import os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', '..'))
from cloudkit import *
C = 'l14_challenges.txt'
def sec(a, b=None, drop=()):
    return capsec(C, a, b, drop)
B = '../../'
hk = hook('If the cloud is so good, why do companies still lose money, data and sleep over it?',
    'Because the cloud has real limits. Google Cloud’s own status feed lists <b>8 incidents</b> in the last 12 months; one about network traffic from <b>Delhi, Chennai and Mumbai</b> stayed open for <b>516 hours</b> (21 days). Add surprise bills, vendor lock-in, data-law rules, skills gaps and security mistakes. Knowing these is what separates a cloud user from a cloud engineer.',
    ['Nine challenges: downtime, security, cost, lock-in, compliance, latency, control, skills, migration.', 'Reading a real provider incident feed.', 'How each challenge is reduced in practice.'])
cmap = concept_map('Concept map. Beginner: what can go wrong. Intermediate: nine challenges and their fixes. Advanced: SLAs, multi-region, governance.',
    [[('adv', 'Advantages', 'Lesson 1.3', B + '01-introduction/03-characteristics-and-advantages-of-cloud/'), ('net', 'Internet dependency', '', None)],
     [('down', 'Downtime', 'incidents', None), ('sec', 'Security', 'misconfig', None), ('cost', 'Cost overrun', 'forgotten', None), ('lock', 'Lock-in', 'proprietary', None)],
     [('sla', 'SLAs', 'Lesson 5.4', B + '05-core-cloud-concepts/04-service-level-agreements/'), ('ha', 'Multi-AZ / region', 'Lesson 7.2', B + '07-cloud-architecture/02-scalability-availability-and-fault-tolerance/'), ('sr', 'Shared responsibility', 'Lesson 9.1', B + '09-cloud-security/01-shared-responsibility-model/'), ('mc', 'Multi-cloud', 'Lesson 3.3', B + '03-deployment-models/03-multi-cloud-vs-hybrid-cloud/')]],
    [('adv', 'down'), ('net', 'down'), ('down', 'sla'), ('down', 'ha'), ('sec', 'sr'), ('cost', 'sla'), ('lock', 'mc'), ('adv', 'cost')],
    {'down', 'sec', 'cost', 'lock', 'sla', 'ha'},
    '<b>Next:</b> <a href="../05-on-premises-vs-cloud-vs-dedicated-servers/">1.5 On-premises vs cloud vs dedicated</a>.')
whw = why_how_where(
    'Every cloud decision is a trade-off. Interviewers ask “what are the disadvantages?” to see if you think like an engineer, not a salesperson.',
    'Challenges come from sharing (security, noisy neighbours), distance (latency, internet dependency), the provider’s control (outages, lock-in) and the pay-per-use model (cost surprises).',
    'Architecture reviews, migration plans, risk registers, audits (banking, health, government), exam “limitations” questions.',
    'No cloud is 100% available; even multi-region designs reduce, not remove, risk.')
def risks(hl=-1):
    items = [('Downtime', 'red'), ('Security', 'red'), ('Cost', 'amber'), ('Lock-in', 'amber'), ('Compliance', 'violet'), ('Latency', 'blue'), ('Control', 'blue'), ('Skills', 'green'), ('Migration', 'green')]
    o = box(130, 54, 100, 40, 'acc', rx=20) + t(180, 78, 'Your cloud app', 8.6, 'ink', bold=True)
    import math
    for i, (lab, tn) in enumerate(items):
        a = -math.pi / 2 + i * 2 * math.pi / 9; x = 180 + 150 * math.cos(a); y = 74 + 58 * math.sin(a)
        o += f'<line x1="180" y1="74" x2="{x:.0f}" y2="{y:.0f}" stroke="currentColor" class="s-ink2" opacity=".35"/>'
        o += box(x - 32, y - 10, 64, 20, 'amber' if i == hl else tn, rx=10) + t(x, y + 3.5, lab, 7.4, 'ink', bold=True)
    return o
scene_svg = scene('Nine risks around a cloud application: downtime, security, cost, lock-in, compliance, latency, control, skills, migration.', risks(0),
                  'Nine challenges to plan for — <tspan font-weight="700" class="s-acc">none is a reason to avoid cloud, all need a plan</tspan>.')
dialogue = '''K> Sir, the TiffinGo app was slow for users in Pune last June, but our servers were fine!
A> The problem may not be ours. Providers publish incidents. Let’s read Google Cloud’s feed — one incident was about traffic from Delhi, Chennai and Mumbai.
R> So the cloud also fails?
A> Everything fails sometimes. Today: the nine challenges of cloud and what engineers do about each.'''
lv = '''
LEVELS> Cloud challenges at three levels
L1> Renting a flat, not owning it
      <ul>
        <li>The landlord fixes the building (provider), but if the water supply stops (outage) you wait; you can’t knock down walls (control); moving out is effort (lock-in); and the bill depends on how much you use (cost).</li>
      </ul>
L2> The nine challenges
      <ul>
        <li><b>Downtime</b> and internet dependency · <b>security & privacy</b> (mostly misconfiguration) · <b>cost overruns</b> · <b>vendor lock-in</b> · <b>compliance / data residency</b> (e.g. India’s DPDP Act 2023, RBI rules) · <b>latency</b> · <b>limited control</b> over hardware · <b>skills gap</b> · <b>migration complexity</b>.</li>
      </ul>
L3> How architects reduce them
      <ul>
        <li>Multi-AZ and multi-region designs, backups and DR (RTO/RPO); least-privilege IAM and encryption; budgets, tags and FinOps; open standards (containers, Terraform, SQL) to limit lock-in; Indian regions for residency; CDNs for latency; training and certification for skills.</li>
      </ul>
/LEVELS
'''
mm = mindmap('Mind map of cloud challenges and their fixes.', 'Cloud challenges', [
    ('Availability', 'red', ['outages', 'internet down', '→ multi-AZ, DR']),
    ('Security', 'violet', ['misconfiguration', 'leaked keys', '→ IAM, MFA']),
    ('Money', 'amber', ['surprise bills', 'data transfer', '→ budgets, tags']),
    ('Lock-in', 'blue', ['proprietary APIs', 'egress fees', '→ open standards']),
    ('Law', 'green', ['data residency', 'DPDP, RBI', '→ Indian regions']),
    ('People', 'card', ['skills gap', 'migration effort', '→ training, certs'])], h=290)
lay = layers('Where each challenge sits: your users and internet at the top, your configuration in the middle, the provider’s infrastructure at the bottom.', [
    ('Users + internet', 'latency, ISP outages', 'blue'), ('Your account settings', 'security misconfig, IAM', 'red'),
    ('Your architecture', 'single AZ = single point of failure', 'amber'), ('Your bill', 'forgotten resources, egress', 'amber'),
    ('Provider services', 'regional incidents, API changes', 'violet'), ('Provider data centres', 'power, network, hardware', 'card')], hl=1, caption='Most incidents customers suffer start in the middle layers — theirs.')
DIS = figure('Dissection of a real Google Cloud incident: began 5 June 2026, network traffic from Delhi, Chennai, Mumbai, severity medium, open 516 hours.',
    t(16, 22, 'One real incident record', 8.6, 'ink', anchor='start', bold=True) +
    fields(16, 34, [('2026-06-05', 'blue', 1), ('Delhi, Chennai, Mumbai', 'green', 2), ('medium', 'amber', 3), ('516 h', 'violet', 4)]) +
    legend(16, 84, [(1, 'Begin', 'when it started'), (2, 'Scope', 'traffic from Indian cities'), (3, 'Severity', 'provider’s rating'), (4, 'Duration', 'begin → end in the feed')], size=8, gap=15, w=90),
    h=156, caption='Long “open” time = tracking period, not 21 days of total outage.')
extra = '\n\n  <h3>Where challenges live</h3>\n' + lay + '\n\n  <h3>Dissect a real incident</h3>\n' + DIS
types_html = table(['Challenge', 'What goes wrong', 'Typical fix'], [
    ['Downtime', 'provider or internet outage', 'multi-AZ/region, health checks, DR plan'],
    ['Security & privacy', 'public bucket, leaked key, weak IAM', 'MFA, least privilege, encryption, audits'],
    ['Cost overrun', 'idle VMs, NAT gateways, data transfer out', 'budgets, alerts, tags, rightsizing'],
    ['Vendor lock-in', 'proprietary services, egress fees', 'containers, Terraform, open formats, exit plan'],
    ['Compliance', 'data must stay in India, audits', 'Indian regions, certifications, logs'],
    ['Latency', 'users far from region', 'nearest region, CDN, edge'],
    ['Limited control', 'no hardware access, provider changes', 'SLAs, support plans, managed services'],
    ['Skills gap', 'team new to cloud', 'training, certification, guardrails'],
    ['Migration', 'old apps hard to move', '6 Rs strategy (rehost, replatform, refactor…)']], minw=620)
warn = 'Most cloud data breaches are customer misconfigurations (open storage buckets, leaked access keys), not the provider being hacked. Read Lesson 9.1 shared responsibility before you build anything public.'
steps = [
    ('Step 1 · Providers publish incidents', code('python', 'l14_challenges.py', 'inc = json.load(urlopen("https://status.cloud.google.com/incidents.json"))', sec('== 1)', '== 2)')), 'The public feed keeps recent incidents; history beyond that is in past reports.'),
    ('Step 2 · Severity', code('python', 'l14_challenges.py', 'Counter(i["severity"] for i in last_12_months)', sec('== 2)', '== 3)')), 'Mostly medium; one high.'),
    ('Step 3 · How long they stay open', code('python', 'l14_challenges.py', 'end - begin in hours; median, 90th percentile, longest', sec('== 3)', '== 4)')), 'Half end within ~11 hours; one tracking record stayed open 21 days.'),
    ('Step 4 · Did India get hit?', code('python', 'l14_challenges.py', 'affected locations contain asia-south1 / asia-south2', sec('== 4)', '== 5)')), 'One: traffic from Indian cities in June 2026. Internet paths are part of “the cloud”.'),
    ('Step 5 · Which products', code('python', 'l14_challenges.py', 'Counter(product titles)', sec('== 5)')), 'Databases, storage, serverless and analytics: no service is immune.'),
]
see = [term([('8 incidents', W), ('last 12 months', W)], size=7.0), term([('medium 6 high 1', W), ('low 1', W)], size=7.0), term([('median 10.7 h', G), ('longest 516 h', RD)], size=7.0),
       term([('India: 1', RD), ('2026-06-05', W)], size=7.0), term([('Cloud Run 3', W), ('BigQuery 3', W)], size=7.0)]
B1 = [risks(i) for i in (0, 0, 0, 5, 1)]
B1 = [b + cap(c, '', tn, y=146, h=20) for b, c, tn in zip(B1, ['Outages happen', 'Severity', 'Duration', 'Latency from India', 'Every product'], ['red', 'amber', 'amber', 'blue', 'violet'])]
two = anim_two('Cloud challenges', 'Reading a real incident feed', 'Real outputs (Google Cloud status)', 'Nine risks', see, B1, ['Feed.', 'Severity.', 'Hours.', 'India.', 'Products.'], ['Down.', 'Rate.', 'Long.', 'Network.', 'Any.'])
pe = peel('A regional outage, layer by layer', 'What happens and what saves you. (Simplified.)',
    [('Fault', ''), ('Detect', ''), ('Impact', ''), ('Failover', ''), ('Recover', ''), ('Review', '')],
    [['Fault', 'zone network', 'problem', ''], ['Detect', 'health checks fail', 'alarms fire', ''], ['Impact', 'single-AZ app', 'goes down', 'bad design'],
     ['Failover', 'multi-AZ app', 'shifts traffic', 'good design'], ['Recover', 'provider fixes', 'incident closed', ''], ['Review', 'post-incident', 'report', 'learn']],
    ['Break.', 'Notice.', 'Hurt.', 'Survive.', 'Fix.', 'Learn.'], 'scenario-peel')
scen = five('Real-time scenario 1', 'Public bucket leak', 'Customer data exposed. (Typical.)', ('Misconfiguration', 'Block public access'), [
    ('Bucket made public', 'for a quick test', 'Mistake.', 'red'), ('Search bots find it', 'hours later', 'Leak.', 'red'),
    ('Block Public Access on', 'account level', 'Fix.', 'green'), ('Encrypt + log', '', 'Harden.', 'green'), ('Audit with config rules', '', 'Prevent.', 'amber')], ['Public.', 'Found.', 'Block.', 'Encrypt.', 'Audit.'], 'scenario-leak') + \
       five('Real-time scenario 2', 'The ₹2 lakh bill', 'Student lab left on. (Typical.)', ('Cost control', 'Budgets + cleanup'), [
    ('GPU VM for a demo', '', 'Start.', 'blue'), ('Forgot to stop', '30 days', 'Mistake.', 'red'),
    ('Bill arrives', 'shock', 'Pain.', 'red'), ('Budget alert at $1', 'next time', 'Fix.', 'green'), ('Cleanup checklist', 'every lab', 'Habit.', 'amber')], ['Start.', 'Forget.', 'Bill.', 'Alert.', 'Habit.'], 'scenario-bill') + \
       five('Real-time scenario 3 · advanced', 'Lock-in', 'Moving clouds is hard. (Typical.)', ('Portability', 'Open standards'), [
    ('Built on proprietary DB', '', 'Then.', 'blue'), ('Price rises / new rules', '', 'Change.', 'amber'),
    ('Export costs + rewrite', 'egress fees', 'Pain.', 'red'), ('Containers + Terraform', 'portable layers', 'Design.', 'green'), ('Exit plan documented', '', 'Ready.', 'green')], ['Proprietary.', 'Change.', 'Cost.', 'Portable.', 'Plan.'], 'scenario-lockin')
clouds = vendor_tabs(
    '<p><b>AWS:</b> AWS Health Dashboard (public + personal), Trusted Advisor (cost, security, limits), AWS Budgets, Well-Architected reliability pillar, Region/AZ design.</p>',
    '<p><b>Azure:</b> Azure Status + Service Health, Azure Advisor, Cost Management budgets, availability zones and region pairs.</p>',
    '<p><b>Google Cloud:</b> status.cloud.google.com (public incidents JSON used here), Personalized Service Health, Recommender, budgets and alerts.</p>') + \
    cloud3([['Public status page', 'health.aws.amazon.com', 'azure.status.microsoft', 'status.cloud.google.com'], ['Your own incidents', 'AWS Health (personal)', 'Service Health', 'Personalized Service Health'], ['Advice engine', 'Trusted Advisor', 'Azure Advisor', 'Recommender / Active Assist'], ['Budget alerts', 'AWS Budgets', 'Cost Management budgets', 'Cloud Billing budgets']])
prac = practical('Check the health of three clouds and read incidents yourself. No account needed.', [
    ('1 · Google incidents as JSON', code('bash', 'terminal', "curl -s https://status.cloud.google.com/incidents.json | jq '.[] | {begin, severity, d: .external_desc[0:60]}' | head -40"), 'Each object is one incident.'),
    ('2 · Filter India', code('bash', 'terminal', "curl -s https://status.cloud.google.com/incidents.json | jq -r '.[] | select(tostring | test(\"asia-south\")) | .begin + \" \" + .external_desc[0:70]'"), 'Matches Step 4.'),
    ('3 · AWS and Azure status pages', '<p>Open <code>health.aws.amazon.com/health/status</code> and <code>azure.status.microsoft</code>; filter Asia Pacific (Mumbai) / Central India.</p>', 'Note the format each uses.'),
    ('4 · Run the lesson script', code('bash', 'terminal', 'python3 l14_challenges.py'), 'Same output style as Steps 1–5.'),
    ('5 · Write a 5-line risk register', '<p>For TiffinGo: risk, likelihood, impact, fix, owner. Use the types table.</p>', 'This is real work in every migration project.')],
    cleanup='Nothing created. Keep your risk register; you will reuse it in the capstone (Module 11).')
mist = mistakes([
    ['Running production in one availability zone.', 'Simplest setup, cheapest.', 'Use at least 2 AZs behind a load balancer (Lesson 7.2).'],
    ['Making storage public “for testing”.', 'Quick sharing; forgotten later.', 'Use pre-signed links; keep Block Public Access on.'],
    ['Assuming the provider backs up your data.', 'Shared responsibility misunderstood.', 'Configure backups/versioning yourself; test restores.'],
    ['No budget alert on a new account.', 'Sign-up does not force one.', 'Create a zero-spend + monthly budget on day one.'],
    ['Picking a US region for Indian personal data.', 'Default region in tutorials.', 'Check data-residency rules; use Indian regions.']])
cert = certbox([
    ['AWS CLF-C02', 'Domain 1 · Cloud Concepts', 'Design principles: design for failure, multi-AZ; migration strategies (the 6/7 Rs); Cloud Adoption Framework basics.'],
    ['AWS CLF-C02', 'Domain 2 · Security & Compliance', 'Misconfiguration risk, shared responsibility, AWS Artifact for compliance reports.'],
    ['Azure AZ-900', 'Describe cloud concepts / management', 'Reliability, availability, Service Health, Advisor.'],
    ['Google Cloud Digital Leader', 'Trust and security; Scaling with operations', 'Reliability, incident response, shared fate.'],
    ['C-DAC PGCP-BDA', 'Sessions 3–4', 'Challenges of the cloud environment.']],
    [('Which is the MOST common cause of cloud data exposure? (a) provider hardware theft (b) customer misconfiguration (c) solar flares', '<b>(b)</b> Customer misconfiguration (e.g. public buckets).'),
     ('A company fears it cannot leave a provider easily. This risk is…', '<b>Vendor lock-in.</b> Reduce with open standards and an exit plan.'),
     ('Running in multiple Availability Zones mainly protects against…', 'A single data-centre (zone) failure: higher availability.')])
proj = miniproject('Mini project: cloud status watcher',
    'A script that checks the Google Cloud incident feed every hour and prints a line when an incident mentions an Indian region.',
    ['Copy the Step 4 filter into <code>watch.py</code>; remember seen incident ids in a file.', 'Print new matches with time and description.', 'Schedule with <code>cron</code>: <code>0 * * * * python3 /home/you/watch.py &gt;&gt; watch.log</code>.', 'Bonus: send yourself an email/Telegram message (later: AWS SNS, Lesson 7.2 of the AWS course).'],
    'A <code>watch.log</code> that grows only when Indian regions are affected.', 'Python + JSON, Linux cron, later AWS SNS.')
assemble_cloud(HERE, interview=['“Cloud has trade-offs: possible downtime and internet dependency, security and privacy risks mostly from misconfiguration, cost overruns, vendor lock-in, compliance and data-residency rules, latency, limited control and a skills gap.”', '“We reduce them with multi-AZ or multi-region design, least-privilege IAM and encryption, budgets and tagging, open standards like containers and Terraform, and choosing Indian regions for regulated data.”'],
    clouds_html=clouds, practical_html=prac, mistakes_html=mist, cert_html=cert, project_html=proj, mindmap_html=mm,
    h2_story='Slow in Pune, but our servers were fine', hook_html=hk,
    narration='In June, TiffinGo users in western India complained of slow loading. The team’s servers looked healthy. Was it them, the internet, or the cloud?',
    scene_svg=scene_svg, dialogue=dialogue, def_h2='Challenges and limitations of cloud computing',
    formal='The <b>challenges of cloud computing</b> are the risks and constraints of consuming shared, remote, provider-operated infrastructure: availability and network dependency, security and privacy, cost management, vendor lock-in, regulatory compliance and data residency, latency, reduced control, skills shortage and migration complexity.',
    simple='The cloud can still go down, can be misused, can cost more than expected, can be hard to leave, and must follow data laws — so you plan for each.',
    term_rows=[('Outage', 'Service unavailable.'), ('Incident', 'Provider-reported problem.'), ('Misconfiguration', 'Wrong settings by the customer.'), ('Vendor lock-in', 'Hard to move providers.'), ('Egress fee', 'Charge for data leaving the cloud.'), ('Data residency', 'Where data must physically stay.'), ('Latency', 'Delay over the network.'), ('DR', 'Disaster recovery plan.')],
    whw=whw, cmap=cmap, extra_def=extra, lv=lv,
    myth_rows=[('Big clouds never fail.', '8 incidents in 12 months on one feed.', 'Step 1.'), ('Outages are always short.', 'One record open 516 h.', 'Step 3.'), ('Indian users are unaffected by global issues.', 'June 2026 incident on Indian traffic.', 'Step 4.')],
    exam='Typical questions: “Which is a disadvantage of cloud?” (internet dependency, lock-in, less control); “How to improve availability?” (multiple AZs/regions); “Who causes most breaches?” (customer misconfiguration). AWS migration: the 7 Rs (retire, retain, rehost, relocate, repurchase, replatform, refactor).',
    types_h2='Nine challenges and their fixes', types_html=types_html, warn=warn,
    steps_h2='Reading a real incident feed', steps_intro='All outputs are real: Google Cloud’s public incidents.json, downloaded 10 Nov 2026.',
    steps=steps, two=two, peel_intro='Now peel a regional outage.', peel_html=pe, scen_intro='Three live scenarios: a leak, a bill, lock-in.', scen=scen,
    uc_h2='Challenges in real projects', ucs=[uc_('bank', 'compliance', 'violet', '1. Banking', 'Residency + audits shape design.', ['Data', '*India region', 'Audit']),
        uc_('ecom', 'downtime', 'red', '2. E-commerce', 'Multi-AZ for sale days.', ['Users', '*2 AZs', 'Orders']),
        uc_('edu', 'cost', 'amber', '3. Colleges', 'Student labs need budgets.', ['Labs', '*Budgets', 'Safe']),
        uc_('gov', 'lock-in', 'blue', '4. Government', 'Open standards, exit plans.', ['Apps', '*Containers', 'Portable'])],
    uc_note='Examples are simplified descriptions of common practice.', pre='<b>Before you start:</b> <a href="../03-characteristics-and-advantages-of-cloud/">1.3</a>.')
