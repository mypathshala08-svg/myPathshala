import os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', '..'))
from cloudkit import *
C = 'l11_cloud_is_real.txt'
def sec(a, b=None, drop=()):
    return capsec(C, a, b, drop)
B = '../../'
hk = hook('Where does your photo go when you “save it to the cloud”? Is the cloud just someone else’s computer?',
    'Yes, and no. The cloud is real buildings full of servers, but you <b>rent</b> them by the minute over the internet, start them yourself in seconds and pay only for what you use. AWS even publishes every IP range it owns: on 9 Nov 2026 the file listed <b>10,744 IPv4 ranges across 42 regions</b>, including Mumbai and Hyderabad. Google Cloud lists <b>48 regions</b>, with Mumbai and Delhi in India.',
    ['The NIST definition: 5 characteristics, 3 service models, 4 deployment models.', 'The parts of a cloud: front end, back end, network, data centres.', 'Seeing real cloud infrastructure from your own laptop.'])
cmap = concept_map('Concept map. Beginner: renting computing over the internet. Intermediate: five NIST characteristics, service and deployment models. Advanced: regions, pay-as-you-go, shared responsibility.',
    [[('it', 'Own servers', 'buy, run, fix', None), ('net', 'Internet', 'broad access', None)],
     [('od', 'On-demand', 'self-service', None), ('pool', 'Pooling', 'shared hardware', None), ('el', 'Elasticity', 'grow + shrink', None), ('ms', 'Measured', 'pay per use', None)],
     [('sm', 'Service models', 'IaaS PaaS SaaS', B + '02-service-models/01-iaas-infrastructure-as-a-service/'), ('dm', 'Deployment models', 'public, private…', B + '03-deployment-models/01-public-private-hybrid-and-community-cloud/'), ('rg', 'Regions', 'Module 5', B + '05-core-cloud-concepts/01-regions-availability-zones-and-edge-locations/'), ('sr', 'Shared responsibility', 'Module 9', B + '09-cloud-security/01-shared-responsibility-model/')]],
    [('it', 'od'), ('net', 'od'), ('od', 'pool'), ('pool', 'el'), ('el', 'ms'), ('od', 'sm'), ('pool', 'dm'), ('el', 'rg'), ('ms', 'sr')],
    {'od', 'pool', 'el', 'ms'},
    '<b>Next:</b> <a href="../02-history-and-evolution-of-cloud-computing/">1.2 History and evolution</a>. <b>Related:</b> <a href="../../../linux/">Linux course</a> (every cloud server runs it).')
whw = why_how_where(
    'Buying servers takes weeks, costs lakhs up front and they sit idle most of the year. The cloud turns that into a bill you can switch on and off, like electricity.',
    'Providers build huge data centres, split machines with virtualization (Module 4), and expose them through a website (console), command line and APIs. You ask, they allocate in seconds, a meter counts usage.',
    'Websites and apps, data storage and backup, big data and AI, email and office tools (SaaS), testing environments, disaster recovery.',
    'Internet down = cloud unreachable; costs grow if you forget resources; data laws may require data in India; you trust the provider’s security for the layers they manage.')

def spike(hl=-1):
    """Traffic vs servers: own data centre (fixed 6) vs cloud (follows demand)."""
    load = [2, 2, 3, 3, 4, 9, 11, 8, 3, 2]
    cloud = [2, 2, 3, 3, 4, 9, 11, 8, 3, 2]
    o = ''
    for i, (l, c) in enumerate(zip(load, cloud)):
        x = 28 + i * 30
        o += box(x, 118 - l * 8, 12, l * 8, 'blue', rx=2)
        o += box(x + 13, 118 - c * 8, 10, c * 8, 'green' if hl != 0 else 'card', rx=2)
    o += f'<line x1="22" y1="{118 - 6 * 8}" x2="330" y2="{118 - 6 * 8}" stroke="#D64545" stroke-width="2" stroke-dasharray="5 3"/>'
    o += t(332, 118 - 6 * 8 - 4, 'own: 6 servers', 7.2, 'red', anchor='end', bold=True)
    o += t(178, 13, 'Diwali week: orders (blue) vs cloud servers (green)', 7.6, 'ink', bold=True)
    o += t(206, 128, 'days →', 7) + (box(30, 22, 66, 18, 'amber', rx=5) + t(63, 34, 'site down!', 7.4, 'red', bold=True) if hl == 1 else '')
    return o
scene_svg = scene('A bar chart of TiffinGo orders during Diwali week. Fixed own servers (6) are too few on the peak days and wasted on quiet days; cloud servers rise and fall with the orders.', spike(1),
                  'Own servers: too few on peak days, idle on quiet days. <tspan font-weight="700" class="s-acc">Cloud: follows demand</tspan>.')
dialogue = '''K> Sir, last Diwali TiffinGo’s site crashed for 3 hours. Boss says “buy 10 more servers”.
A> And for the other 360 days those servers sit idle, eating electricity. What if we could <b>rent</b> 10 servers for just Diwali week?
R> Like booking an Ola instead of buying a car?
A> Exactly. That is cloud computing. Today: what it really is, and proof that it is real hardware, not magic.'''

lv = '''
LEVELS> Cloud computing at three levels
L1> Electricity for computers
      <ul>
        <li>You don’t build a power plant at home: you plug in and pay the bill. The cloud is the same for computers, storage and software: plug in over the internet, use, pay for what you used.</li>
        <li>Gmail, Google Drive, Netflix, IRCTC and UPI apps all run on cloud-style data centres.</li>
      </ul>
L2> The NIST definition
      <ul>
        <li><b>5 characteristics:</b> on-demand self-service · broad network access · resource pooling · rapid elasticity · measured service.</li>
        <li><b>3 service models:</b> IaaS (rent machines), PaaS (rent a platform), SaaS (use finished software). Module 2.</li>
        <li><b>4 deployment models:</b> public, private, hybrid, community. Module 3.</li>
      </ul>
L3> What it means for an architect
      <ul>
        <li>Capital expense (CapEx, buy up front) becomes operating expense (OpEx, pay monthly); capacity planning becomes auto scaling.</li>
        <li>Everything is an API: the console, the CLI and Terraform all call the same APIs (Module 8).</li>
        <li>Location still matters: regions and availability zones decide latency, cost, data law and fault tolerance (Module 5).</li>
      </ul>
/LEVELS
'''
mm = mindmap('Mind map of cloud computing: definition, five characteristics, service models, deployment models, providers and benefits.', 'Cloud computing', [
    ('5 traits (NIST)', 'blue', ['on-demand', 'network access', 'pooling', 'elasticity', 'measured']),
    ('Service models', 'green', ['IaaS', 'PaaS', 'SaaS', '+ FaaS']),
    ('Deployment', 'violet', ['public', 'private', 'hybrid', 'community']),
    ('Providers', 'acc', ['AWS', 'Azure', 'Google Cloud']),
    ('Parts', 'card', ['front end', 'back end', 'network', 'data centres']),
    ('Benefits', 'amber', ['pay as you go', 'speed', 'global', 'no idle servers'])], h=300)
lay = layers('Layers of a cloud: your device and browser at the top, the internet, the provider front door (console, CLI, API), the service layer, virtualization, and physical data centres at the bottom.', [
    ('Your phone / laptop', 'browser, app, CLI', 'blue'), ('Internet', 'broad network access', 'card'),
    ('Front door: console · CLI · API', 'on-demand self-service', 'green'), ('Services', 'VMs, storage, databases, AI…', 'violet'),
    ('Virtualization', 'one machine → many VMs (pooling)', 'acc'), ('Data centres in regions', 'servers, disks, power, cooling', 'card')], hl=None, caption='Every cloud request goes down these layers and back.')
DIS = figure('Dissection of one line of AWS’s public IP range file: prefix 16.4.0.0/16, region ap-south-1 (Mumbai), service EC2.',
    t(16, 22, 'One real line from ip-ranges.json', 8.6, 'ink', anchor='start', bold=True) +
    fields(16, 34, [('16.4.0.0/16', 'blue', 1), ('ap-south-1', 'green', 2), ('EC2', 'amber', 3), ('2026-11-09', 'violet', 4)]) +
    legend(16, 84, [(1, 'IP range', '65,536 addresses AWS owns'), (2, 'Region', 'Mumbai data centres'), (3, 'Service', 'virtual machines'),
                    (4, 'File date', 'updated by AWS')], size=8, gap=15, w=90),
    h=156, caption='Cloud “magic” has addresses, buildings and a city.')
extra = '''

  <h3>The layers behind every cloud request</h3>
''' + lay + '''

  <h3>Dissect a real cloud address</h3>
''' + DIS
types_html = table(['Way to describe it', 'Says', 'Source'], [
    ['NIST SP 800-145', 'a model for on-demand network access to a shared pool of configurable resources, provisioned with minimal effort', 'US standards body (exam favourite)'],
    ['AWS', 'on-demand delivery of IT resources over the internet with pay-as-you-go pricing', 'aws.amazon.com/what-is-cloud-computing'],
    ['Google Cloud', 'on-demand access to computing resources over the internet, with pay-per-use', 'cloud.google.com/learn'],
    ['Simple', 'rent computers and software by the minute, through the internet', 'this course']], minw=600)
warn = 'Cloud is not “free storage on the internet”. Every running machine, disk, IP address and data transfer has a meter. In the hands-on lessons we always clean up at the end and set a budget alert first (Lesson 1.3 of the AWS course).'
steps = [
    ('Step 1 · AWS publishes its whole network',
     code('python', 'l11_cloud_is_real.py', 'a = json.load(urlopen("https://ip-ranges.amazonaws.com/ip-ranges.json"))\nlen(a["prefixes"]), len(a["ipv6_prefixes"]), regions', sec('== 1)', '  ap-south-1 IPv4')),
     'Tens of thousands of address blocks and 42 region codes: physical places, not a fog.'),
    ('Step 2 · What runs in Mumbai',
     code('python', 'l11_cloud_is_real.py', 'Counter(x["service"] for x in prefixes if x["region"] == "ap-south-1")', sec('  ap-south-1 IPv4', '== 2)')),
     'Virtual machines (EC2), storage (S3), DNS (Route 53), APIs: services you will use in the AWS course.'),
    ('Step 3 · Google Cloud does the same',
     code('python', 'l11_cloud_is_real.py', 'g = json.load(urlopen("https://www.gstatic.com/ipranges/cloud.json"))', sec('== 2)', '== 3)')),
     'Two Indian regions each: AWS Mumbai + Hyderabad, Google Mumbai + Delhi.'),
    ('Step 4 · One address each',
     code('python', 'l11_cloud_is_real.py', 'first EC2 range in ap-south-1; first range in asia-south1', sec('== 3)')),
     'A request from your phone to a Mumbai VM goes to an address like these.'),
]
see = [term([('10744 IPv4 prefixes', G), ('42 regions', G)], size=7.0), term([('AMAZON 167 EC2 56', W), ('S3 14', W)], size=7.0),
       term([('GCP 1153 prefixes', G), ('48 scopes', G)], size=7.0), term([('16.4.0.0/16 EC2', W), ('8.231.64.0/18', W)], size=7.0), term([('pay per use', G), ('no idle servers', G)], size=7.0)]
B1 = [spike(0), spike(1), spike(-1), spike(-1), spike(-1)]
B1 = [b + cap(c, '', tn, y=140, h=24) for b, c, tn in zip(B1, ['Fixed capacity', 'Peak: crash', 'Cloud follows', 'Quiet: shrink', 'Pay for green'], ['red', 'red', 'green', 'blue', 'green'])]
two = anim_two('Cloud computing', 'Real infrastructure, elastic use', 'Real outputs (public cloud files)', 'Diwali week at TiffinGo', see, B1, ['AWS.', 'Mumbai.', 'Google.', 'Addresses.', 'Bill.'], ['Fixed.', 'Crash.', 'Elastic.', 'Shrink.', 'Pay.'])
pe = peel('A cloud request, layer by layer', 'Riya clicks “Order” in the TiffinGo app. (Simplified.)',
    [('Phone', ''), ('Internet', ''), ('Front door', ''), ('Service', ''), ('VM', ''), ('Data centre', '')],
    [['Phone', 'HTTPS request', 'to api.tiffingo.in', ''], ['Internet', 'DNS → IP', '16.4.x.x (Mumbai)', ''], ['Front door', 'load balancer', 'picks a server', ''],
     ['Service', 'app on a VM', 'reads database', ''], ['VM', 'one slice of', 'a big server', 'pooling'], ['Data centre', 'ap-south-1', 'power, cooling, disks', '']],
    ['Tap.', 'Route.', 'Balance.', 'Process.', 'Share.', 'Physical.'], 'scenario-peel')
scen = five('Real-time scenario 1', 'Festival spike', 'Diwali orders ×4. (Typical.)', ('Elasticity', 'Add servers for a week'), [
    ('Normal: 3 servers', '₹ low bill', 'Before.', 'blue'), ('Orders ×4', 'Diwali', 'Spike.', 'red'),
    ('Auto scaling adds 9', 'in minutes', 'Grow.', 'green'), ('After festival', 'back to 3', 'Shrink.', 'green'),
    ('Bill: only that week', 'measured service', 'Pay.', 'amber')], ['Normal.', 'Spike.', 'Grow.', 'Shrink.', 'Pay.'], 'scenario-spike') + \
       five('Real-time scenario 2', 'Startup in a day', 'New app idea. (Typical.)', ('On-demand', 'No purchase order'), [
    ('Idea on Monday', '', 'Start.', 'blue'), ('Create VM + database', 'console, 10 min', 'Self-service.', 'green'),
    ('Show investors Tuesday', 'public URL', 'Demo.', 'green'), ('Idea fails', 'delete all', 'Stop.', 'amber'),
    ('Loss: a few hundred ₹', 'not lakhs', 'Cheap failure.', 'violet')], ['Idea.', 'Create.', 'Demo.', 'Delete.', 'Small loss.'], 'scenario-startup') + \
       five('Real-time scenario 3 · advanced', 'Data must stay in India', 'Regulated data. (Typical.)', ('Region choice', 'ap-south-1 / asia-south1'), [
    ('Bank data', 'RBI rules', 'Rule.', 'red'), ('Pick Indian region', 'Mumbai', 'Place.', 'green'),
    ('Backup in Hyderabad', 'second region', 'Protect.', 'green'), ('Encrypt', 'keys you control', 'Secure.', 'amber'),
    ('Audit logs', 'who did what', 'Prove.', 'blue')], ['Rule.', 'Mumbai.', 'Hyderabad.', 'Encrypt.', 'Audit.'], 'scenario-india')

clouds = vendor_tabs(
    '<p><b>AWS</b> (Amazon Web Services, 2006) is the largest public cloud. India regions: <code>ap-south-1</code> Mumbai and <code>ap-south-2</code> Hyderabad. You enter through the AWS Management Console, the AWS CLI or SDKs.</p><p>Exam: <b>AWS Certified Cloud Practitioner (CLF-C02)</b>.</p>',
    '<p><b>Microsoft Azure</b> (2010) is strong with companies already on Windows, Office 365 and Active Directory. India regions include Central India (Pune), South India (Chennai) and West India (Mumbai). Entry: Azure portal, Azure CLI, PowerShell.</p><p>Exam: <b>AZ-900 Azure Fundamentals</b>.</p>',
    '<p><b>Google Cloud</b> (2008, App Engine) is known for data, analytics and AI (BigQuery, Vertex AI). India regions: <code>asia-south1</code> Mumbai and <code>asia-south2</code> Delhi. Entry: Google Cloud console, <code>gcloud</code> CLI.</p><p>Exam: <b>Cloud Digital Leader</b>.</p>') + \
    cloud3([['Web console', 'AWS Management Console', 'Azure portal', 'Google Cloud console'], ['Command line', 'aws CLI, CloudShell', 'az CLI, Cloud Shell', 'gcloud CLI, Cloud Shell'],
            ['Virtual machine', 'EC2', 'Virtual Machines', 'Compute Engine'], ['Object storage', 'S3', 'Blob Storage', 'Cloud Storage'],
            ['India regions', 'Mumbai, Hyderabad', 'Pune, Chennai, Mumbai', 'Mumbai, Delhi'], ['Free start', 'Free plan + credits', 'Free account + credit', 'Free trial + credit']])
prac = practical('No account and no card needed today. You will look at real cloud infrastructure from your own computer (Linux, macOS or Windows with WSL).', [
    ('1 · Download AWS’s address list', code('bash', 'terminal', 'curl -s https://ip-ranges.amazonaws.com/ip-ranges.json -o aws.json\nls -lh aws.json'), 'A few MB of JSON, updated by AWS several times a week.'),
    ('2 · Count Mumbai ranges with jq', code('bash', 'terminal', 'sudo apt install -y jq          # once\njq \'[.prefixes[] | select(.region=="ap-south-1")] | length\' aws.json\njq -r \'.prefixes[].region\' aws.json | sort -u | wc -l'), 'Compare your numbers with Step 1–2 above; they change over time.'),
    ('3 · Do the same for Google Cloud', code('bash', 'terminal', 'curl -s https://www.gstatic.com/ipranges/cloud.json -o gcp.json\njq -r \'.prefixes[].scope\' gcp.json | sort -u | grep asia-south'), 'You should see asia-south1 and asia-south2.'),
    ('4 · Open the provider health pages', '<p>Visit <code>health.aws.amazon.com/health/status</code>, <code>azure.status.microsoft</code> and <code>status.cloud.google.com</code>. Find Mumbai on each.</p>', 'Clouds publish outages per region: one more proof they are real places.'),
    ('5 · Run the lesson script', code('bash', 'terminal', 'python3 l11_cloud_is_real.py'), 'Same output style as Step 1–4 above (numbers will be newer).')],
    cleanup='Nothing to delete: we only downloaded public files. From the AWS course onward, every lab ends with this box and a delete command.')
prac = prac.replace('<ol class="stepper">', caution('Do not create a cloud account with your card “just to look” yet. First learn budgets and alerts (AWS course, Lesson 1.3); most surprise bills come from forgotten resources.') + '<ol class="stepper">', 1)
mist = mistakes([
    ['“Cloud is just online storage like Google Drive.”', 'Drive is one SaaS product; people see only that face of the cloud.', 'Remember the 3 service models: rent machines (IaaS), platforms (PaaS) or finished apps (SaaS).'],
    ['“Cloud is always cheaper.”', 'Pay-per-use is cheap for spiky or small loads; steady 24×7 loads can cost more than owned servers.', 'Compare total cost (Lesson 1.5); use reserved/savings pricing for steady loads (Lesson 5.5).'],
    ['Surprise bill after a free trial.', 'A VM, disk, public IP or NAT gateway kept running; the meter never sleeps.', 'Budget alert first, tag resources, delete after every lab, check the billing page weekly.'],
    ['Slow app for Indian users.', 'Resources created in the default US region (e.g. us-east-1).', 'Pick ap-south-1 / Central India / asia-south1 before creating anything.'],
    ['Logging in as root / owner for daily work.', 'Sign-up account has full power; easy to keep using.', 'Enable MFA, create an admin user/role, lock the root user away (AWS 2.1).']])
cert = certbox([
    ['AWS CLF-C02', 'Domain 1 · Cloud Concepts (24%)', 'Define the AWS Cloud and its value: pay-as-you-go, elasticity, global reach, speed (agility), no guessing capacity.'],
    ['Azure AZ-900', 'Describe cloud concepts (25–30%)', 'Describe cloud computing, shared responsibility idea, consumption-based model.'],
    ['Google Cloud Digital Leader', 'Digital transformation with Google Cloud (~18%)', 'Why organisations move to cloud: speed, scale, cost model, innovation.'],
    ['C-DAC PGCP-BDA', 'Cloud Session 2', 'Definition, characteristics, components, cloud vendors (AWS/Azure/GCP).']],
    [('Which is NOT one of NIST’s five essential characteristics? (a) on-demand self-service (b) rapid elasticity (c) open source software (d) measured service', '<b>(c)</b>. The five are on-demand self-service, broad network access, resource pooling, rapid elasticity, measured service.'),
     ('A company pays only for the compute hours it used last month. Which characteristic/benefit is this?', 'Measured service → pay-as-you-go (trade capital expense for variable expense).'),
     ('TiffinGo adds servers for Diwali and removes them after. Which benefit of the cloud is this?', 'Elasticity: “stop guessing capacity”, scale out and in with demand.')])
proj = miniproject('Mini project: India cloud footprint report',
    'Write one script that prints, for AWS and Google Cloud, how many regions exist, which are in India, and how many address ranges Mumbai has; save it as a dated text report.',
    ['<code>mkdir cloud-report && cd cloud-report</code>', 'Download both JSON files with <code>curl</code> (Practical steps 1 and 3).',
     'Copy <code>l11_cloud_is_real.py</code> and add: <code>open(f"report-{date.today()}.txt","w").write(output)</code>.',
     'Run it every Monday for a month (Linux <code>cron</code>, see the Linux course) and <code>diff</code> two reports.',
     'Push the folder to GitHub (Git course) to share it.'],
    'A dated report such as “AWS 42 regions, India: ap-south-1, ap-south-2 · Mumbai: 304 entries, 221 unique IPv4 ranges”, and diffs showing new ranges over weeks.',
    'Python + JSON, Linux cron and diff, Git/GitHub.')

assemble_cloud(HERE, interview=['“Cloud computing is the on-demand delivery of IT resources such as servers, storage, databases and software over the internet, with pay-as-you-go pricing.”', '“NIST defines it by five characteristics: on-demand self-service, broad network access, resource pooling, rapid elasticity and measured service; three service models, IaaS, PaaS and SaaS; and four deployment models: public, private, hybrid and community.”', '“For example, a food-delivery app can add servers during Diwali and remove them after, paying only for that week.”'], clouds_html=clouds, practical_html=prac, mistakes_html=mist, cert_html=cert, project_html=proj, mindmap_html=mm,
    h2_story='The Diwali crash that cloud would have prevented', hook_html=hk,
    narration='TiffinGo, our food-delivery startup, owns 6 servers in a rented rack. Every festival the orders jump four times and the site falls over; the rest of the year the servers sit almost idle.',
    scene_svg=scene_svg, dialogue=dialogue, def_h2='What is cloud computing?',
    formal='<b>Cloud computing</b> (NIST SP 800-145) is a model for enabling ubiquitous, convenient, on-demand network access to a shared pool of configurable computing resources (networks, servers, storage, applications and services) that can be rapidly provisioned and released with minimal management effort or service-provider interaction. It has five essential characteristics, three service models and four deployment models.',
    simple='Renting computers, storage and software over the internet, starting them yourself in minutes and paying only for what you use.',
    term_rows=[('Cloud provider', 'Company that runs the data centres (AWS, Microsoft, Google).'), ('Region', 'A city/area with data centres.'), ('On-demand', 'Start it yourself, now.'), ('Elasticity', 'Grow and shrink with load.'), ('Pooling', 'Many customers share hardware.'), ('Measured service', 'Metered, pay per use.'), ('CapEx / OpEx', 'Buy up front / pay as you go.'), ('Console / CLI / API', 'Three doors into a cloud.')],
    whw=whw, cmap=cmap, extra_def=extra, lv=lv,
    myth_rows=[('The cloud is not a real place.', '42 AWS regions and 48 Google regions, each with buildings and IP ranges.', 'Step 1, Step 3.'),
               ('Cloud means storage only.', 'Mumbai ranges serve VMs, storage, DNS, APIs…', 'Step 2.'),
               ('Cloud is always cheaper.', 'Cheaper for spiky loads; steady loads need pricing plans.', 'Mistakes table.')],
    exam='Learn the 5 NIST characteristics word for word (on-demand self-service, broad network access, resource pooling, rapid elasticity, measured service). AWS exams phrase benefits as: trade fixed expense for variable expense, benefit from massive economies of scale, stop guessing capacity, increase speed and agility, stop spending money running data centres, go global in minutes.',
    types_h2='Three ways to define it', types_html=types_html, warn=warn,
    steps_h2='Proof that the cloud is real', steps_intro='All outputs are real: the public IP-range files published by AWS and Google Cloud, downloaded on 10 Nov 2026 with a short Python script.',
    steps=steps, two=two, peel_intro='Now peel one cloud request.', peel_html=pe,
    scen_intro='Three live scenarios: a festival spike, a startup in a day, and data that must stay in India.', scen=scen,
    uc_h2='Cloud around you', ucs=[uc_('stream', 'video', 'blue', '1. Streaming', 'Video apps serve millions from cloud CDNs.', ['Phone', '*Cloud CDN', 'Video']),
        uc_('upi', 'payments', 'green', '2. Payments', 'Banks and wallets scale for sale days.', ['App', '*Cloud', 'Bank']),
        uc_('mail', 'SaaS', 'amber', '3. Email & office', 'Gmail, Outlook: software as a service.', ['Browser', '*SaaS', 'Mail']),
        uc_('ai', 'AI', 'violet', '4. AI and big data', 'Train models on rented GPUs.', ['Data', '*Cloud GPUs', 'Model'])],
    uc_note='Examples are simplified descriptions of common practice.',
    pre='<b>Before you start:</b> nothing! This is the first lesson. Basic computer knowledge is enough; the <a href="../../../linux/">Linux course</a> helps for the hands-on parts.')
