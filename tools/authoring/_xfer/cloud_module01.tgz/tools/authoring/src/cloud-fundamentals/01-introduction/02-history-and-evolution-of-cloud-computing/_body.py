import os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', '..'))
from cloudkit import *
C = 'l12_history.txt'
def sec(a, b=None, drop=()):
    return capsec(C, a, b, drop)
B = '../../'
hk = hook('Who invented the cloud? Was it Amazon in 2006, or much older?',
    'The idea is from the 1960s (“computing as a utility”), the pieces came from mainframes, the internet, grid computing and virtualization, and the business arrived in 2006 when AWS rented storage (S3) and servers (EC2) by the hour. The AWS SDK today knows <b>436 services</b>; the oldest API it still carries is <b>S3 (2006-03-01)</b>, and about half of all services appeared between 2017 and 2020.',
    ['Six eras: mainframes → client-server → internet → grid/utility → virtualization → cloud.', 'Key dates for AWS, Azure and Google Cloud.', 'Where cloud is heading: serverless, edge, AI.'])
cmap = concept_map('Concept map. Beginner: timeline from mainframes to cloud. Intermediate: technologies that made cloud possible. Advanced: provider launches and the next eras.',
    [[('mf', 'Mainframes', '1950s–70s', None), ('cs', 'Client-server', '1980s–90s', None)],
     [('net', 'Internet + web', '1990s', None), ('grid', 'Grid / utility', '1990s–2000s', None), ('vz', 'Virtualization', 'VMware 1999', B + '04-virtualization/01-virtualization-and-hypervisors/'), ('saas', 'Early SaaS', 'Salesforce 1999', None)],
     [('aws', 'AWS 2006', 'S3, EC2', None), ('az', 'Azure 2010', 'Windows Azure', None), ('gcp', 'Google 2008', 'App Engine', None), ('next', 'Serverless · edge · AI', 'today', B + '03-deployment-models/04-cloud-vs-grid-vs-fog-vs-edge-computing/')]],
    [('mf', 'cs'), ('cs', 'net'), ('net', 'grid'), ('grid', 'vz'), ('net', 'saas'), ('vz', 'aws'), ('saas', 'aws'), ('aws', 'az'), ('aws', 'gcp'), ('aws', 'next')],
    {'net', 'grid', 'vz', 'saas', 'aws'},
    '<b>Before:</b> <a href="../01-what-is-cloud-computing/">1.1</a>. <b>Next:</b> <a href="../03-characteristics-and-advantages-of-cloud/">1.3 Characteristics and advantages</a>.')
whw = why_how_where(
    'History explains why the cloud looks the way it does: shared machines (from mainframes), pay-per-use (from utility computing), many small servers (from grid), slices of servers (from virtualization).',
    'Each era solved the previous era’s pain: mainframes were too expensive to own, PCs were too scattered to manage, data centres were idle most of the time, and virtualization let one machine be sold as many.',
    'Exam “evolution” questions, interviews, and choosing technology: old ideas (time-sharing, grids) return as new products (serverless, HPC on cloud).',
    'Dates for “first cloud” differ by source; we give the widely accepted milestones and mark the API dates as approximate.')
def timeline(hl=-1):
    ev = [('1960s', 'mainframe', 'time-sharing'), ('1990s', 'internet', 'web + grid'), ('1999', 'VMware,', 'Salesforce'), ('2006', 'AWS S3,', 'EC2'), ('2008', 'Google', 'App Engine'), ('2010', 'Azure', 'launch'), ('2014', 'Lambda', 'serverless'), ('2020s', 'AI +', 'edge')]
    o = '<line x1="14" y1="64" x2="346" y2="64" stroke="currentColor" class="s-ink2" stroke-width="2"/>'
    for i, (y, a, b) in enumerate(ev):
        r = i // 4; x = 50 + (i % 4) * 86; yy = 46 + r * 60
        o += box(x - 7, yy - 7, 14, 14, 'amber' if i == hl else ('acc' if i >= 3 else 'blue'), rx=7)
        o += t(x, yy - 12, y, 9, 'ink', bold=True) + t(x, yy + 19, a, 8, 'ink2') + t(x, yy + 29, b, 8, 'ink2')
    o = o.replace('<line x1="14" y1="64" x2="346" y2="64"', '<line x1="30" y1="46" x2="330" y2="46"') + '<line x1="30" y1="106" x2="330" y2="106" stroke="currentColor" class="s-ink2" stroke-width="2"/>'
    return o + t(180, 18, 'From shared mainframes to rented clouds', 8.2, 'ink', bold=True)
scene_svg = scene('A timeline: 1960s mainframe time-sharing, 1990s internet and grid, 1999 VMware and Salesforce, 2006 AWS S3 and EC2, 2008 Google App Engine, 2010 Azure, 2014 Lambda serverless, 2020s AI and edge.', timeline(3),
                  'The idea is 60 years old; <tspan font-weight="700" class="s-acc">the business started in 2006</tspan>.')
dialogue = '''R> Sir, my uncle says “cloud is just mainframes again”. Is he right?
A> Half right. In the 1960s many users shared one big computer and paid for time. The cloud brings that sharing back, but with millions of cheap servers, the internet and virtualization.
K> So what changed in 2006?
A> Amazon started renting S3 storage and EC2 servers to anyone with a card, by the hour. Let’s look at what grew from there, using AWS’s own SDK as evidence.'''
lv = '''
LEVELS> Cloud history at three levels
L1> From one big computer to rented computers
      <ul>
        <li>First, one huge computer was shared by many people. Then everyone got a PC. Then companies built server rooms. Now we rent servers from giant data centres over the internet.</li>
      </ul>
L2> Six eras
      <ul>
        <li><b>Mainframes + time-sharing</b> (1960s–70s), <b>client-server</b> (1980s–90s), <b>internet & web</b> (1990s), <b>grid and utility computing</b> (late 1990s–2000s), <b>virtualization</b> (VMware 1999, Xen 2003), <b>cloud</b> (AWS 2006 onward).</li>
        <li>1961: John McCarthy suggests computing could be sold “as a utility”. 1999: Salesforce sells CRM over the web (early SaaS).</li>
      </ul>
L3> The provider race
      <ul>
        <li>AWS: S3 (Mar 2006), EC2 (Aug 2006). Google App Engine (2008, PaaS first, then Compute Engine 2012). Windows Azure (2010, renamed Microsoft Azure 2014).</li>
        <li>Then: containers (Docker 2013, Kubernetes 2014), serverless (AWS Lambda 2014), managed data and AI services, edge computing, and generative-AI services in the 2020s.</li>
      </ul>
/LEVELS
'''
mm = mindmap('Mind map of cloud history: ideas, enabling technologies, early SaaS, providers, modern era, India.', 'Cloud history', [
    ('Ideas', 'blue', ['utility computing', 'time-sharing', 'McCarthy 1961']),
    ('Technologies', 'green', ['internet', 'virtualization', 'cheap servers']),
    ('Early SaaS', 'violet', ['Salesforce 1999', 'web email']),
    ('Providers', 'acc', ['AWS 2006', 'Google 2008', 'Azure 2010']),
    ('Modern era', 'amber', ['containers', 'serverless', 'AI services']),
    ('India', 'card', ['AWS Mumbai 2016', 'Hyderabad 2022', 'GCP Delhi 2021'])], h=290)
lay = layers('Evolution as layers: each era builds on the one below, from mainframe hardware at the bottom to AI services at the top.', [
    ('AI + edge services (2020s)', 'models, GPUs, edge locations', 'violet'), ('Serverless (2014→)', 'run code, no servers to manage', 'green'),
    ('Public cloud (2006→)', 'rent by the hour over the internet', 'acc'), ('Virtualization (1999→)', 'one server → many VMs', 'blue'),
    ('Internet + grid (1990s)', 'connect and share resources', 'card'), ('Mainframes (1960s)', 'one big shared computer', 'card')], hl=2, caption='Each era rests on the ones below it.')
DIS = figure('Dissection of one line of the SDK evidence: 2006-03-01 is the API version date of s3, the oldest API in botocore.',
    t(16, 22, 'One line of evidence (real)', 8.6, 'ink', anchor='start', bold=True) +
    fields(16, 34, [('2006-03-01', 'blue', 1), ('s3', 'green', 2), ('botocore 1.43', 'amber', 3), ('436 services', 'violet', 4)]) +
    legend(16, 84, [(1, 'API version date', 'when this API shape was fixed'), (2, 'Service', 'Simple Storage Service'), (3, 'Source', 'AWS SDK for Python'),
                    (4, 'Today', 'all services the SDK knows')], size=8, gap=15, w=90),
    h=156, caption='API dates are a rough timeline, not exact launch dates.')
extra = '\n\n  <h3>Evolution as layers</h3>\n' + lay + '\n\n  <h3>Dissect one line of evidence</h3>\n' + DIS
types_html = table(['Era', 'Years', 'Key idea', 'What the cloud kept from it'], [
    ['Mainframe', '1950s–1970s', 'one computer, many users, pay for time', 'sharing + metering'],
    ['Client-server / PC', '1980s–1990s', 'computers everywhere', 'standard hardware'],
    ['Internet & web', '1990s', 'connect everything', 'broad network access'],
    ['Grid / utility', 'late 1990s–2000s', 'pool many computers for big jobs', 'resource pooling, HPC'],
    ['Virtualization', '1999 →', 'split one server into many VMs', 'IaaS, multitenancy'],
    ['Cloud', '2006 →', 'self-service, on-demand, pay-as-you-go', 'everything as a service']], minw=620)
warn = 'Do not mix up “the first cloud” claims in interviews. Say: the utility idea is from the 1960s; early SaaS (Salesforce) from 1999; the modern public cloud began with AWS S3 and EC2 in 2006.'
steps = [
    ('Step 1 · How many AWS services today?', code('python', 'l12_history.py', 'svc = {folder names under botocore/data/<service>/<api-date>/service-2.json}\nlen(svc)', sec('== 1)', '== 2)')), 'The SDK every Python cloud tool uses knows 436 services.'),
    ('Step 2 · Growth over the years', code('python', 'l12_history.py', 'first = {s: min(api_dates)}\nCounter(year of first)', sec('== 2)', '== 3)')), 'Slow start (2006–2013), explosion 2014–2018 (containers, serverless, data, ML), steady since.'),
    ('Step 3 · The oldest APIs', code('python', 'l12_history.py', 'sorted(first.items(), key=date)[:6]', sec('== 3)', '== 4)')), 'S3 2006, EMR (Hadoop!) 2009, SNS, IAM, CloudFormation 2010. EC2/SQS have newer API versions, so they show later.'),
    ('Step 4 · Regions in the SDK', code('python', 'l12_history.py', 'endpoints.json → partition "aws" → regions', sec('== 4)')), 'India: Mumbai (2016) and Hyderabad (2022).'),
]
see = [term([('436 services', G), ('botocore 1.43.127', W)], size=7.0), term([('2017 +50', W), ('2018 +82', G)], size=7.0),
       term([('2006 s3', G), ('2009 emr', W)], size=7.0), term([('34 regions', W), ('Mumbai, Hyderabad', G)], size=7.0), term([('idea 1961', W), ('business 2006', G)], size=7.0)]
B1 = [timeline(i) for i in (7, 6, 3, 3, 0)]
B1 = [b + cap(c, '', tn, y=118, h=24) for b, c, tn in zip(B1, ['Today', 'Boom', 'S3 first', 'Regions', 'Old idea'], ['violet', 'green', 'acc', 'blue', 'amber'])]
two = anim_two('Cloud history', 'Sixty years in one line', 'Real outputs (AWS SDK data)', 'The timeline', see, B1, ['Count.', 'Growth.', 'Oldest.', 'Regions.', 'Idea.'], ['Now.', '2017–18.', '2006.', 'India.', '1961.'])
pe = peel('From a mainframe to a cloud VM', 'The same need, solved six times. (Simplified.)',
    [('Mainframe', ''), ('PC', ''), ('Server room', ''), ('Grid', ''), ('VM', ''), ('Cloud', '')],
    [['Mainframe', 'share one big', 'computer, pay time', ''], ['PC', 'own your own', 'small computer', ''], ['Server room', 'company buys', 'and runs servers', 'idle 70%'],
     ['Grid', 'pool servers', 'for big jobs', ''], ['VM', 'slice one server', 'into many', ''], ['Cloud', 'rent slices', 'by the hour', 'self-service']],
    ['Share.', 'Own.', 'Buy.', 'Pool.', 'Slice.', 'Rent.'], 'scenario-peel')
scen = five('Real-time scenario 1', 'A bank in 1975 vs 2026', 'Same job, two eras. (Typical.)', ('Utility model', 'Pay for use'), [
    ('1975: rent mainframe time', 'batch jobs at night', 'Then.', 'blue'), ('1995: own servers', 'big up-front cost', 'Then.', 'card'),
    ('2010: virtualized data centre', 'better use', 'Then.', 'green'), ('2026: cloud regions', 'Mumbai + Hyderabad', 'Now.', 'acc'),
    ('Pay per hour', 'like 1975, but self-service', 'Same idea.', 'amber')], ['1975.', '1995.', '2010.', '2026.', 'Utility.'], 'scenario-bank') + \
       five('Real-time scenario 2', 'Why AWS came first', 'Retailer’s idle servers. (Common story.)', ('Sell spare skill', 'Infrastructure as a product'), [
    ('Amazon builds for peak', 'holiday season', 'Need.', 'blue'), ('Learns to run huge DCs', 'cheaply', 'Skill.', 'green'),
    ('Packages it as APIs', 'S3, EC2', 'Product.', 'acc'), ('Startups rent it', 'no hardware', 'Market.', 'green'),
    ('Others follow', 'Google, Microsoft', 'Race.', 'amber')], ['Peak.', 'Skill.', 'APIs.', 'Startups.', 'Race.'], 'scenario-why') + \
       five('Real-time scenario 3 · advanced', 'Old idea, new name', 'Grid → serverless. (Typical.)', ('Patterns return', 'Recognise them'), [
    ('Grid: submit a job', 'cluster runs it', 'Old.', 'card'), ('Serverless: submit a function', 'cloud runs it', 'New.', 'green'),
    ('Time-sharing → per-ms billing', '', 'Metering.', 'amber'), ('Mainframe → managed DB', '', 'Central.', 'blue'),
    ('Exam: “evolution”', 'name the link', 'Answer.', 'violet')], ['Grid.', 'Serverless.', 'Billing.', 'Managed.', 'Exam.'], 'scenario-pattern')
clouds = vendor_tabs(
    '<p><b>AWS:</b> S3 (14 Mar 2006), SQS (2006), EC2 beta (Aug 2006), RDS (2009), Lambda (2014). India: Mumbai region 2016, Hyderabad 2022.</p>',
    '<p><b>Azure:</b> announced as “Windows Azure” in 2008, generally available 2010, renamed Microsoft Azure 2014. India: Pune, Chennai, Mumbai regions from 2015.</p>',
    '<p><b>Google Cloud:</b> App Engine (2008, PaaS), Cloud Storage (2010), BigQuery (2011), Compute Engine (2012/13). India: Mumbai 2017, Delhi 2021.</p>') + \
    cloud3([['First service', 'S3 storage (2006)', 'Windows Azure PaaS (2010)', 'App Engine PaaS (2008)'], ['Started as', 'IaaS', 'PaaS', 'PaaS'], ['Serverless', 'Lambda (2014)', 'Functions (2016)', 'Cloud Functions (2017 beta)'], ['First India region', 'Mumbai (2016)', 'Pune/Chennai/Mumbai (2015)', 'Mumbai (2017)']])
prac = practical('Find the evidence yourself. Needs Python 3 and pip; no cloud account.', [
    ('1 · Download the AWS SDK package', code('bash', 'terminal', 'pip download botocore --no-deps -d bc\nls bc'), 'A .whl file is just a zip.'),
    ('2 · Count the services', code('bash', 'terminal', "unzip -l bc/botocore-*.whl | grep -c 'service-2.json'"), 'Counts API versions (a bit more than services).'),
    ('3 · List Indian regions', code('bash', 'terminal', "unzip -p bc/botocore-*.whl botocore/data/endpoints.json | grep -A1 '\"ap-south'"), 'Mumbai and Hyderabad with descriptions.'),
    ('4 · Run the lesson script', code('bash', 'terminal', 'python3 l12_history.py'), 'Same as Steps 1–4 above (numbers change with new releases).')],
    cleanup='Delete the <code>bc</code> folder if you like: <code>rm -r bc</code>. No cloud resources were created.')
mist = mistakes([
    ['“Amazon invented cloud computing.”', 'AWS made it a mass business; ideas are older.', 'Say: utility idea 1960s, SaaS 1999, public IaaS cloud AWS 2006.'],
    ['Confusing grid and cloud.', 'Both pool many computers.', 'Grid: big shared jobs, usually research; cloud: on-demand self-service for anyone (Lesson 3.4).'],
    ['Thinking virtualization = cloud.', 'Cloud uses virtualization.', 'Virtualization is a technology; cloud is a service model with self-service and metering (Lesson 4.5).'],
    ['Old exam notes with retired names.', 'Products get renamed (Windows Azure → Microsoft Azure, Azure AD → Entra ID).', 'Check current names on the provider docs before exams.']])
cert = certbox([
    ['AWS CLF-C02', 'Domain 1 · Cloud Concepts', 'Benefits of the cloud vs traditional on-premises; history is not tested directly but the “why” is.'],
    ['Azure AZ-900', 'Describe cloud concepts', 'Cloud computing and its benefits; names like Microsoft Entra ID (old Azure AD).'],
    ['Google Cloud Digital Leader', 'Digital transformation', 'Why organisations modernise: from on-prem to cloud.'],
    ['C-DAC PGCP-BDA', 'Cloud Session 2', 'Introduction to cloud paradigms.']],
    [('Which technology most directly made IaaS possible? (a) SQL (b) virtualization (c) HTML (d) email', '<b>(b) virtualization</b>: one physical server can be sold as many isolated VMs.'),
     ('Utility computing means…', 'Paying for computing like electricity: metered, on demand.')])
proj = miniproject('Mini project: cloud history timeline page',
    'Make a one-page HTML timeline of cloud history with real data from the SDK.',
    ['Run <code>l12_history.py</code> and save the output: <code>python3 l12_history.py &gt; history.txt</code>.', 'Write a small Python script that turns the year counts into an HTML bar chart (<code>&lt;div style="width:Npx"&gt;</code>).',
     'Add 8 milestones from this lesson as a list.', 'Open it in a browser; later (AWS course, S3 static website) host it on the cloud.'],
    'An HTML page with growth bars 2006–2026 and milestones.', 'Python, HTML, and later AWS S3 website hosting.')
assemble_cloud(HERE, interview=['“Cloud computing evolved from 1960s mainframe time-sharing and the idea of utility computing, through client-server, the internet, grid computing and virtualization.”', '“The modern public cloud started in 2006 when AWS launched S3 and EC2; Google App Engine followed in 2008 and Microsoft Azure in 2010.”', '“Since then it moved to containers, serverless (Lambda 2014) and now AI and edge services.”'], clouds_html=clouds, practical_html=prac, mistakes_html=mist, cert_html=cert, project_html=proj, mindmap_html=mm,
    h2_story='Is the cloud just mainframes again?', hook_html=hk,
    narration='Riya’s uncle worked on a bank mainframe in the 1980s. He says the cloud is nothing new. Riya wants to know what really changed.',
    scene_svg=scene_svg, dialogue=dialogue, def_h2='History and evolution of cloud computing',
    formal='The <b>evolution of cloud computing</b> runs from 1960s mainframe time-sharing and the idea of <b>utility computing</b>, through client-server computing, the internet, grid computing and hardware <b>virtualization</b>, to on-demand public clouds (AWS 2006, Google App Engine 2008, Microsoft Azure 2010) and today’s serverless, container, edge and AI services.',
    simple='People first shared one big computer, then each owned one, then companies built server rooms, and now everyone rents slices of giant data centres over the internet.',
    term_rows=[('Mainframe', 'Big central computer.'), ('Time-sharing', 'Many users, one computer.'), ('Utility computing', 'Metered like electricity.'), ('Grid computing', 'Pooling computers for big jobs.'), ('Virtualization', 'Many VMs on one server.'), ('SaaS', 'Software over the web.'), ('Serverless', 'Run code, no servers to manage.'), ('API version', 'Date stamp of a service API.')],
    whw=whw, cmap=cmap, extra_def=extra, lv=lv,
    myth_rows=[('Cloud is a 2006 invention.', 'Idea from 1961; business from 2006.', 'Levels.'), ('AWS has a handful of services.', '436 in the SDK.', 'Step 1.'), ('Growth was steady.', '2017–2018 added 132.', 'Step 2.')],
    exam='Remember the enabling technologies (internet, virtualization, cheap hardware, web services/APIs) and the milestones: Salesforce 1999 (SaaS), AWS S3/EC2 2006 (IaaS), Google App Engine 2008 (PaaS), Azure 2010, Lambda 2014 (serverless).',
    types_h2='Six eras of computing', types_html=types_html, warn=warn,
    steps_h2='Evidence from the AWS SDK', steps_intro='All outputs are real: botocore 1.43.127 (the AWS SDK for Python) downloaded on 10 Nov 2026. API dates are approximate launch indicators.',
    steps=steps, two=two, peel_intro='Now peel sixty years.', peel_html=pe, scen_intro='Three scenarios across eras.', scen=scen,
    uc_h2='Old ideas in today’s cloud', ucs=[uc_('share', 'pooling', 'blue', '1. Sharing', 'Time-sharing → multitenancy.', ['Mainframe', '*Cloud', 'Tenants']),
        uc_('meter', 'billing', 'green', '2. Metering', 'Pay per CPU second.', ['1960s', '*Lambda', 'Per ms']),
        uc_('grid', 'HPC', 'amber', '3. Grid → HPC', 'Science on cloud clusters.', ['Grid', '*Cloud HPC', 'Results']),
        uc_('saas', 'SaaS', 'violet', '4. Web software', 'Salesforce → every app.', ['1999', '*SaaS', 'Today'])],
    uc_note='Dates are the commonly cited milestones.', pre='<b>Before you start:</b> <a href="../01-what-is-cloud-computing/">1.1 What is cloud computing?</a>')
