import os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', '..'))
from cloudkit import *
C = 'l13_measured.txt'
def sec(a, b=None, drop=()):
    return capsec(C, a, b, drop)
B = '../../'
hk = hook('“Pay only for what you use” — how exactly does the cloud measure that, and what does it cost?',
    'Every resource has a meter, and AWS publishes the price list as JSON. In Mumbai today: S3 storage <b>$0.025 per GB-month</b>, a request <b>$0.000005</b>, a t3.micro virtual machine <b>$0.0112 per hour</b>. TiffinGo’s 500 GB of menu photos cost about <b>$13.50 a month</b>; a 2-hour lab on a t3.medium costs <b>$0.09</b>. Delete them, and the bill stops.',
    ['The five NIST characteristics, one by one, with proof.', 'Six AWS advantages and how exams phrase them.', 'Reading a real cloud price list.'])
cmap = concept_map('Concept map. Beginner: five characteristics. Intermediate: six advantages. Advanced: price list, pricing models, economies of scale.',
    [[('wc', 'What is cloud', 'Lesson 1.1', B + '01-introduction/01-what-is-cloud-computing/'), ('hi', 'History', 'Lesson 1.2', B + '01-introduction/02-history-and-evolution-of-cloud-computing/')],
     [('od', 'On-demand', 'self-service', None), ('bn', 'Broad network', 'any device', None), ('rp', 'Pooling', 'multitenant', None), ('re', 'Elasticity', 'scale in/out', None)],
     [('ms', 'Measured', 'price list', None), ('adv', '6 advantages', 'AWS wording', None), ('ch', 'Challenges', 'Lesson 1.4', B + '01-introduction/04-challenges-and-limitations-of-cloud/'), ('pm', 'Pricing models', 'Lesson 5.5', B + '05-core-cloud-concepts/05-cloud-pricing-models/')]],
    [('wc', 'od'), ('hi', 'rp'), ('od', 'bn'), ('rp', 're'), ('re', 'ms'), ('ms', 'adv'), ('adv', 'ch'), ('ms', 'pm')],
    {'od', 'bn', 'rp', 're', 'ms', 'adv'},
    '<b>Next:</b> <a href="../04-challenges-and-limitations-of-cloud/">1.4 Challenges and limitations</a>.')
whw = why_how_where(
    'Exams and interviews ask the five characteristics and six advantages almost word for word; managers decide cloud vs own servers on these benefits.',
    'Self-service portals and APIs give on-demand access; data centres are reached over the internet; virtualization pools hardware; auto scaling adds and removes capacity; meters record every GB, hour and request into a bill.',
    'Startups (speed), seasonal businesses (elasticity), global apps (go global in minutes), analytics (big compute for a short time).',
    'Benefits only appear if you use them: forgotten resources, wrong sizes and data transfer can erase savings.')
def meters(hl=-1):
    items = [('Storage', '$0.025/GB-mo', 'blue'), ('Requests', '$0.005/1,000', 'green'), ('VM t3.micro', '$0.0112/h', 'violet'), ('VM t3.medium', '$0.0448/h', 'acc')]
    o = t(180, 16, 'Every resource has a meter (AWS Mumbai, real prices)', 8.2, 'ink', bold=True)
    for i, (a, p, tn) in enumerate(items):
        x = 14 + i * 86
        o += box(x, 28, 76, 70, 'amber' if i == hl else tn, rx=8)
        o += f'<circle cx="{x + 38}" cy="56" r="16" style="fill:none;stroke:currentColor" class="s-ink2" stroke-width="1.5"/><line x1="{x + 38}" y1="56" x2="{x + 48}" y2="46" stroke="#D64545" stroke-width="2"/>'
        o += t(x + 38, 84, a, 7.6, 'ink', bold=True) + t(x + 38, 94, p, 7, 'ink2')
    return o + t(180, 128, 'Bill = Σ (usage × price). Delete → meter stops.', 8.4, 'ink', bold=True)
scene_svg = scene('Four meters: S3 storage 0.025 dollars per GB-month, requests 0.005 dollars per thousand, t3.micro 0.0112 dollars per hour, t3.medium 0.0448 dollars per hour.', meters(),
                  'Real Mumbai prices from AWS’s public price list, 9 Nov 2026.')
dialogue = '''K> Sir, the finance team doesn’t trust “pay only for what you use”. They want numbers.
A> Good! AWS publishes every price as a file. We will read the Mumbai price list ourselves and calculate TiffinGo’s photo bill.
R> And the five characteristics from 1.1 — will we see each one?
A> Yes, one by one, and the six advantages exams love. Let’s go.'''
lv = '''
LEVELS> Characteristics and advantages at three levels
L1> Like a mobile prepaid plan
      <ul>
        <li>You recharge yourself (on-demand), use it anywhere (network access), share towers with millions (pooling), upgrade data for a weekend (elasticity), and see exact usage in the app (measured).</li>
      </ul>
L2> The five NIST characteristics
      <ul>
        <li><b>On-demand self-service:</b> get resources without calling anyone. <b>Broad network access:</b> through standard networks from phones, laptops, servers.</li>
        <li><b>Resource pooling:</b> provider hardware is shared by many tenants, location-independent. <b>Rapid elasticity:</b> scale out and in, seemingly unlimited. <b>Measured service:</b> usage metered, reported, billed.</li>
      </ul>
L3> The six advantages (AWS wording)
      <ul>
        <li>Trade fixed (capital) expense for variable expense · benefit from massive economies of scale · stop guessing capacity · increase speed and agility · stop spending money running and maintaining data centres · go global in minutes.</li>
        <li>Other lists add: high availability, reliability, security tooling, sustainability (shared efficient data centres), innovation (managed AI, analytics).</li>
      </ul>
/LEVELS
'''
mm = mindmap('Mind map: five NIST characteristics and six advantages of cloud computing, plus extra benefits and the price list.', 'Cloud benefits', [
    ('NIST traits', 'blue', ['self-service', 'network access', 'pooling', 'elasticity', 'measured']),
    ('Money', 'green', ['CapEx → OpEx', 'economies of scale', 'no data centre']),
    ('Speed', 'violet', ['agility', 'minutes not weeks', 'experiment cheaply']),
    ('Scale', 'acc', ['stop guessing', 'auto scaling', 'go global']),
    ('Extras', 'card', ['availability', 'security tools', 'sustainability']),
    ('Proof', 'amber', ['price list JSON', '$0.025/GB-mo', '$0.0112/h'])], h=290)
lay = layers('How a bill is built in layers: usage records from meters, rated by the price list, summed per service, minus credits and discounts, gives your invoice.', [
    ('Invoice', 'what you pay this month', 'acc'), ('Credits / discounts', 'free tier, savings plans', 'green'),
    ('Per service totals', 'EC2, S3, data transfer…', 'violet'), ('Rating', 'usage × price list (JSON)', 'blue'),
    ('Usage records', 'GB-hours, requests, VM-seconds', 'card'), ('Meters on every resource', 'measured service', 'card')], hl=3, caption='Measured service, from meter to invoice.')
DIS = figure('Dissection of one price: 0.025 US dollars per GB-month for S3 Standard storage in ap-south-1, first 50 TB tier.',
    t(16, 22, 'One price from the AWS price list (real)', 8.6, 'ink', anchor='start', bold=True) +
    fields(16, 34, [('$0.025', 'blue', 1), ('GB-Mo', 'green', 2), ('0–51200 GB', 'amber', 3), ('ap-south-1', 'violet', 4)]) +
    legend(16, 84, [(1, 'Price', 'US dollars'), (2, 'Unit', 'one GB stored for a month'), (3, 'Tier', 'cheaper above 50 TB'), (4, 'Region', 'prices differ by region')], size=8, gap=15, w=90),
    h=156, caption='Volume tiers = economies of scale passed to you.')
extra = '\n\n  <h3>From meter to invoice</h3>\n' + lay + '\n\n  <h3>Dissect one price</h3>\n' + DIS
types_html = table(['Characteristic', 'Means', 'Real example'], [
    ['On-demand self-service', 'you create resources yourself, any time', 'launch a VM from the console in 2 minutes'],
    ['Broad network access', 'reach it over standard networks and devices', 'manage AWS from the mobile app'],
    ['Resource pooling', 'shared physical resources, multi-tenant', 'many customers’ VMs on one server'],
    ['Rapid elasticity', 'scale out/in quickly, looks unlimited', 'Diwali: 3 → 12 servers'],
    ['Measured service', 'usage metered and billed', '$0.0112 per VM-hour, per-second billing']], minw=600)
warn = 'Elasticity is not automatic: you must configure auto scaling (AWS course 3.4). And measured service works both ways: an idle VM still shows on the meter every hour.'
steps = [
    ('Step 1 · The price list is public', code('python', 'l13_measured.py', 'u = "https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/AmazonS3/current/ap-south-1/index.json"\nd = json.load(urlopen(u))', sec('== 1)', '== 2)')), 'Anyone can download it: measured service is transparent.'),
    ('Step 2 · Storage price tiers', code('python', 'l13_measured.py', 'products where volumeType == "Standard" → OnDemand price dimensions', sec('== 2)', '== 3)')), 'The more you store, the cheaper per GB: economies of scale.'),
    ('Step 3 · Even requests are metered', code('python', 'l13_measured.py', 'usagetype == "APS3-Requests-Tier1"', sec('== 3)', '== 4)')), 'Half a paisa per 1,000 uploads — tiny, but counted.'),
    ('Step 4 · TiffinGo’s photo bill', code('python', 'l13_measured.py', '500 * storage_price + 200000 * request_price', sec('== 4)', '== 5)')), 'About $13.50/month, no hardware bought.'),
    ('Step 5 · Virtual machines by the hour', code('python', 'l13_measured.py', 'EC2 ap-south-1 price file (315 MB) → Linux, shared, on-demand', sec('== 5)')), 'Bigger machine, higher hourly price; a 2-hour lab costs cents.'),
]
see = [term([('380 S3 products', W), ('2026-11-09', W)], size=7.0), term([('$0.025 / GB-mo', G), ('$0.023 > 512 TB', G)], size=7.0), term([('$0.000005 / req', W)], size=7.0),
       term([('storage $12.50', W), ('total $13.50', G)], size=7.0), term([('t3.micro $0.0112/h', W), ('2 h lab $0.09', G)], size=7.0)]
B1 = [meters(i) for i in (-1, 0, 1, 0, 3)]
B1 = [b + cap(c, '', tn, y=136, h=24) for b, c, tn in zip(B1, ['Public', 'Tiers', 'Requests', 'Bill', 'Per hour'], ['blue', 'green', 'green', 'acc', 'violet'])]
two = anim_two('Measured service', 'Reading a real price list', 'Real outputs (AWS price list)', 'Meters', see, B1, ['Public.', 'Tiers.', 'Requests.', 'Bill.', 'VMs.'], ['Open.', 'Scale.', 'Tiny.', '$13.50.', 'Hourly.'])
pe = peel('Elasticity, layer by layer', 'What happens when Diwali orders arrive. (Simplified.)',
    [('Metric', ''), ('Alarm', ''), ('Policy', ''), ('Launch', ''), ('Register', ''), ('Shrink', '')],
    [['Metric', 'CPU 80%', 'on 3 servers', ''], ['Alarm', 'above target', 'for 3 min', ''], ['Policy', 'add 2 servers', 'up to 12', ''],
     ['Launch', 'new VMs', 'from template', 'minutes'], ['Register', 'load balancer', 'sends traffic', ''], ['Shrink', 'CPU 20%', 'remove extras', 'save']],
    ['Watch.', 'Alarm.', 'Decide.', 'Launch.', 'Serve.', 'Scale in.'], 'scenario-peel')
scen = five('Real-time scenario 1', 'Exam results day', 'Traffic ×20 for one day. (Typical.)', ('Elasticity', 'Scale out, then in'), [
    ('Normal: 2 servers', '', 'Before.', 'blue'), ('Results at 10 am', 'traffic ×20', 'Spike.', 'red'),
    ('Auto scaling → 30', 'minutes', 'Grow.', 'green'), ('Evening → 2', '', 'Shrink.', 'green'), ('Paid for 1 busy day', '', 'Measured.', 'amber')], ['Normal.', 'Spike.', 'Grow.', 'Shrink.', 'Pay.'], 'scenario-results') + \
       five('Real-time scenario 2', 'Go global in minutes', 'Expanding to Dubai. (Typical.)', ('Regions', 'Deploy where users are'), [
    ('Users in UAE', 'slow from Mumbai', 'Need.', 'blue'), ('Pick me-central-1', 'UAE region', 'Place.', 'green'),
    ('Same template', 'deploy again', 'Copy.', 'green'), ('DNS routes by location', '', 'Route.', 'acc'), ('Live in a day', 'no new office', 'Global.', 'amber')], ['Need.', 'Region.', 'Deploy.', 'Route.', 'Live.'], 'scenario-global') + \
       five('Real-time scenario 3 · advanced', 'Experiment cheaply', 'Try a big ML model. (Typical.)', ('Agility', 'Rent, test, delete'), [
    ('Need 8 GPUs', 'for 6 hours', 'Need.', 'blue'), ('Rent GPU VMs', 'on demand', 'Start.', 'green'),
    ('Train + test', '', 'Work.', 'green'), ('Delete', 'meter stops', 'Stop.', 'amber'), ('Cost: hours, not a ₹1 crore purchase', '', 'Agility.', 'violet')], ['Need.', 'Rent.', 'Train.', 'Delete.', 'Cheap.'], 'scenario-gpu')
clouds = vendor_tabs(
    '<p><b>AWS</b> lists six advantages (trade CapEx for variable expense, economies of scale, stop guessing capacity, speed and agility, stop running data centres, go global in minutes). Price list: AWS Price List bulk JSON and the Pricing Calculator.</p>',
    '<p><b>Azure</b> (AZ-900) groups benefits as high availability, scalability (vertical/horizontal), elasticity, reliability, predictability (performance + cost), security, governance and manageability. Prices: Azure Retail Prices API and Pricing Calculator.</p>',
    '<p><b>Google Cloud</b> stresses speed of innovation, data and AI, sustainability (carbon-free energy goal) and per-second billing with sustained-use discounts. Prices: Cloud Billing Catalog API and Pricing Calculator.</p>') + \
    cloud3([['Price calculator', 'AWS Pricing Calculator', 'Azure Pricing Calculator', 'Google Cloud Pricing Calculator'], ['Public price API', 'Price List API / bulk JSON', 'Retail Prices API', 'Cloud Billing Catalog API'], ['VM billing', 'per second (Linux, min 60 s)', 'per second', 'per second (min 1 min)'], ['Auto scaling', 'EC2 Auto Scaling', 'VM Scale Sets', 'Managed instance groups']])
prac = practical('Read a real price list and estimate a bill. No account needed.', [
    ('1 · Download the S3 Mumbai price list', code('bash', 'terminal', 'curl -s -o s3.json https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/AmazonS3/current/ap-south-1/index.json\nls -lh s3.json'), 'About 0.5 MB.'),
    ('2 · Find the storage price with jq', code('bash', 'terminal', "jq -r '.products[] | select(.attributes.volumeType==\"Standard\" and .attributes.storageClass==\"General Purpose\") | .sku' s3.json"), 'Copy the SKU, then look it up under .terms.OnDemand.'),
    ('3 · Run the lesson script', code('bash', 'terminal', 'python3 l13_measured.py'), 'Matches Steps 1–4 (prices may change).'),
    ('4 · Cross-check in the AWS Pricing Calculator', '<p>Open <code>calculator.aws</code> → Add service → S3 → region Asia Pacific (Mumbai) → 500 GB Standard, 200,000 PUT requests.</p>', 'Should be close to $13.50/month.'),
    ('5 · Try Azure and Google calculators', '<p>Same 500 GB in Azure Blob (Central India, Hot) and Google Cloud Storage (asia-south1, Standard).</p>', 'Write the three numbers in a table: your first cloud comparison.')],
    cleanup='Nothing to clean: price files are public. Never paste real account IDs or keys into public calculators’ shared links.')
prac = prac.replace('<ol class="stepper">', caution('Prices in this lesson are list prices in US dollars on 9–10 Nov 2026, before tax and without free tier. Always check the calculator for today’s numbers.') + '<ol class="stepper">', 1)
mist = mistakes([
    ['Mixing up elasticity and scalability.', 'Both talk about size.', 'Scalability = can grow to handle more; elasticity = grows and shrinks automatically with demand.'],
    ['Forgetting that idle resources are still metered.', 'Measured service counts time, not work.', 'Stop or delete after use; schedule dev servers off at night.'],
    ['Ignoring data transfer cost.', 'Uploading is usually free, downloading/out to internet is not.', 'Check “Data transfer out” in the calculator.'],
    ['Comparing prices across regions blindly.', 'Prices differ by region.', 'Compare the same region; pick Indian regions for Indian users.'],
    ['Quoting the six advantages in your own words in the exam.', 'Options use AWS’s exact wording.', 'Memorise the six phrases.']])
cert = certbox([
    ['AWS CLF-C02', 'Domain 1 · Cloud Concepts (24%)', 'The six advantages; economies of scale; elasticity vs scalability; agility.'],
    ['AWS CLF-C02', 'Domain 4 · Billing & Pricing (12%)', 'Pay-as-you-go, Pricing Calculator, price varies by region.'],
    ['Azure AZ-900', 'Describe the benefits of using cloud services', 'High availability, scalability, elasticity, reliability, predictability, security, governance, manageability.'],
    ['Google Cloud Digital Leader', 'Digital transformation', 'Total cost of ownership, agility, innovation.'],
    ['C-DAC PGCP-BDA', 'Cloud Session 2', 'Characteristics and benefits.']],
    [('A company no longer buys servers for its peak season and instead adds capacity automatically. Which advantage? (a) go global in minutes (b) stop guessing capacity (c) economies of scale', '<b>(b) Stop guessing capacity</b> (elasticity).'),
     ('Lower prices because AWS buys hardware for millions of customers is…', '<b>Benefit from massive economies of scale.</b>'),
     ('Azure: the ability to automatically add and remove resources based on demand is…', '<b>Elasticity</b> (scalability is the ability to grow).')])
proj = miniproject('Mini project: three-cloud storage bill calculator',
    'A command-line Python tool that asks for GB and requests and prints the monthly bill in AWS Mumbai using the live price list.',
    ['Start from <code>l13_measured.py</code>; read GB and requests with <code>input()</code>.', 'Cache the JSON file locally so you download it once a day.', 'Add Azure and Google prices by hand (from their calculators) as a dictionary.', 'Print a table of the three clouds and the cheapest.', 'Bonus: wrap it as a shell script <code>bill 500 200000</code> (Shell scripting course).'],
    'A table like “AWS $13.50 · Azure $x · GCP $y”.', 'Python + JSON, cloud pricing, shell scripting.')
assemble_cloud(HERE, interview=['“The five essential characteristics are on-demand self-service, broad network access, resource pooling, rapid elasticity and measured service.”', '“The main advantages are paying for what you use instead of up-front capital, economies of scale, no capacity guessing thanks to elasticity, speed and agility, no data-centre maintenance, and going global in minutes.”', '“For example, S3 in Mumbai charges about 2.5 cents per GB per month, so you only pay for what you store.”'],
    clouds_html=clouds, practical_html=prac, mistakes_html=mist, cert_html=cert, project_html=proj, mindmap_html=mm,
    h2_story='Finance wants proof of “pay only for what you use”', hook_html=hk,
    narration='TiffinGo wants to move its 500 GB of menu photos to the cloud. The finance team asks: what exactly will we pay, and why is that better than buying a storage box?',
    scene_svg=scene_svg, dialogue=dialogue, def_h2='Characteristics and advantages of cloud computing',
    formal='NIST lists five <b>essential characteristics</b> of cloud computing: <b>on-demand self-service</b>, <b>broad network access</b>, <b>resource pooling</b> (multi-tenant, location-independent), <b>rapid elasticity</b> and <b>measured service</b>. Providers describe the resulting <b>advantages</b> as variable instead of capital expense, economies of scale, elastic capacity, agility, no data-centre operations and global reach.',
    simple='You help yourself, from anywhere, to shared machines that grow and shrink with your needs, and a meter charges you only for what you used.',
    term_rows=[('Self-service', 'Create without asking anyone.'), ('Elasticity', 'Grow and shrink automatically.'), ('Scalability', 'Ability to handle more.'), ('Economies of scale', 'Cheaper per unit at huge size.'), ('Agility', 'Speed to try and deliver.'), ('GB-month', 'One GB stored for a month.'), ('Price list API', 'Public prices as data.'), ('Tier', 'Price band by volume.')],
    whw=whw, cmap=cmap, extra_def=extra, lv=lv,
    myth_rows=[('Cloud prices are secret.', 'Published as JSON.', 'Step 1.'), ('Requests are free.', '$0.000005 each.', 'Step 3.'), ('A small VM is expensive.', '$0.0112/h for t3.micro.', 'Step 5.')],
    exam='Exam favourites: “stop guessing capacity” = elasticity; “trade capital expense for variable expense” = pay-as-you-go; “benefit from massive economies of scale” = lower unit prices; AZ-900 adds reliability, predictability, governance and manageability.',
    types_h2='Five characteristics with examples', types_html=types_html, warn=warn,
    steps_h2='Reading AWS’s real price list', steps_intro='All outputs are real: AWS Price List bulk files for ap-south-1 (Mumbai), published 9 Nov 2026, downloaded 10 Nov 2026.',
    steps=steps, two=two, peel_intro='Now peel elasticity.', peel_html=pe, scen_intro='Three live scenarios: results day, going global, a GPU experiment.', scen=scen,
    uc_h2='Advantages in real businesses', ucs=[uc_('sale', 'elastic', 'blue', '1. Sale days', 'E-commerce scales for big sales.', ['Traffic', '*Auto scaling', 'Orders']),
        uc_('start', 'agility', 'green', '2. Startups', 'Launch in days.', ['Idea', '*Cloud', 'Product']),
        uc_('glob', 'global', 'amber', '3. Expansion', 'New country, new region.', ['India', '*Region', 'World']),
        uc_('ml', 'GPU', 'violet', '4. AI research', 'Rent GPUs for hours.', ['Data', '*GPUs', 'Model'])],
    uc_note='Examples are simplified descriptions of common practice.', pre='<b>Before you start:</b> <a href="../01-what-is-cloud-computing/">1.1</a>.')
