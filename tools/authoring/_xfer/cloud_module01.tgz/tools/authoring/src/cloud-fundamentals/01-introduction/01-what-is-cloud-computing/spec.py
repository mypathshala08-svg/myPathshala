import os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "..", "..", ".."))
sys.path.insert(0, os.path.join(HERE, "..", ".."))
from svgkit import scn
BODY = body(HERE)
META = dict(module='01-introduction', lesson='01-what-is-cloud-computing', n='1.1', module_label='Module 1 · Introduction to cloud computing',
    title='What is cloud computing?',
    desc='Cloud computing from zero: the NIST definition with its five characteristics, three service models and four deployment models, the layers of a cloud, AWS vs Azure vs Google Cloud, a hands-on look at real cloud infrastructure, common mistakes and exam questions for AWS CLF-C02, AZ-900 and Cloud Digital Leader.',
    og_desc='42 AWS regions, 10,744 IP ranges and a Diwali crash: what cloud computing really is, with real data and exam tips.',
    minutes=22, level='Beginner',
    lead='Cloud computing means <b>renting</b> computers, storage and software over the internet and paying only for what you use. We learn the NIST definition, see the layers, prove the cloud is real hardware with <b>real data</b>, compare AWS, Azure and Google Cloud, and finish with exam questions and a mini project.',
    chips=['NIST 5 characteristics', 'AWS · Azure · GCP', 'CLF-C02 · AZ-900 · CDL', 'Runs in your browser (Python)'])
MAIN = '''# Own servers vs cloud for one festival year (simplified, rupees)
daily_orders = [3000] * 350 + [12000] * 15          # 15 festival days
per_server = 1000                                    # orders one server handles per day
own_servers = max(daily_orders) // per_server        # must buy for the peak
own_cost = own_servers * 90000                       # buy once (per year share)
cloud_cost = sum(-(-d // per_server) * 250 for d in daily_orders)   # 250 per server-day
print("own servers:", own_servers, " cost:", own_cost)
print("cloud server-days:", sum(-(-d // per_server) for d in daily_orders), " cost:", cloud_cost)
print("cheaper:", "cloud" if cloud_cost < own_cost else "own")
'''
RUN = dict(heading='Run the code: own vs cloud for a festival year', intro='<p>A simplified cost model. Press <b>Run</b>, then try the challenges.</p>', code=MAIN,
    anno=[('own_servers = max(daily_orders) // per_server        # must buy for the peak', 'Owned capacity must cover the busiest day.'), ('cloud_cost = sum(-(-d // per_server) * 250 for d in daily_orders)   # 250 per server-day', 'Cloud: pay per server per day actually used.')],
    tasks=[dict(label='1 · Run it', hint='Press <b>Run</b>.', code=None),
        dict(label='2 · Predict first: steady load', hint='<b>Predict first:</b> no festival, 3000 orders every day. Which is cheaper?', code='d = [3000] * 365\nown = 3 * 90000\ncloud = sum(3 * 250 for _ in d)\nprint(own, cloud, "cloud" if cloud < own else "own")\n'),
        dict(label='3 · Five traits', hint='List NIST’s five characteristics.', code='traits = ["on-demand self-service", "broad network access", "resource pooling", "rapid elasticity", "measured service"]\nfor i, t in enumerate(traits, 1):\n    print(i, t)\n'),
        dict(label='4 · Classify', hint='Service model of each product.', code='m = {"Gmail": "SaaS", "EC2 VM": "IaaS", "App Engine": "PaaS"}\nfor k, v in m.items():\n    print(f"{k:10} {v}")\n'),
        dict(label='5 · Spot the error', hint='A forgotten VM.', expect='error', code='running_hours = 24 * 30\nbudget_alert = None\nif budget_alert is None and running_hours > 100:\n    raise RuntimeError("VM left running 720 h with no budget alert: set alerts and delete after labs")\n')])
RUN['tasks'][0]['code'] = RUN['code']
PCRUN = dict(heading='Run on your PC', intro='<p>Any computer with Python 3 and internet. <b>Outputs are real.</b></p>',
    items=[dict(title='1 · Run the lab', cmd='python3 l11_cloud_is_real.py', file='terminal', output='  regions in the file: 42', note='Numbers grow over time.'),
           dict(title='2 · One-liner', cmd="curl -s https://ip-ranges.amazonaws.com/ip-ranges.json | jq '.prefixes | length'", file='terminal', output='10744', note='Needs jq.')])
TRACE = dict(heading='Elasticity step by step', intro='<p>Servers follow orders.</p>',
    code='orders = [3000, 12000, 3000]\nfor o in orders:\n    servers = -(-o // 1000)\n    print(o, "orders ->", servers, "servers")\n', notes={3: 'Ceiling :: round up servers.'})
WORKED_INTRO = 'Three “is this cloud?” decisions.'
EXAMPLES = [
    dict(level='b', tag='NIST', title='Is it cloud?', problem='<p>A company rents a fixed server for 3 years, booked by email, fixed monthly fee.</p>', inp='traits',
         approach=['On-demand? No (email).', 'Elastic? No.', 'Measured? No.'], code='print("hosting, not cloud: missing on-demand, elasticity, metering")\n', notes={1: 'Traditional hosting.'}, tryit='Levels: NIST.'),
    dict(level='i', tag='benefit', title='Name the benefit', problem='<p>Startup launched in a week without buying hardware.</p>', inp='story',
         approach=['No up-front cost.', 'Fast to start.', 'Benefit: agility + OpEx.'], code='print(["speed and agility", "trade CapEx for OpEx"])\n', notes={1: 'Exam wording.'}, tryit='Exam tip.'),
    dict(level='a', tag='region', title='Choose a place', problem='<p>Indian bank, data must stay in India.</p>', inp='rule',
         approach=['Indian region.', 'Second Indian region for backup.', 'Encrypt.'], code='print({"aws": ["ap-south-1", "ap-south-2"], "gcp": ["asia-south1", "asia-south2"]})\n', notes={1: 'Real region codes.'}, tryit='Step 3.')]
QUIZ = mix([
    dict(q='Beginner: Cloud computing mainly means…', options=['Buying servers', 'Renting IT resources over the internet', 'Using only Google Drive', 'Offline software'], answer=1, why='Rent, on demand, pay per use.'),
    dict(q='Beginner: Which is a NIST characteristic?', options=['Open source', 'Rapid elasticity', 'Free forever', 'Single tenant'], answer=1, why='One of five.'),
    dict(q='Beginner: AWS Mumbai region code is…', options=['us-east-1', 'ap-south-1', 'asia-south1', 'in-west-1'], answer=1, why='Step 1.'),
    dict(q='Intermediate: Pay only for what you use is…', options=['Resource pooling', 'Measured service', 'Broad network access', 'Self-service'], answer=1, why='Metering.'),
    dict(q='Intermediate: Many customers sharing the same hardware is…', options=['Elasticity', 'Resource pooling', 'Measured service', 'SaaS'], answer=1, why='Pooling.'),
    dict(q='Intermediate: Google Cloud Delhi region is…', options=['asia-south1', 'asia-south2', 'ap-south-2', 'centralindia'], answer=1, why='Step 3.'),
    dict(q='Advanced: “Trade capital expense for variable expense” means…', options=['Buy more servers', 'Pay as you go instead of up front', 'Pay a fixed fee', 'Use only free tier'], answer=1, why='CapEx → OpEx.'),
    dict(q='Advanced: Steady 24×7 load all year is…', options=['Always cheapest on demand', 'Often cheaper with reserved/savings pricing or owned servers', 'Free', 'Not allowed'], answer=1, why='Run the challenge.')])
REVISION = ['Cloud = on-demand IT resources over the internet, pay as you go.', 'NIST: 5 characteristics, 3 service models, 4 deployment models.',
    'Layers: device → internet → console/CLI/API → services → virtualization → data centres.', 'Real: AWS 42 regions, 10,744 IPv4 ranges; Google 48 regions; India: ap-south-1/2, asia-south1/2.', 'Always: budget alert, right region, clean up.']
FAQ = [('Is the cloud safe?', 'The provider secures buildings, hardware and its services; you secure your accounts, data and settings (shared responsibility, Module 9).'),
    ('Do I need a credit card to learn?', 'Not for this course’s concept lessons. For AWS labs you need an account; set budgets first.'),
    ('Which cloud should I learn first?', 'Concepts are the same; AWS has the largest share and the most jobs, so our hands-on course starts there, with Azure and GCP names side by side.'),
    ('Is Google Drive cloud computing?', 'Yes, it is SaaS: finished software delivered from the cloud.'),
    ('Which certification after this course?', 'AWS Cloud Practitioner (CLF-C02), Azure AZ-900 or Google Cloud Digital Leader: each lesson has a Certification corner.')]
PRACTICE_INTRO = 'Cloud programs.'
PROBLEMS = [
    dict(level='easy', title='Server-days', stmt='Servers for 7500 orders.', inp='int', code='print(-(-7500 // 1000))\n', explain='8.'),
    dict(level='easy', title='Monthly bill', stmt='3 servers × 30 days × ₹250.', inp='ints', code='print(3 * 30 * 250)\n', explain='₹22,500.'),
    dict(level='easy', title='Hours', stmt='VM forgotten for a month.', inp='int', code='print(24 * 30, "hours")\n', explain='720.'),
    dict(level='medium', title='Peak ratio', stmt='Peak vs normal.', inp='ints', code='print(12000 / 3000)\n', explain='×4.'),
    dict(level='medium', title='Region filter', stmt='India regions.', inp='list', code='r = ["us-east-1", "ap-south-1", "eu-west-1", "ap-south-2"]\nprint([x for x in r if x.startswith("ap-south")])\n', explain='Mumbai, Hyderabad.'),
    dict(level='medium', title='Utilisation', stmt='Average use of 12 owned servers.', inp='ints', code='print(round((350 * 3 + 15 * 12) / (365 * 12) * 100), "%")\n', explain='~28%: mostly idle.'),
    dict(level='business', title='Saving', stmt='Own vs cloud.', inp='ints', code='own, cloud = 1080000, 307500\nprint("save", own - cloud)\n', explain='From the RUN model.'),
    dict(level='business', title='Alert', stmt='Budget alert.', inp='floats', code='spend, budget = 1.2, 0.0\nprint("ALERT" if spend > budget else "ok")\n', explain='Zero-spend alert.')]
SCN_INTRO = 'Cloud interview questions.'
SCENARIOS = (scn('Any company', 'Fresher', '“What is cloud computing?”', 'Explain in 30 s.', 'answer?', '<p>On-demand delivery of compute, storage and software over the internet with pay-as-you-go pricing; NIST’s five characteristics; IaaS/PaaS/SaaS; public/private/hybrid.</p>', '“Storing files online.”') +
    scn('Startup', 'Fresher', 'Why cloud?', 'Benefits.', 'answer?', '<ul><li>No up-front cost, speed, elasticity, global reach.</li></ul>', '“It is free.”') +
    scn('Bank', 'Mid-level', 'Data in India', 'Where to host?', 'answer?', '<ul><li>Indian regions, second region for DR, encryption.</li></ul>', 'Any region.') +
    scn('Ops', 'Mid-level', 'Surprise bill', 'Why?', 'answer?', '<ul><li>Forgotten resources; budgets, tags, cleanup.</li></ul>', 'Provider error.'))
