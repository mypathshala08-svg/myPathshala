import os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "..", "..", ".."))
sys.path.insert(0, os.path.join(HERE, "..", ".."))
from svgkit import scn
BODY = body(HERE)
META = dict(module='01-introduction', lesson='02-history-and-evolution-of-cloud-computing', n='1.2', module_label='Module 1 · Introduction to cloud computing',
    title='History and evolution of cloud computing',
    desc='How cloud computing evolved: mainframe time-sharing, utility computing, client-server, internet, grid computing, virtualization, Salesforce, AWS S3 and EC2 (2006), Google App Engine, Azure, serverless and AI. Real evidence from the AWS SDK: 436 services and their growth by year.',
    og_desc='From 1961’s “computing as a utility” to 436 AWS services: the history of cloud computing with real data.',
    minutes=18, level='Beginner',
    lead='The cloud’s ideas are sixty years old, but the business began in 2006. We walk through <b>six eras</b>, the provider race, and use the <b>AWS SDK itself</b> as evidence of how fast the cloud grew.',
    chips=['6 eras', '436 AWS services', 'AWS · Azure · GCP dates', 'Runs in your browser (Python)'])
MAIN = '''# Services added per year (real counts from the AWS SDK), running total
added = {2006: 1, 2009: 2, 2010: 7, 2011: 3, 2012: 9, 2013: 6, 2014: 19, 2015: 22, 2016: 22,
         2017: 50, 2018: 82, 2019: 30, 2020: 47, 2021: 33, 2022: 30, 2023: 32, 2024: 15, 2025: 19, 2026: 7}
total = 0
for year, n in added.items():
    total += n
    print(year, f"+{n:3d}", f"total {total:3d}", "#" * (n // 5))
'''
RUN = dict(heading='Run the code: the growth curve', intro='<p>Real counts from Step 2. Press <b>Run</b>, then try the challenges.</p>', code=MAIN,
    anno=[('    total += n', 'Running total = services known so far.')],
    tasks=[dict(label='1 · Run it', hint='Press <b>Run</b>.', code=None),
        dict(label='2 · Predict first: busiest year', hint='<b>Predict first:</b> which year added most?', code='added = {2017: 50, 2018: 82, 2020: 47}\nprint(max(added, key=added.get))\n'),
        dict(label='3 · Order the eras', hint='Sort by year.', code='eras = {"cloud": 2006, "mainframe": 1960, "virtualization": 1999, "internet": 1991}\nprint(sorted(eras, key=eras.get))\n'),
        dict(label='4 · Age', hint='How old is S3?', code='print(2026 - 2006, "years")\n'),
        dict(label='5 · Spot the error', hint='Wrong claim.', expect='error', code='first_public_iaas = 1999\nif first_public_iaas != 2006:\n    raise ValueError("1999 was Salesforce (SaaS) and VMware; public IaaS started with AWS S3/EC2 in 2006")\n')])
RUN['tasks'][0]['code'] = RUN['code']
PCRUN = dict(heading='Run on your PC', intro='<p>Python 3 and pip. <b>Outputs are real.</b></p>',
    items=[dict(title='1 · Run the lab', cmd='python3 l12_history.py', file='terminal', output="== 1) services the AWS SDK (botocore 1.43.127) knows today: 436", note='Needs the wheel from Practical step 1.')])
TRACE = dict(heading='Running total step by step', intro='<p>Three years.</p>',
    code='total = 0\nfor n in [1, 2, 7]:\n    total += n\n    print(total)\n', notes={3: 'Add :: this year.'})
WORKED_INTRO = 'Three history questions.'
EXAMPLES = [
    dict(level='b', tag='era', title='Which era?', problem='<p>Many users share one big computer and pay for time.</p>', inp='clue', approach=['Shared big computer.', '1960s.', 'Mainframe time-sharing.'], code='print("mainframe time-sharing")\n', notes={1: 'Era 1.'}, tryit='Types table.'),
    dict(level='i', tag='enabler', title='Key enabler', problem='<p>What lets one server be rented to 10 customers safely?</p>', inp='clue', approach=['Isolation.', 'Hypervisor.', 'Virtualization.'], code='print("virtualization")\n', notes={1: 'Module 4.'}, tryit='Exam tip.'),
    dict(level='a', tag='model', title='First model per provider', problem='<p>AWS, Google, Azure started with?</p>', inp='dates', approach=['AWS S3/EC2.', 'Google App Engine.', 'Azure PaaS.'], code='print({"AWS": "IaaS", "Google": "PaaS", "Azure": "PaaS"})\n', notes={1: 'Clouds tab.'}, tryit='Clouds.')]
QUIZ = mix([
    dict(q='Beginner: The public cloud business began with…', options=['Gmail 2004', 'AWS S3 and EC2 in 2006', 'Windows 95', 'Linux 1991'], answer=1, why='2006.'),
    dict(q='Beginner: Time-sharing comes from the era of…', options=['Smartphones', 'Mainframes', 'Serverless', 'Edge'], answer=1, why='1960s.'),
    dict(q='Beginner: An early SaaS company (1999) is…', options=['Docker', 'Salesforce', 'Kubernetes', 'Lambda'], answer=1, why='CRM over the web.'),
    dict(q='Intermediate: Utility computing means…', options=['Free computing', 'Metered computing like electricity', 'Only storage', 'Offline'], answer=1, why='Pay per use.'),
    dict(q='Intermediate: AWS SDK services today (our lab)…', options=['36', '436', '4,360', '43'], answer=1, why='Step 1.'),
    dict(q='Intermediate: Google Cloud started with…', options=['EC2', 'App Engine (PaaS)', 'Azure', 'S3'], answer=1, why='2008.'),
    dict(q='Advanced: AWS Lambda (serverless) launched in…', options=['2006', '2014', '2020', '1999'], answer=1, why='2014.'),
    dict(q='Advanced: Most services were added in…', options=['2006–2009', '2017–2018', '2025–2026', '2010–2011'], answer=1, why='Step 2.')])
REVISION = ['Utility idea 1961; mainframe time-sharing.', 'Eras: mainframe → client-server → internet → grid → virtualization → cloud.', 'Salesforce 1999 SaaS; AWS S3/EC2 2006; App Engine 2008; Azure 2010; Lambda 2014.', 'AWS SDK: 436 services; boom 2017–2018.', 'India regions: AWS Mumbai 2016, Hyderabad 2022.']
FAQ = [('Is cloud the same as mainframe?', 'Same sharing idea, but self-service, internet access, elastic scale and millions of commodity servers.'),
    ('Why did Amazon start a cloud?', 'It had learned to run huge infrastructure for its retail business and turned that into products (commonly told story).'),
    ('Will the cloud keep growing?', 'Yes: AI, data and edge services keep adding services; the SDK still adds new ones every year.'),
    ('Do exams ask dates?', 'Rarely exact dates; they ask benefits and evolution concepts.')]
PRACTICE_INTRO = 'History programs.'
PROBLEMS = [
    dict(level='easy', title='Sum', stmt='Services 2017+2018.', inp='ints', code='print(50 + 82)\n', explain='132.'),
    dict(level='easy', title='Years', stmt='1961 → 2006.', inp='ints', code='print(2006 - 1961)\n', explain='45 years.'),
    dict(level='easy', title='Share', stmt='% added 2017–18.', inp='ints', code='print(round(132 / 436 * 100), "%")\n', explain='30%.'),
    dict(level='medium', title='Peak year', stmt='Max of dict.', inp='dict', code='a = {2016: 22, 2017: 50, 2018: 82}\nprint(max(a, key=a.get))\n', explain='2018.'),
    dict(level='medium', title='Decades', stmt='Group by decade.', inp='dict', code='a = {2006: 1, 2009: 2, 2010: 7, 2014: 19, 2018: 82, 2021: 33}\nfrom collections import Counter\nc = Counter()\nfor y, n in a.items(): c[y // 10 * 10] += n\nprint(dict(c))\n', explain='2010s dominate.'),
    dict(level='medium', title='Sort eras', stmt='Chronological.', inp='dict', code='e = {"cloud": 2006, "grid": 1998, "web": 1991}\nprint(sorted(e, key=e.get))\n', explain='web, grid, cloud.'),
    dict(level='business', title='Age of region', stmt='Mumbai region age.', inp='int', code='print(2026 - 2016, "years")\n', explain='10.'),
    dict(level='business', title='Avg per year', stmt='Services per year.', inp='ints', code='print(round(436 / 20, 1))\n', explain='~22.')]
SCN_INTRO = 'History interview questions.'
SCENARIOS = (scn('Any company', 'Fresher', '“How did cloud computing evolve?”', 'Explain.', 'answer?', '<p>Mainframe time-sharing → client-server → internet → grid/utility → virtualization → public cloud (AWS 2006) → serverless/containers → AI/edge.</p>', '“Amazon invented it in 2006.”') +
    scn('Training', 'Fresher', 'Enablers', 'Which tech?', 'answer?', '<ul><li>Internet, virtualization, cheap hardware, web APIs.</li></ul>', 'Only internet.') +
    scn('Consulting', 'Mid-level', 'Grid vs cloud', 'Difference?', 'answer?', '<ul><li>Grid: shared big jobs; cloud: on-demand self-service, metered.</li></ul>', 'Same.') +
    scn('Product', 'Mid-level', 'Why serverless', 'History link?', 'answer?', '<ul><li>Utility + metering idea taken to per-ms billing.</li></ul>', 'Fashion.'))
