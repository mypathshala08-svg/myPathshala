import os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "..", "..", ".."))
sys.path.insert(0, os.path.join(HERE, "..", ".."))
from svgkit import scn
BODY = body(HERE)
META = dict(module='01-introduction', lesson='06-real-world-applications-of-cloud', n='1.6', module_label='Module 1 · Introduction to cloud computing',
    title='Real-world applications of cloud',
    desc='Real-world applications of cloud computing: web and mobile apps, payments, streaming, healthcare, education, e-governance, agriculture, IoT, big data and AI, with real data from the Registry of Open Data on AWS, hands-on AWS CLI access to public datasets, and the Module 1 combined project.',
    og_desc='1,474 open datasets and ten industries: where cloud computing is really used, with a hands-on public-data lab.',
    minutes=20, level='Beginner',
    lead='Where is the cloud used? We map <b>ten application areas</b> to cloud building blocks, explore <b>1,474 open datasets</b> on AWS, read a public bucket with the AWS CLI, and finish Module 1 with a <b>combined project</b>.',
    chips=['10 industries', 'Open data on AWS', 'Module 1 project', 'Runs in your browser (Python)'])
MAIN = '''# Match a use case to cloud building blocks
blocks = {
    "food delivery app": ["load balancer", "auto-scaled compute", "managed database", "CDN"],
    "satellite crop map": ["object storage (open data)", "Spark on cloud", "dashboard"],
    "smart meters": ["IoT hub", "stream", "time-series DB"],
    "X-ray triage": ["encrypted storage (India region)", "GPU inference", "audit logs"],
}
for app, parts in blocks.items():
    print(f"{app:20} -> " + " + ".join(parts))
'''
RUN = dict(heading='Run the code: use case → building blocks', intro='<p>Press <b>Run</b>, then try the challenges.</p>', code=MAIN,
    anno=[('    "food delivery app": ["load balancer", "auto-scaled compute", "managed database", "CDN"],', 'Classic web app pattern.')],
    tasks=[dict(label='1 · Run it', hint='Press <b>Run</b>.', code=None),
        dict(label='2 · Predict first: top tag', hint='<b>Predict first:</b> most common open-data topic?', code='tags = {"life sciences": 527, "satellite imagery": 310, "medicine": 293}\nprint(max(tags, key=tags.get))\n'),
        dict(label='3 · Add one', hint='Online exam portal.', code='print("online exam -> auto-scaled web + database + CDN + logs")\n'),
        dict(label='4 · Share', hint='% satellite of 1474.', code='print(round(310 / 1474 * 100), "% of datasets")\n'),
        dict(label='5 · Spot the error', hint='Download petabytes.', expect='error', code='dataset_tb, laptop_tb = 5000, 1\nif dataset_tb > laptop_tb:\n    raise MemoryError("do not download: analyse in the cloud next to the data")\n')])
RUN['tasks'][0]['code'] = RUN['code']
PCRUN = dict(heading='Run on your PC', intro='<p>Python 3 / AWS CLI, internet. <b>Outputs are real.</b></p>',
    items=[dict(title='1 · Run the lab', cmd='python3 l16_apps.py', file='terminal', output='  datasets on the page: 1474  tag uses: 8714', note='Grows over time.'),
           dict(title='2 · Public bucket', cmd='aws s3 ls --no-sign-request s3://noaa-ghcn-pds/', file='terminal', output='', note='No account needed.')])
TRACE = dict(heading='Counting tags step by step', intro='<p>Counter.</p>',
    code='from collections import Counter\nc = Counter(["climate", "health", "climate"])\nprint(c.most_common(1))\n', notes={2: 'Count :: each tag.'})
WORKED_INTRO = 'Three use-case mappings.'
EXAMPLES = [
    dict(level='b', tag='web', title='Static website', problem='<p>College fest website.</p>', inp='need', approach=['Static files.', 'Object storage.', 'CDN.'], code='print("S3 static website + CloudFront")\n', notes={1: 'AWS course 4.5.'}, tryit='Exam tip.'),
    dict(level='i', tag='data', title='Analyse open data', problem='<p>Query 10 years of weather.</p>', inp='need', approach=['Data on S3.', 'Serverless SQL.', 'Pay per query.'], code='print("Athena over the public bucket")\n', notes={1: 'Bring compute to data.'}, tryit='Practical.'),
    dict(level='a', tag='AI', title='Hospital AI', problem='<p>X-ray triage with rules.</p>', inp='need', approach=['India region.', 'Encrypt.', 'GPU inference + audit.'], code='print(["ap-south-1", "KMS", "GPU endpoint", "CloudTrail"])\n', notes={1: 'Compliance.'}, tryit='Scenario 3.')]
QUIZ = mix([
    dict(q='Beginner: Which uses the cloud?', options=['Only IT companies', 'Streaming, payments, health, government…', 'Nobody in India', 'Only games'], answer=1, why='Everywhere.'),
    dict(q='Beginner: A CDN is used for…', options=['Billing', 'Fast content delivery near users', 'Passwords', 'Backups only'], answer=1, why='Edge cache.'),
    dict(q='Beginner: Open datasets on AWS (our count)…', options=['14', '1,474', '147,400', '0'], answer=1, why='Step 1.'),
    dict(q='Intermediate: Top topic in the registry…', options=['gaming', 'life sciences', 'music', 'sports'], answer=1, why='Step 2.'),
    dict(q='Intermediate: Analyse data where it is stored is called…', options=['Lift and shift', 'Bring compute to data', 'Egress', 'Lock-in'], answer=1, why='Levels L3.'),
    dict(q='Intermediate: Indian government community cloud initiative…', options=['ONDC', 'MeghRaj', 'UPI', 'Aadhaar'], answer=1, why='Types table.'),
    dict(q='Advanced: Stream of smart-meter readings fits…', options=['Glacier', 'IoT hub + stream processing', 'CDN only', 'Email'], answer=1, why='IoT pattern.'),
    dict(q='Advanced: Public bucket without credentials uses…', options=['--force', '--no-sign-request', '--root', '--public'], answer=1, why='Practical.')])
REVISION = ['10 areas: web/mobile, payments, streaming, education, health, e-gov, agri, big data, backup, IoT.', 'Pattern = compute + storage + data + network (+ AI).', 'Real: 1,474 open datasets; life sciences 527, satellite 310.', 'Bring compute to data; read licences.', 'Module 1 project combines all six lessons.']
FAQ = [('Is reading open data really free?', 'For public open-data buckets, yes for you; costs are covered by the program. Your own compute is billed.'),
    ('Can I use this for my capstone?', 'Yes — weather, satellite, transport and health datasets are great; check licences.'),
    ('What is MeghRaj?', 'The Government of India’s cloud initiative (GI Cloud) for government departments.'),
    ('Which course next?', 'Module 2 service models; for hands-on, the AWS course.')]
PRACTICE_INTRO = 'Application programs.'
PROBLEMS = [
    dict(level='easy', title='Percent', stmt='Weather share.', inp='ints', code='print(round(197 / 1474 * 100))\n', explain='13%.'),
    dict(level='easy', title='Top 2', stmt='Two largest.', inp='dict', code='d = {"a": 527, "b": 310, "c": 293}\nprint(sorted(d, key=d.get)[-2:])\n', explain='b, a.'),
    dict(level='easy', title='Avg tags', stmt='Tags per dataset.', inp='ints', code='print(round(8714 / 1474, 1))\n', explain='~5.9.'),
    dict(level='medium', title='Map', stmt='Use case → service.', inp='dict', code='m = {"video": "CDN", "files": "object storage"}\nprint(m["video"])\n', explain='CDN.'),
    dict(level='medium', title='Filter', stmt='Names with "noaa".', inp='list', code='n = ["noaa-goes", "sentinel-2", "noaa-nexrad"]\nprint([x for x in n if "noaa" in x])\n', explain='2.'),
    dict(level='medium', title='Group', stmt='Count by first word.', inp='list', code='from collections import Counter\nn = ["noaa-goes", "noaa-nexrad", "sentinel-2"]\nprint(Counter(x.split("-")[0] for x in n))\n', explain='noaa 2.'),
    dict(level='business', title='Download time', stmt='5 PB at 100 Mbps.', inp='ints', code='print(round(5e15 * 8 / 100e6 / 86400 / 365, 1), "years")\n', explain='~12.7 years!'),
    dict(level='business', title='Pick project', stmt='Score ideas.', inp='dict', code='s = {"weather": 8, "toy csv": 3, "satellite": 9}\nprint(max(s, key=s.get))\n', explain='satellite.')]
SCN_INTRO = 'Applications interview questions.'
SCENARIOS = (scn('Any company', 'Fresher', '“Where is cloud used?”', 'Examples.', 'answer?', '<p>Web/mobile apps, payments, streaming, health, education, e-governance, IoT, analytics and AI — with the matching building blocks.</p>', '“Google Drive.”') +
    scn('Analytics', 'Fresher', 'Open data', 'Use?', 'answer?', '<ul><li>Analyse in place with Athena/Spark.</li></ul>', 'Download all.') +
    scn('Gov', 'Mid-level', 'Citizen portal', 'Design?', 'answer?', '<ul><li>Elastic web tier, Indian region, CDN, WAF.</li></ul>', 'One server.') +
    scn('Health', 'Mid-level', 'AI on X-rays', 'Rules?', 'answer?', '<ul><li>Residency, encryption, audit, human review.</li></ul>', 'Any region.'))
