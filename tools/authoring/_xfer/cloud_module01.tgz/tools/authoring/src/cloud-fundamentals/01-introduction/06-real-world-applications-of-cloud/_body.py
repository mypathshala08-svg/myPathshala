import os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', '..'))
from cloudkit import *
C = 'l16_apps.txt'
def sec(a, b=None, drop=()):
    return capsec(C, a, b, drop)
B = '../../'
hk = hook('Who actually uses the cloud, and for what? Only tech companies?',
    'Everyone: streaming, payments, hospitals, farms, weather offices, schools, governments. Even science data lives there: the <b>Registry of Open Data on AWS</b> lists <b>1,474 public datasets</b> — <b>527</b> tagged life sciences, <b>310</b> satellite imagery, <b>197</b> weather, <b>154</b> agriculture. Anyone can analyse Sentinel-2 or Landsat satellite images without downloading petabytes.',
    ['Ten application areas, each with a cloud pattern.', 'Indian examples: UPI scale, CoWIN, IRCTC, DigiLocker, ONDC.', 'Big data and AI on cloud (your PGCP-BDA link).'])
cmap = concept_map('Concept map. Beginner: apps you use daily. Intermediate: application areas and patterns. Advanced: big data and AI pipelines on cloud.',
    [[('wc', 'What is cloud', 'Lesson 1.1', B + '01-introduction/01-what-is-cloud-computing/'), ('sm', 'Service models', 'Module 2', B + '02-service-models/01-iaas-infrastructure-as-a-service/')],
     [('web', 'Web + mobile', 'apps', None), ('data', 'Big data', 'analytics', None), ('ai', 'AI / ML', 'GPUs', None), ('bk', 'Backup + DR', 'storage', None)],
     [('iot', 'IoT', 'devices', None), ('gov', 'e-Gov', 'India', None), ('sci', 'Science', 'open data', None), ('bp', 'Building blocks', 'Module 6', B + '06-cloud-building-blocks/04-cloud-products-and-solutions-map/')]],
    [('wc', 'web'), ('sm', 'web'), ('web', 'data'), ('data', 'ai'), ('web', 'bk'), ('data', 'iot'), ('web', 'gov'), ('data', 'sci'), ('ai', 'bp')],
    {'web', 'data', 'ai', 'bk', 'iot', 'gov', 'sci'},
    '<b>Module 1 done!</b> <b>Next:</b> <a href="../../02-service-models/01-iaas-infrastructure-as-a-service/">Module 2 · Service models</a>. <b>Related:</b> <a href="../../../spark-pyspark/">PySpark</a>, <a href="../../../kafka/">Kafka</a>.')
whw = why_how_where(
    'Knowing real applications helps you answer “where is cloud used?” and pick project ideas for placements and capstones.',
    'Each application maps to a few cloud building blocks: compute (VMs, containers, functions), storage (object, block), databases, queues/streams, analytics and AI services, CDN.',
    'Entertainment, finance, healthcare, education, government, retail, logistics, agriculture, science, gaming, telecom.',
    'Examples describe common practice; companies rarely publish full architectures, so we name patterns, not secret details.')
def apps(hl=-1):
    items = [('Streaming', 'blue'), ('Payments', 'green'), ('Health', 'violet'), ('Education', 'amber'), ('e-Gov', 'acc'), ('Retail', 'blue'), ('Agri', 'green'), ('Science', 'violet'), ('Gaming', 'amber'), ('AI', 'acc')]
    o = t(180, 14, 'One cloud, many industries', 8.4, 'ink', bold=True)
    for i, (a, tn) in enumerate(items):
        x = 16 + (i % 5) * 68; y = 26 + (i // 5) * 52
        o += box(x, y, 60, 40, 'amber' if i == hl else tn, rx=8) + t(x + 30, y + 24, a, 8, 'ink', bold=True)
    return o + t(180, 140, 'same building blocks: compute · storage · data · AI · network', 7.6, 'ink2')
scene_svg = scene('Ten industry tiles that run on the cloud: streaming, payments, health, education, e-government, retail, agriculture, science, gaming, AI.', apps(),
                  'Different industries, <tspan font-weight="700" class="s-acc">same cloud building blocks</tspan>.')
dialogue = '''R> Sir, for my capstone I want a “cloud project”, but what do real companies use cloud for?
A> Look around: the video you streamed, the UPI payment, your vaccine certificate, the weather forecast. And scientists share whole satellite archives on the cloud.
K> Can we see that data?
A> Yes — AWS publishes a registry of open datasets. Let’s count what is there and map each industry to cloud building blocks.'''
lv = '''
LEVELS> Cloud applications at three levels
L1> Apps you already use
      <ul>
        <li>Video and music streaming, online classes, food delivery, cab booking, UPI and banking apps, email, maps, photo backup, online games.</li>
      </ul>
L2> Ten application areas
      <ul>
        <li><b>Web & mobile apps</b> · <b>storage, backup & DR</b> · <b>big data analytics</b> · <b>AI/ML and GenAI</b> · <b>IoT</b> (sensors, smart meters) · <b>media streaming & CDN</b> · <b>e-commerce</b> · <b>healthcare</b> · <b>education</b> (LMS, virtual labs) · <b>e-governance</b>.</li>
        <li>Also: dev/test environments, high-performance computing (simulations), gaming servers, virtual desktops.</li>
      </ul>
L3> Patterns behind them
      <ul>
        <li>Web app = load balancer + auto-scaled compute + managed DB + CDN. Data lake = object storage + Spark/SQL engines (our PySpark and Hive courses). Streaming = Kafka/Kinesis + stream processing. AI = GPUs + managed ML platforms + model APIs.</li>
        <li>Open data on cloud: analyse where the data lives instead of downloading it (“bring compute to data”, same idea as Hadoop).</li>
      </ul>
/LEVELS
'''
mm = mindmap('Mind map of real-world cloud applications grouped by area.', 'Cloud in real life', [
    ('Consumer', 'blue', ['streaming', 'social media', 'gaming']),
    ('Business', 'green', ['e-commerce', 'CRM / ERP SaaS', 'email, office']),
    ('Data + AI', 'violet', ['data lakes', 'ML training', 'GenAI apps']),
    ('Public sector', 'acc', ['e-governance', 'health records', 'education']),
    ('Physical world', 'amber', ['IoT sensors', 'agriculture', 'smart cities']),
    ('Science', 'card', ['genomics', 'satellites', 'climate'])], h=290)
lay = layers('A typical cloud application stack: users and CDN at the top, then app compute, data stores, analytics and AI, all on provider infrastructure.', [
    ('Users + CDN', 'phones, browsers, edge cache', 'blue'), ('App layer', 'VMs, containers, functions', 'green'),
    ('Data stores', 'object storage, databases', 'violet'), ('Analytics', 'Spark, SQL engines, dashboards', 'acc'),
    ('AI / ML', 'training, model APIs', 'amber'), ('Cloud infrastructure', 'regions, AZs, network', 'card')], hl=2, caption='Most applications use 3–5 of these layers.')
DIS = figure('Dissection of a registry entry: dataset sentinel-2, tags satellite imagery and earth observation, stored in S3, free to access.',
    t(16, 22, 'One open dataset on AWS (real)', 8.6, 'ink', anchor='start', bold=True) +
    fields(16, 34, [('sentinel-2', 'blue', 1), ('satellite imagery', 'green', 2), ('S3 bucket', 'amber', 3), ('free to read', 'violet', 4)]) +
    legend(16, 84, [(1, 'Dataset', 'ESA Sentinel-2 images'), (2, 'Tags', 'how the registry groups it'), (3, 'Where', 'object storage'), (4, 'Access', 'analyse in place')], size=8, gap=15, w=90),
    h=156, caption='Bring the computation to the data, not the data to you.')
extra = '\n\n  <h3>The stack behind a cloud application</h3>\n' + lay + '\n\n  <h3>Dissect an open dataset</h3>\n' + DIS
types_html = table(['Area', 'Example (India-flavoured)', 'Cloud pattern', 'Service model'], [
    ['Web & mobile', 'food delivery, cab apps', 'LB + auto scaling + DB + CDN', 'IaaS/PaaS'],
    ['Payments', 'UPI apps on sale days', 'elastic compute, queues, multi-AZ', 'IaaS/PaaS'],
    ['Streaming', 'cricket live streams', 'CDN + video encoding', 'PaaS'],
    ['Education', 'LMS, online exams, virtual labs', 'SaaS + VMs per student', 'SaaS/IaaS'],
    ['Healthcare', 'tele-consultation, health records', 'encrypted storage, Indian regions', 'PaaS/SaaS'],
    ['e-Governance', 'digital certificates, citizen portals', 'government community cloud (MeghRaj)', 'IaaS/PaaS'],
    ['Agriculture', 'crop monitoring from satellites', 'open data + analytics', 'PaaS'],
    ['Big data & AI', 'fraud detection, recommendations', 'data lake + Spark + ML', 'PaaS'],
    ['Backup & DR', 'office file backup', 'object storage + lifecycle', 'IaaS/SaaS'],
    ['IoT', 'smart electricity meters', 'IoT hub + streams + DB', 'PaaS']], minw=640)
warn = 'In interviews do not claim a specific company “runs entirely on AWS/Azure” unless it is published. Say “apps like X typically use…” and describe the pattern.'
steps = [
    ('Step 1 · Count the open datasets', code('python', 'l16_apps.py', 'h = urlopen("https://registry.opendata.aws/").read()\nnames = re.findall(r\'<h3><a href="/([^/"]+)/">\', h)', sec('== 1)', '== 2)')), 'Public, free-to-access data stored on cloud object storage.'),
    ('Step 2 · Top topics', code('python', 'l16_apps.py', 'Counter(tags).most_common(15)', sec('== 2)', '== 3)')), 'Life sciences, satellites, health, climate, agriculture, ML: cloud is everywhere in science.'),
    ('Step 3 · Famous datasets', code('python', 'l16_apps.py', 'names containing sentinel / landsat / noaa / covid', sec('== 3)')), 'Satellite images, weather radar, COVID research: analysed in place with Spark or Athena.'),
]
see = [term([('1474 datasets', G), ('8714 tag uses', W)], size=7.0), term([('life sciences 527', W), ('satellite 310', W)], size=7.0), term([('sentinel-2', G), ('usgs-landsat', G)], size=7.0),
       term([('weather 197', W), ('agriculture 154', W)], size=7.0), term([('ML 161', G)], size=7.0)]
B1 = [apps(i) for i in (7, 7, 6, 3, 9)]
B1 = [b + cap(c, '', tn, y=146, h=20) for b, c, tn in zip(B1, ['Science data', 'Topics', 'Farms from space', 'Weather', 'AI'], ['violet', 'violet', 'green', 'amber', 'acc'])]
two = anim_two('Cloud applications', 'Open data on the cloud', 'Real outputs (registry.opendata.aws)', 'Industries', see, B1, ['Count.', 'Topics.', 'Famous.', 'Weather.', 'ML.'], ['Science.', 'Topics.', 'Agri.', 'Climate.', 'AI.'])
pe = peel('A UPI-style payment on sale day, layer by layer', 'Common pattern for payment apps. (Simplified.)',
    [('Tap Pay', ''), ('Edge', ''), ('App', ''), ('Queue', ''), ('Bank switch', ''), ('Analytics', '')],
    [['Tap Pay', 'mobile app', '', ''], ['Edge', 'CDN + WAF', 'blocks attacks', ''], ['App', 'auto-scaled', 'containers', 'elastic'],
     ['Queue', 'smooths spikes', 'no lost requests', ''], ['Bank switch', 'secure link', 'to bank/NPCI', 'hybrid'], ['Analytics', 'stream to fraud model', '', 'AI']],
    ['Tap.', 'Protect.', 'Scale.', 'Buffer.', 'Settle.', 'Watch.'], 'scenario-peel')
scen = five('Real-time scenario 1', 'Cricket final stream', 'Millions watch at once. (Typical.)', ('CDN + elasticity', 'Edge caches video'), [
    ('Match starts', 'viewers ×50', 'Spike.', 'red'), ('Video encoded in cloud', 'many bitrates', 'Prepare.', 'blue'),
    ('CDN edges serve', 'near users', 'Deliver.', 'green'), ('Origin auto-scales', '', 'Scale.', 'green'), ('After match: shrink', '', 'Save.', 'amber')], ['Spike.', 'Encode.', 'Edge.', 'Scale.', 'Shrink.'], 'scenario-stream') + \
       five('Real-time scenario 2', 'Farm advisory from satellites', 'Crop health for a district. (Typical.)', ('Open data + Spark', 'Analyse in place'), [
    ('Need crop health', '', 'Question.', 'blue'), ('Sentinel-2 on S3', 'open data', 'Data.', 'green'),
    ('Spark on cloud', 'compute NDVI', 'Analyse.', 'violet'), ('Map per village', '', 'Result.', 'green'), ('SMS advice to farmers', '', 'Act.', 'amber')], ['Ask.', 'Data.', 'Spark.', 'Map.', 'SMS.'], 'scenario-agri') + \
       five('Real-time scenario 3 · advanced', 'Hospital AI', 'X-ray triage. (Typical.)', ('AI + compliance', 'Indian region, encrypted'), [
    ('X-rays uploaded', 'encrypted', 'Ingest.', 'blue'), ('Stored in India region', '', 'Comply.', 'violet'),
    ('Model flags urgent cases', 'GPU inference', 'AI.', 'green'), ('Doctor reviews', '', 'Human.', 'amber'), ('Audit log', '', 'Prove.', 'blue')], ['Upload.', 'Store.', 'Flag.', 'Review.', 'Audit.'], 'scenario-health')
clouds = vendor_tabs(
    '<p><b>AWS:</b> Registry of Open Data (used here), case studies at aws.amazon.com/solutions/case-studies, building blocks: EC2, S3, RDS, Kinesis, EMR, SageMaker, Bedrock, CloudFront.</p>',
    '<p><b>Azure:</b> Azure Open Datasets, Planetary Computer (earth data), strong in enterprise apps with Microsoft 365, Dynamics, Power BI; building blocks: VMs, Blob, SQL, Event Hubs, Synapse, Azure AI.</p>',
    '<p><b>Google Cloud:</b> BigQuery public datasets, Earth Engine (satellite analysis), Vertex AI; strong in analytics and AI; building blocks: Compute Engine, Cloud Storage, Pub/Sub, Dataflow, BigQuery.</p>') + \
    cloud3([['Public datasets', 'Registry of Open Data', 'Azure Open Datasets', 'BigQuery public datasets'], ['Earth / satellite', 'Sentinel, Landsat on S3', 'Planetary Computer', 'Earth Engine'], ['Streaming data', 'Kinesis / MSK', 'Event Hubs', 'Pub/Sub'], ['ML platform', 'SageMaker / Bedrock', 'Azure AI Foundry / ML', 'Vertex AI']])
prac = practical('Explore real cloud datasets and list a public bucket without an account.', [
    ('1 · Browse the registry', '<p>Open <code>registry.opendata.aws</code>, search “sentinel-2” and “india”.</p>', 'Each page shows the S3 location and licence.'),
    ('2 · Install the AWS CLI', code('bash', 'terminal', 'pip install awscli     # or the official installer\naws --version'), 'Free; no account needed for public data with --no-sign-request.'),
    ('3 · List a public bucket', code('bash', 'terminal', 'aws s3 ls --no-sign-request s3://noaa-ghcn-pds/ --region us-east-1 | head'), 'You are reading cloud object storage directly.'),
    ('4 · Download one small file', code('bash', 'terminal', 'aws s3 ls --no-sign-request s3://noaa-ghcn-pds/csv/by_year/ | tail -3\naws s3 cp --no-sign-request s3://noaa-ghcn-pds/csv/by_year/1763.csv .'), 'Weather records from 1763: a few KB.'),
    ('5 · Run the lesson script', code('bash', 'terminal', 'python3 l16_apps.py'), 'Same as Steps 1–3.')],
    cleanup='Delete downloaded files. Public open-data reads are free for you; the data owner/AWS pays. Never use --no-sign-request on private data.')
mist = mistakes([
    ['Downloading huge datasets to a laptop.', 'Habit from small files.', 'Analyse in the cloud next to the data (Athena, Spark, BigQuery).'],
    ['Claiming a company’s exact cloud setup.', 'Guessing from news.', 'Describe patterns; cite published case studies only.'],
    ['Picking a capstone with no real data.', 'Toy CSVs.', 'Use open datasets (weather, satellite, transport) for real scale.'],
    ['Ignoring licences of open data.', '“Public” ≠ any use.', 'Read the licence on the registry page.'],
    ['Thinking cloud = only IT companies.', 'Visible apps are tech.', 'Health, farming, government and science are big users.']])
cert = certbox([
    ['AWS CLF-C02', 'Domain 3 · Cloud Technology & Services (34%)', 'Match use cases to services: web (EC2, ELB), storage (S3), analytics (Athena, EMR), ML (SageMaker), CDN (CloudFront).'],
    ['Azure AZ-900', 'Describe Azure architecture and services', 'Typical workloads and matching services.'],
    ['Google Cloud Digital Leader', 'Data transformation; AI', 'Value of data and AI in industries; public datasets, BigQuery, Vertex AI.'],
    ['C-DAC PGCP-BDA', 'Sessions 5–6, 8–9 lab', 'Cloud products and solutions; exposure to big data technologies on cloud.']],
    [('A company wants to analyse petabytes of satellite images without buying storage. Best approach?', 'Use the open dataset in cloud object storage and analyse in place with a managed query/Spark service.'),
     ('Which service delivers video to millions with low latency? (a) S3 Glacier (b) CloudFront (c) IAM', '<b>(b) CloudFront</b>, a CDN.')])
proj = miniproject('Module 1 project: “Cloud in India” fact sheet (combines 1.1–1.6)',
    'One script that builds a dated HTML fact sheet: regions in India (1.1), AWS service growth (1.2), real prices (1.3), recent incidents (1.4), TCO line (1.5) and top open-data topics (1.6).',
    ['Make a folder <code>cloud-factsheet</code> and copy the six lesson scripts into it.', 'Change each script’s <code>print</code> into a function that returns its lines.', 'Write <code>build.py</code> that calls them and writes <code>factsheet.html</code> with one section each.', 'Run weekly with <code>cron</code>; commit each version to GitHub.', 'Later (AWS course): host it as an S3 static website and send the link.'],
    'A one-page HTML fact sheet you can share with classmates, updated weekly with real data.', 'Everything from Module 1 + Python, HTML, cron, Git, later S3.')
assemble_cloud(HERE, interview=['“Cloud computing is used everywhere: web and mobile apps, payments, video streaming, e-governance, healthcare, education, IoT, big data analytics and AI.”', '“Each application uses a few building blocks: elastic compute, object storage, managed databases, streaming, analytics engines and AI services, often with a CDN in front.”', '“For example, satellite data like Sentinel-2 is stored as open data on the cloud so we can analyse it in place with Spark instead of downloading petabytes.”'],
    clouds_html=clouds, practical_html=prac, mistakes_html=mist, cert_html=cert, project_html=proj, mindmap_html=mm,
    h2_story='A capstone idea from the sky', hook_html=hk,
    narration='Riya must pick a capstone. She wants real data and a real cloud use case, not a toy CSV. Arjun Sir shows her where the world keeps its open data.',
    scene_svg=scene_svg, dialogue=dialogue, def_h2='Real-world applications of cloud computing',
    formal='<b>Cloud applications</b> are workloads delivered using cloud resources and services, including web and mobile applications, storage, backup and disaster recovery, big data analytics, artificial intelligence, IoT, media streaming, e-commerce, healthcare, education, scientific computing and e-governance, each composed from compute, storage, database, networking, analytics and AI building blocks.',
    simple='Almost every app and service you use — and much of science and government — runs on the cloud’s rented computers, storage and AI.',
    term_rows=[('Workload', 'An application running on cloud.'), ('CDN', 'Content delivery network, edge cache.'), ('Data lake', 'Raw data in object storage.'), ('Open data', 'Public datasets anyone can use.'), ('IoT', 'Internet of Things devices.'), ('e-Governance', 'Government services online.'), ('Inference', 'Using a trained AI model.'), ('Bring compute to data', 'Analyse where data lives.')],
    whw=whw, cmap=cmap, extra_def=extra, lv=lv,
    myth_rows=[('Cloud is only for IT companies.', '527 life-science datasets.', 'Step 2.'), ('You must download data to analyse it.', 'Query it in place.', 'Practical.'), ('Open data is small.', 'Satellite archives are petabytes.', 'Step 3.')],
    exam='Exams give a use case and ask for the service: static website → S3 + CloudFront; analytics on S3 → Athena; big data → EMR; ML → SageMaker; IoT → IoT Core. Azure/GCP equivalents in the Clouds tab.',
    types_h2='Ten application areas', types_html=types_html, warn=warn,
    steps_h2='What the world keeps on the cloud', steps_intro='All outputs are real: the Registry of Open Data on AWS home page, read on 10 Nov 2026.',
    steps=steps, two=two, peel_intro='Now peel a payment on sale day.', peel_html=pe, scen_intro='Three live scenarios: a cricket stream, farm advice, hospital AI.', scen=scen,
    uc_h2='Cloud in India and beyond', ucs=[uc_('upi', 'payments', 'green', '1. Digital payments', 'Elastic, secure, multi-AZ.', ['App', '*Cloud', 'Bank']),
        uc_('gov', 'e-gov', 'acc', '2. Citizen services', 'Certificates and portals (MeghRaj community cloud).', ['Citizen', '*Gov cloud', 'Service']),
        uc_('agri', 'agri', 'amber', '3. Agriculture', 'Satellite + weather analytics.', ['Satellite', '*Spark', 'Advice']),
        uc_('edu', 'edu', 'blue', '4. Education', 'Online classes and labs.', ['Students', '*SaaS/VMs', 'Learn'])],
    uc_note='Examples are simplified descriptions of common practice, not specific companies’ architectures.', pre='<b>Before you start:</b> <a href="../05-on-premises-vs-cloud-vs-dedicated-servers/">1.5</a>.')
