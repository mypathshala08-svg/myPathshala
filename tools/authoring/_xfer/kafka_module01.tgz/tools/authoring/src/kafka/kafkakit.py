"""Small drawing helpers shared by the Apache Kafka lessons (authoring time only)."""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))
from svgkit import *


def keep(spec, inner):
    """Show `inner` on the frames in spec, e.g. keep('2-', ...) or keep('2-4,6', ...)."""
    return f'<g data-on="{spec}">{inner}</g>'


def chip(x, y, label, color='acc', w=30, h=14, size=7.6, txt='#fff'):
    return fill(x, y, w, h, color, rx=3) + t(x + w / 2, y + h / 2 + 2.8, label, size, bold=True, extra=f' style="fill:{txt}"')


def tall(x, y, w, h, title, lines, tone='card', size=7.6, mono=True):
    """Box with a bold title and a few left-aligned lines."""
    o = box(x, y, w, h, tone) + t(x + w / 2, y + 11, title, 8.2, bold=True)
    for k, ln in enumerate(lines):
        o += t(x + 6, y + 24 + k * 11, ln, size, 'ink2', anchor='start', mono=mono)
    return o


def cyl(x, y, w, h, label, tone='card', size=8.4):
    """A small database drum."""
    cls, st = TONES[tone]
    return (f'<path d="M{x} {y+6}v{h-12}a{w/2} 6 0 0 0 {w} 0v-{h-12}" class="{cls}" style="stroke:{st}"/>'
            f'<ellipse cx="{x+w/2}" cy="{y+6}" rx="{w/2}" ry="6" class="{cls}" style="stroke:{st}"/>'
            + t(x + w / 2, y + h / 2 + 5, label, size, bold=True))


def dn(x, y, w, h, label, tone='card'):
    return box(x, y, w, h, tone) + t(x + w / 2, y + 11, label, 8, bold=True)


def tag(x, y, text, color='acc', size=8):
    return t(x, y, text, size, color, anchor='start', bold=True)


G, W, Y, RD = '#9FD3B8', '#EDEBE3', '#F5C77E', '#FF8A80'


def term(lines, label='terminal · real output', size=8, step=14, x=26, y0=50):
    """Dark terminal panel (360x250 view). lines: [(text, colour)]; text is escaped."""
    import html as _h
    o = f'<rect x="14" y="14" width="332" height="196" rx="8" class="s-board"/><text x="26" y="30" font-size="9" class="mono" style="fill:#7F8C86">{_h.escape(label)}</text>'
    for k, (txt, col) in enumerate(lines):
        o += f'<text x="{x}" y="{y0 + k * step}" font-size="{size}" class="mono" style="fill:{col};white-space:pre" xml:space="preserve">{_h.escape(txt)}</text>'
    return o


def node(x, y, w, h, title, sub='', tone='card', on=True, size=8.4):
    """A component box; dimmed when on is False."""
    op = '' if on else ' opacity=".35"'
    o = f'<g{op}>' + box(x, y, w, h, tone) + t(x + w / 2, y + (h / 2 + 3 if not sub else h / 2 - 2), title, size, bold=True)
    if sub:
        o += t(x + w / 2, y + h / 2 + 10, sub, 7.2, 'ink2')
    return o + '</g>'


def tables(text):
    """Split concatenated Beeline table outputs into a list of tables."""
    import re as _re
    return [p.strip('\n') for p in _re.split(r'\n(?=\+[-+]+\+\n\|[^\n]*\|\n\+[-+]+\+)', text.strip('\n')) if p.strip()]


# ---- Module 4+ helpers
_CAPDIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'lab', 'captures') + os.sep


def capsec(name, a, b=None, drop=()):
    """Text of capture `name` from marker a up to marker b (exclusive); lines containing any of `drop` removed."""
    s = open(_CAPDIR + name).read().rstrip()
    i = s.index(a)
    j = s.index(b, i + len(a)) if b else len(s)
    out = s[i:j].rstrip()
    if drop:
        out = '\n'.join(l for l in out.split('\n') if not any(d in l for d in drop))
    return out


def opbox(x, y, label, sub='', tone='card', w=128, h=26):
    o = box(x, y, w, h, tone) + t(x + w / 2, y + (11 if sub else 16), label, 7.2, 'ink', bold=True)
    if sub:
        o += t(x + w / 2, y + 21, sub, 6.4, 'ink2', mono=True)
    return o


def flow(items, y=40, x0=8, w=74, gap=16, h=30):
    """A left-to-right row of boxes: items = [(label, sub, tone)]."""
    o = ''
    for k, (lab, sub, tone) in enumerate(items):
        x = x0 + k * (w + gap)
        o += opbox(x, y, lab, sub, tone, w, h)
        if k:
            o += arrow(x - gap, y + h / 2, x, y + h / 2, 'ink3', 1.1)
    return o


# ---- Kafka helpers
def figure(aria, content, h=200, caption=''):
    """A wide static figure (640 x h) for image dissection."""
    cap_ = f'<text x="320" y="{h - 10}" text-anchor="middle" font-size="10.5" class="s-ink2">{caption}</text>' if caption else ''
    return f'''    <div class="scene">
      <svg viewBox="0 0 640 {h}" role="img" aria-label="{aria}">
        {content}
        {cap_}
        <text x="632" y="{h - 2}" text-anchor="end" class="s-wm">myphatshala.in</text>
      </svg>
    </div>'''


def pin(x, y, n, color='acc'):
    """Numbered call-out circle."""
    return (f'<circle cx="{x}" cy="{y}" r="8" class="s-{color}" style="fill:var(--{"track" if color == "acc" else color})"/>'
            + t(x, y + 3, str(n), 8, bold=True, extra=' style="fill:#fff"'))


def legend(x, y, items, size=8, gap=15, w=None):
    """Numbered legend lines: [(n, bold, text)]."""
    o = ''
    for k, (n, b, txt) in enumerate(items):
        yy = y + k * gap
        o += pin(x + 8, yy - 3, n) + t(x + 22, yy, b, size, 'ink', anchor='start', bold=True) + t(x + (w or 170), yy, txt, size - 0.4, 'ink2', anchor='start')
    return o


def pcol(x, y, label, cells, tone='blue', cw=34, ch=20, hi=()):
    """A partition drawn as a row of offset cells. cells: list of short strings."""
    o = t(x - 6, y + ch / 2 + 3, label, 8, 'ink', anchor='end', bold=True)
    for k, c in enumerate(cells):
        o += box(x + k * (cw + 2), y, cw, ch, 'acc' if k in hi else tone, rx=3) + t(x + k * (cw + 2) + cw / 2, y + ch / 2 + 3, c, 7, 'ink', mono=True)
    return o


def fields(x, y, items, h=22, size=7.6, gap=4):
    """A row of field boxes [(text, tone, pin_no or None)]; width from text length (mono). Returns svg."""
    o = ''
    for txt, tone, n in items:
        w = len(txt) * size * 0.62 + 12
        o += box(x, y, w, h, tone, rx=3) + t(x + w / 2, y + h / 2 + 3, txt, size, 'ink', mono=True)
        if n:
            o += pin(x + 2, y - 2, n)
        x += w + gap
    return o


# ---- Learning-design helpers (hook, concept map, layer peel, why/how/where)
def hook(question, promise, teasers):
    """Opening hook: one curious question, what you will be able to do, 3 'you will find out' teasers."""
    lis = ''.join(f'<li>{x}</li>' for x in teasers)
    return f'''<div class="callout callout--exam" style="display:block"><p style="font-size:1.12rem;margin:0 0 6px"><b>🤔 {question}</b></p><p style="margin:0 0 6px">{promise}</p><ul style="margin:0 0 0 18px">{lis}</ul></div>
'''


def concept_map(aria, cols, edges, here, links_html, h=230):
    """Beginner/Intermediate/Advanced columns of concept nodes with dependency arrows.
    cols: [[(id, label, sub, href or None)], ...] for B, I, A. edges: [(from_id, to_id)]. here: set of ids taught in this lesson."""
    names = [('Beginner', 'green'), ('Intermediate', 'blue'), ('Advanced', 'violet')]
    pos, o = {}, ''
    for c, (nm, tone) in enumerate(names):
        x = 14 + c * 210
        o += box(x, 8, 196, h - 40, 'card', rx=8) + t(x + 98, 24, nm, 9, tone, bold=True)
        for r, (nid, lab, sub, href) in enumerate(cols[c]):
            y = 36 + r * 38
            node = opbox(x + 14, y, lab, sub, 'acc' if nid in here else tone, 168, 30)
            if href:
                node = f'<a href="{href}">{node}</a>'
            o += node; pos[nid] = (x + 14, y)
    for a, b in edges:
        (x1, y1), (x2, y2) = pos[a], pos[b]
        if x2 > x1:
            o += arrow(x1 + 168, y1 + 15, x2, y2 + 15, 'ink3', 1)
        else:
            o += arrow(x1 + 84, y1 + 30, x2 + 84, y2, 'ink3', 1)
    return figure(aria, o + t(320, h - 18, 'Orange = this lesson · arrows = “you need this first” · click a box to jump', 8, 'ink2'), h=h) + f'  <p class="muted">{links_html}</p>\n'


def peel(title, intro, layers, notes, caps, hid):
    """Layer-by-layer dissection animation: frame k highlights layer k and shows its note."""
    fr = []
    n = len(layers)
    for k in range(n):
        o = t(180, 14, 'Peel it layer by layer', 9, bold=True)
        for i, (nm, sub) in enumerate(layers):
            y = 24 + i * 22
            tone = 'acc' if i == k else ('green' if i < k else 'card')
            o += box(16, y, 150, 19, tone, rx=3) + t(24, y + 13, f'{i + 1}. {nm}', 7.6, 'ink', anchor='start', bold=True)
        o += chip(134, 26 + k * 22, 'event', 'acc', w=30, h=14, size=6.6) + (arrow(149, 26 + k * 22 - 8, 149, 26 + k * 22, 'acc', 1) if k else '')
        o += box(176, 24, 168, n * 22 - 3, 'card', rx=6)
        for j, ln in enumerate(notes[k]):
            o += t(184, 40 + j * 13, ln, 7.4, 'ink' if j == 0 else 'ink2', anchor='start', bold=(j == 0))
        fr.append(o)
    return anim_one('Layer by layer', title, intro, 'Layers', 'Each layer of the system, from your code down to the disk', fr, caps, hid=hid)


def why_how_where(why, how, where, when):
    return cards([('Why', why, 'the problem it solves'), ('How', how, 'the mechanism'),
                  ('Where', where, 'in real systems'), ('When not', when, 'know the limits')])
