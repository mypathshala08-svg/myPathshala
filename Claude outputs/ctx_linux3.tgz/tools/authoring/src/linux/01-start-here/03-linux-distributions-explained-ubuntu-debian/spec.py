import os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', '..', '..', '..'))
from svgkit import scn
from shlesson import pc
sys.path.insert(0, os.path.join(HERE, '..', '..'))
from linuxkit import teaser
BODY = body(HERE)

META = dict(
    module='01-start-here', lesson='03-linux-distributions-explained-ubuntu-debian', n='1.3',
    module_label='Module 1 · Start here: what is Linux?',
    title='Linux distributions explained: Ubuntu, Debian, Fedora, RHEL, Rocky, Arch',
    desc='What a Linux distribution is, the Debian, Red Hat, SUSE, Arch and Alpine families, apt vs dnf, LTS vs rolling releases, support lifecycles and the CentOS end of life, and how to identify any Linux system from /etc/os-release. With animations, real Bash and interview questions.',
    og_desc='Ubuntu, Debian, RHEL, Rocky, Fedora, Arch, Alpine: what really differs, and how to choose. With animations and real commands.',
    minutes=25, level='Beginner → Advanced',
    lead='Riya hears four Linux names in her first week: Ubuntu, RHEL, Alpine and Kali. This lesson explains what a distribution is, the families they belong to, what actually changes between them (mostly how you install software), how long each version is supported, and how to tell in seconds which Linux you are sitting at.',
    chips=['Story-based', '4 animations', 'Real Bash in your browser'],
)

SAMPLES = '''mkdir -p samples
cat > samples/ubuntu <<'EOF'
ID=ubuntu
ID_LIKE=debian
VERSION_ID="24.04"
PRETTY_NAME="Ubuntu 24.04 LTS"
EOF
cat > samples/rocky <<'EOF'
ID="rocky"
ID_LIKE="rhel centos fedora"
VERSION_ID="9.6"
PRETTY_NAME="Rocky Linux 9.6"
EOF
cat > samples/debian <<'EOF'
ID=debian
VERSION_ID="13"
PRETTY_NAME="Debian GNU/Linux 13 (trixie)"
EOF
cat > samples/alpine <<'EOF'
ID=alpine
VERSION_ID=3.22.0
PRETTY_NAME="Alpine Linux v3.22"
EOF
'''

MAIN = SAMPLES + '''for f in samples/*; do
  ( . "$f"
    case " $ID $ID_LIKE " in
      *" debian "*)          tool=apt ;;
      *" rhel "*|*" fedora "*) tool=dnf ;;
      *" alpine "*)          tool=apk ;;
      *)                     tool="?" ;;
    esac
    echo "$PRETTY_NAME -> install with: $tool" )
done
'''

RUN = dict(
    heading='Identify four distributions from their os-release files',
    intro='<p>The script writes shortened copies of the <code>/etc/os-release</code> file from four distributions (version numbers are examples), then reads each one and decides which package tool that system uses. This is exactly how install scripts and automation tools adapt to different Linux systems.</p>',
    code=MAIN,
    anno=[
        ("cat > samples/ubuntu <<'EOF'", 'Creates a small sample file. Real systems have more lines, but these four fields are the important ones.'),
        ('for f in samples/*; do', 'Loops over every file in <code>samples</code> (alphabetical order: alpine, debian, rocky, ubuntu).'),
        ('( . "$f"', '<code>.</code> loads the file’s variables (ID, ID_LIKE, …) into a <b>subshell</b> <code>( )</code>, so each file starts fresh.'),
        ('case " $ID $ID_LIKE " in', 'Debian has no ID_LIKE because it <i>is</i> the base; Ubuntu says <code>ID_LIKE=debian</code>; Rocky says it is like RHEL.'),
        ('echo "$PRETTY_NAME -> install with: $tool"', 'Prints the human name and the package tool for that family.'),
    ],
    tasks=[
        dict(label='1 · Run it', hint='Press <b>Run</b>. Which distribution has no <code>ID_LIKE</code> line, and why does the script still work for it?', code=MAIN),
        dict(label='2 · Predict first', hint='<b>Predict first:</b> what does the OneCompiler machine say about itself? Guess the distribution, then run.',
             code='grep -E "^(PRETTY_NAME|ID|ID_LIKE)=" /etc/os-release\n'),
        dict(label='3 · Spot the error', hint='<b>Spot the error:</b> this line was copied from an Ubuntu tutorial and pasted into a Rocky server’s notes. What is wrong, and what should it be?',
             code='echo "On Rocky Linux run: sudo apt install nginx"\necho "Fix: on Rocky Linux run: sudo dnf install nginx"\n'),
        dict(label='4 · Your turn', hint='Add a sample file for Fedora (<code>ID=fedora</code>, no ID_LIKE) and run the loop again. Does it get dnf?',
             code=SAMPLES + 'printf \'ID=fedora\\nVERSION_ID=43\\nPRETTY_NAME="Fedora Linux 43"\\n\' > samples/fedora\nfor f in samples/*; do ( . "$f"; case " $ID $ID_LIKE " in *" debian "*) t=apt;; *" rhel "*|*" fedora "*) t=dnf;; *" alpine "*) t=apk;; *) t="?";; esac; echo "$PRETTY_NAME: $t" ); done\n'),
        dict(label='5 · Challenge', hint='Count how many of the sample distributions are in the Debian family (ID or ID_LIKE contains debian).',
             code=SAMPLES + 'grep -l "debian" samples/* | wc -l\n'),
    ],
)

PCRUN = dict(
    heading='Run on your PC: identify your own Linux',
    intro='<p>Run these on your own Linux. <b>Outputs were recorded on a real Ubuntu 24.04 cloud VM</b>. On WSL you will usually see Ubuntu too; on a RHEL-family system, <code>ID_LIKE</code> mentions rhel and dnf exists instead of apt.</p>',
    items=[
        dict(title='1 · The full os-release file', cmd='cat /etc/os-release', output=pc('cat /etc/os-release'),
             note='Ubuntu names releases after animals: 24.04 is “Noble Numbat”. <code>ID_LIKE=debian</code> shows its family.'),
        dict(title='2 · The Ubuntu/Debian way', cmd='lsb_release -a', output=pc('lsb_release -a'),
             note='Common on Ubuntu; often not installed on RHEL or in containers, so scripts prefer /etc/os-release.'),
        dict(title='3 · Ubuntu is built on Debian', cmd='cat /etc/debian_version', output=pc('cat /etc/debian_version'),
             note='Ubuntu keeps this Debian file. It shows the Debian development branch Ubuntu was based on.'),
        dict(title='4 · Which package tools exist?', cmd='for pm in apt dnf yum zypper pacman apk; do command -v $pm; done', output=pc('for pm in apt dnf yum zypper pacman apk; do command -v $pm; done'),
             note='Only apt on this Ubuntu machine. On Rocky Linux you would see <code>/usr/bin/dnf</code> and <code>/usr/bin/yum</code>.'),
        dict(title='5 · How many packages are installed?', cmd='dpkg -l | grep -c "^ii"', output=pc('dpkg -l | grep -c "^ii"'),
             note='Every installed .deb package is listed by dpkg with status “ii”. On RHEL the equivalent is <code>rpm -qa | wc -l</code>.'),
    ],
)

TRACE = dict(
    heading='Reading an os-release file, line by line',
    intro='<p>The script writes one sample file, loads it with <code>.</code> and decides the family. Watch the variables <code>ID</code>, <code>ID_LIKE</code> and <code>tool</code> appear in the <b>Shell</b> box.</p>',
    code='''printf 'ID=ubuntu\\nID_LIKE=debian\\nVERSION_ID=24.04\\n' > os-release
cat os-release
. ./os-release
echo "ID is $ID, family is $ID_LIKE"
if [ "$ID_LIKE" = "debian" ]; then tool=apt; else tool=dnf; fi
echo "Install software with: $tool"
''',
    notes={1: 'Write :: printf writes three lines (\\n = new line) into a file named os-release.',
           3: 'Source :: <code>.</code> runs the file in this shell, so each line becomes a variable.',
           5: 'Decide :: <code>[ "$ID_LIKE" = "debian" ]</code> is a test; the family decides the tool.'},
)

WORKED_INTRO = 'Three real tasks: identify the machine you are on, sort a list of servers by family, and find servers whose distribution version is past its end-of-life date.'
EXAMPLES = [
    dict(level='b', tag='Everyday', title='What am I logged in to?',
         problem='<p>Riya has just connected to a new server. In one go she wants its distribution name, its ID, its family and its version.</p>',
         inp='/etc/os-release of the machine',
         approach=['Load <code>/etc/os-release</code> with <code>.</code> inside a subshell.', 'Print the four fields. If ID_LIKE is empty, the distro is a base distro (Debian, Fedora).'],
         code='''(
  . /etc/os-release
  echo "Name   : $PRETTY_NAME"
  echo "ID     : $ID"
  echo "Family : ${ID_LIKE:-$ID (base)}"
  echo "Version: $VERSION_ID"
)
''',
         notes={2: 'Source :: Variables from the file now exist inside this subshell only.', 5: 'Default value :: <code>${ID_LIKE:-…}</code> uses the text after <code>:-</code> when ID_LIKE is empty.'},
         tryit='Run it on OneCompiler: which distribution does it use?'),
    dict(level='i', tag='Operations', title='Group a server list by family',
         problem='<p>The team keeps a simple inventory: one line per server with its name and distribution ID. Print which package tool each server needs.</p>',
         inp='web-01 ubuntu\ndb-01 rhel\netl-01 rocky\nci-01 debian\napi-01 alpine',
         approach=['Write the inventory to a file.', 'Read it line by line with <code>while read name id</code>.', 'Map each ID to a tool with <code>case</code>.'],
         code='''cat > servers.txt <<'EOF'
web-01 ubuntu
db-01 rhel
etl-01 rocky
ci-01 debian
api-01 alpine
EOF
while read -r name id; do
  case $id in
    ubuntu|debian) tool=apt ;;
    rhel|rocky|almalinux|fedora) tool=dnf ;;
    alpine) tool=apk ;;
  esac
  echo "$name ($id) -> $tool"
done < servers.txt
''',
         notes={8: 'Loop :: <code>read</code> takes one line from servers.txt and splits it into name and id.', 14: 'Print :: One line per server. The loop then reads the next line.'},
         tryit='Add “bi-01 almalinux” to the inventory and run again.'),
    dict(level='a', tag='Business problem', title='Which servers are past end of life?',
         problem='<p>An auditor asks: “Which of your servers run a distribution version that no longer receives security updates?” The team has an inventory and a small table of end-of-support dates. Report every server whose date is before today (5 November 2026).</p>',
         inp='inventory: web-01 ubuntu-24.04, old-01 centos-7, rep-01 ubuntu-20.04, db-01 rhel-9\neol dates: centos-7 2024-06-30, ubuntu-20.04 2025-05-31, ubuntu-24.04 2029-05-31, rhel-9 2032-05-31',
         approach=['Store the end-of-support dates in a file and the inventory in another.', 'For each server look up its date with <code>grep</code> and <code>cut</code>.', 'Dates in YYYY-MM-DD form compare correctly as text: <code>[[ $eol < $today ]]</code>.'],
         code='''today=2026-11-05
printf 'centos-7 2024-06-30\\nubuntu-20.04 2025-05-31\\nubuntu-24.04 2029-05-31\\nrhel-9 2032-05-31\\n' > eol.txt
printf 'web-01 ubuntu-24.04\\nold-01 centos-7\\nrep-01 ubuntu-20.04\\ndb-01 rhel-9\\n' > inventory.txt
while read -r server release; do
  eol=$(grep "^$release " eol.txt | cut -d' ' -f2)
  if [[ $eol < $today ]]; then
    echo "UNSUPPORTED: $server runs $release (ended $eol)"
  fi
done < inventory.txt
''',
         notes={5: 'Look up :: grep finds the release’s line; cut takes the second field, the date.', 6: 'Compare :: ISO dates sort like text, so a simple string comparison works.'},
         tryit='Change <code>today</code> to 2030-01-01. Which servers appear now? (End-of-support dates here are for the exercise; always check the vendor’s lifecycle page.)'),
]

QUIZ = mix([
    dict(q='Which pair is in the same distribution family?', options=['Ubuntu and RHEL', 'Ubuntu and Debian', 'Fedora and Arch', 'Alpine and Kali'], answer=1,
         why='Ubuntu is built from Debian. Both use .deb packages and apt.'),
    dict(q='On Rocky Linux you want to install a package. Which tool do you use?', options=['apt', 'dnf', 'pacman', 'apk'], answer=1,
         why='Rocky Linux is in the Red Hat family: .rpm packages with dnf (yum on older versions).'),
    dict(q='What does LTS mean in “Ubuntu 24.04 LTS”?', options=['Linux Terminal System', 'Long-Term Support', 'Latest Test Snapshot', 'Low Throughput Server'], answer=1,
         why='LTS releases come every two years and get 5 years of standard support, which is why servers use them.'),
    dict(q='Which file describes the distribution on almost every modern Linux system?', options=['/etc/hostname', '/etc/os-release', '/proc/version', '/boot/grub.cfg'], answer=1,
         why='/etc/os-release holds NAME, ID, ID_LIKE, VERSION_ID and PRETTY_NAME. /proc/version is about the kernel.'),
    dict(q='Why do many banks choose RHEL or SUSE?', options=['They have the newest software every day', 'Long support lifecycles, paid support and vendor certification', 'They do not use the Linux kernel', 'They have no command line'], answer=1,
         why='Regulated companies need predictable, supported platforms on which their software vendors certify products.'),
    dict(q='What happened to CentOS Linux 7 on 30 June 2024?', options=['It was renamed Rocky Linux', 'It reached end of life: no more updates', 'It became a rolling release', 'It moved to the Debian family'], answer=1,
         why='CentOS Linux ended. Rocky Linux and AlmaLinux are separate projects created as RHEL-compatible alternatives; CentOS Stream continues upstream of RHEL.'),
    dict(q='Ubuntu version 24.04 tells you…', options=['it is the 24th version, 4th update', 'it was released in April 2024', 'it has kernel 24.04', 'it is for 24-core CPUs'], answer=1,
         why='Ubuntu versions are year.month of release.'),
])

REVISION = [
    '<b>Distribution</b> = Linux kernel + GNU tools + package manager + repositories + installer + defaults + support cycle.',
    '<b>Debian family</b>: Debian, Ubuntu, Mint, Kali · <code>.deb</code> · <code>apt</code>/<code>dpkg</code>.',
    '<b>Red Hat family</b>: RHEL, Fedora, CentOS Stream, Rocky, AlmaLinux, Amazon Linux · <code>.rpm</code> · <code>dnf</code>/<code>rpm</code>.',
    'Others: SUSE (<code>zypper</code>), Arch (<code>pacman</code>), Alpine (<code>apk</code>, musl, tiny containers).',
    '<b>LTS/fixed</b> releases for servers; <b>rolling</b> releases for newest software.',
    'Ubuntu LTS: every two years in April, 5 years standard support. RHEL: 10 years per major version.',
    'CentOS Linux ended (8 in 2021, 7 in June 2024); Rocky and Alma are RHEL-compatible replacements.',
    'Identify any system: <code>cat /etc/os-release</code> → ID, ID_LIKE, VERSION_ID.',
]

FAQ = [
    ('What is a Linux distribution?', 'A complete operating system built on the Linux kernel, adding system tools (usually GNU), a package manager and repositories, an installer, default settings and a support lifecycle, maintained by a community or a company.'),
    ('Difference between Debian-based and RHEL-based distributions?', 'Debian-based (Debian, Ubuntu) use .deb packages with apt/dpkg; RHEL-based (RHEL, Rocky, AlmaLinux, Fedora) use .rpm with dnf/rpm. Some paths and names differ (auth.log vs secure, apache2 vs httpd) and RHEL enables SELinux by default while Ubuntu uses AppArmor.'),
    ('What is the difference between Fedora, CentOS Stream and RHEL?', 'Fedora is the fast-moving community distro where new technology appears first. CentOS Stream is the development branch just ahead of the next RHEL minor release. RHEL is the stable, commercially supported product.'),
    ('Why did Rocky Linux and AlmaLinux appear?', 'When CentOS Linux, the popular free RHEL rebuild, was ended in favour of CentOS Stream, these projects were created to continue offering free distributions compatible with RHEL.'),
    ('LTS vs rolling release?', 'An LTS keeps the same package versions for years and only adds security and bug fixes, which suits servers. A rolling release continuously updates to the newest versions, which suits enthusiasts.'),
    ('How do you find which Linux distribution and version a server runs?', '<code>cat /etc/os-release</code> (or <code>lsb_release -a</code> where available). For the kernel version use <code>uname -r</code>.'),
]

PRACTICE_INTRO = 'Small tasks about identifying and grouping distributions. Expected outputs are from real runs on Ubuntu 24.04.'
PROBLEMS = [
    dict(level='easy', title='Print only the distro name', stmt='Print just the value of PRETTY_NAME, without quotes.', inp='/etc/os-release',
         code="grep '^PRETTY_NAME=' /etc/os-release | cut -d'\"' -f2\n", explain='<code>cut -d\'"\' -f2</code> splits the line at double quotes and keeps the second piece: the text between the quotes.'),
    dict(level='easy', title='Debian family or not?', stmt='Print “Debian family” if <code>/etc/debian_version</code> exists, otherwise “Not Debian family”.', inp='(the machine)',
         code='if [ -f /etc/debian_version ]; then\n  echo "Debian family"\nelse\n  echo "Not Debian family"\nfi\n', explain='<code>-f</code> tests whether a regular file exists. Ubuntu and Debian have this file; RHEL-family systems do not.'),
    dict(level='easy', title='Version from the version string', stmt='Given <code>VERSION_ID="24.04"</code>, print the year and month of release as “Released 20&lt;yy&gt;-&lt;mm&gt;”.', inp='24.04',
         code='v=24.04\necho "Released 20${v%%.*}-${v#*.}"\n', explain='<code>${v%%.*}</code> removes everything from the first dot (24); <code>${v#*.}</code> removes everything up to the dot (04). Shell string tricks are covered in the Shell Scripting course.'),
    dict(level='medium', title='Count servers per tool', stmt='From the inventory, count how many servers need apt and how many need dnf.', inp='web-01 ubuntu\nweb-02 debian\ndb-01 rhel\netl-01 rocky\nci-01 ubuntu',
         code="printf 'web-01 ubuntu\\nweb-02 debian\\ndb-01 rhel\\netl-01 rocky\\nci-01 ubuntu\\n' > inv.txt\necho \"apt: $(grep -cE ' (ubuntu|debian)$' inv.txt)\"\necho \"dnf: $(grep -cE ' (rhel|rocky)$' inv.txt)\"\n",
         explain='<code>grep -cE</code> counts lines matching an extended regex. <code>( a|b )</code> means either word, <code>$</code> the end of the line.'),
    dict(level='medium', title='Base distro or derivative?', stmt='For each sample (ID, ID_LIKE) pair, print “base” if ID_LIKE is empty, otherwise “derivative of …”.', inp='ubuntu:debian\ndebian:\nrocky:rhel',
         code="for pair in ubuntu:debian debian: rocky:rhel; do\n  id=${pair%%:*}; like=${pair#*:}\n  if [ -z \"$like\" ]; then echo \"$id: base\"; else echo \"$id: derivative of $like\"; fi\ndone\n",
         explain='<code>-z</code> is true for an empty string. The pair is split at the colon with the same shell tricks as P3.'),
    dict(level='medium', title='Which package manager is installed?', stmt='Print the first package manager found among apt, dnf, yum, zypper, pacman, apk.', inp='(the machine)',
         code='for pm in apt dnf yum zypper pacman apk; do\n  if command -v "$pm" >/dev/null; then echo "Package manager: $pm"; break; fi\ndone\n',
         explain='<code>command -v</code> succeeds if the command exists; its output is thrown away with <code>>/dev/null</code>. <code>break</code> stops at the first match.'),
    dict(level='business', title='Audit: how many servers are unsupported?', stmt='Using the EOL table and inventory below, print the number of unsupported servers as of 2026-11-05.', inp='eol: centos-7 2024-06-30, ubuntu-20.04 2025-05-31, ubuntu-24.04 2029-05-31\ninventory: a centos-7, b ubuntu-24.04, c ubuntu-20.04, d centos-7',
         code="today=2026-11-05\nprintf 'centos-7 2024-06-30\\nubuntu-20.04 2025-05-31\\nubuntu-24.04 2029-05-31\\n' > eol.txt\nprintf 'a centos-7\\nb ubuntu-24.04\\nc ubuntu-20.04\\nd centos-7\\n' > inv.txt\nn=0\nwhile read -r s r; do\n  e=$(grep \"^$r \" eol.txt | cut -d' ' -f2)\n  [[ $e < $today ]] && n=$((n+1))\ndone < inv.txt\necho \"Unsupported servers: $n\"\n",
         explain='Same lookup as worked example 3, but counting with <code>n=$((n+1))</code>. <code>&amp;&amp;</code> runs the count only when the date test is true.'),
    dict(level='business', title='Docker base image size check', stmt='A team lists base images and their sizes in MB. Print the smallest image and its size.', inp='ubuntu:24.04 78\ndebian:stable-slim 75\nalpine:3.22 8\nrockylinux:9-minimal 92',
         code="printf 'ubuntu:24.04 78\\ndebian:stable-slim 75\\nalpine:3.22 8\\nrockylinux:9-minimal 92\\n' > images.txt\nsort -k2 -n images.txt | head -1\n",
         explain='<code>sort -k2 -n</code> sorts by the second column as numbers; <code>head -1</code> keeps the smallest. (Sizes here are example numbers for the exercise.)'),
]

SCN_INTRO = 'How interviewers check your understanding of distributions in real company situations.'
SCENARIOS = (
    scn('IT services · fresher', 'Fresher', '“Which Linux have you worked on?”',
        'You learnt on Ubuntu. The interviewer says the client project runs RHEL 9. “Can you work on it?”',
        'do you know what transfers and what differs?',
        '''<ul>
          <li>Yes: the kernel, shell, core commands, permissions, processes and systemd work the same.</li>
          <li>Differences I would expect: <code>dnf</code>/<code>rpm</code> instead of <code>apt</code>/<code>dpkg</code>, some package and log names (<code>httpd</code>, <code>/var/log/secure</code>), and SELinux enabled by default.</li>
          <li>I would check <code>/etc/os-release</code> first and read the RHEL documentation for those parts.</li>
        </ul>''', '“Linux is Linux, no difference” or “I only know Ubuntu”.') +
    scn('Startup · design', 'Junior', 'Choosing a distro for production',
        'Your startup is moving its app from a laptop to cloud servers. The CTO asks you to suggest a distribution.',
        'do you choose by support, ecosystem and team skills?',
        '''<ol>
          <li>Prefer a fixed release with long support: Ubuntu LTS, or a RHEL-compatible distro (Rocky Linux / AlmaLinux) if the team or customers prefer the Red Hat family.</li>
          <li>Check that our runtime, database and tools officially support it, and that the cloud offers maintained images.</li>
          <li>Standardise on one distro and version across servers and containers to keep scripts simple.</li>
        </ol>''', 'picking a rolling distro for production, or choosing by what looks nicest on a desktop.') +
    scn('Enterprise · operations', 'Mid-level', 'An end-of-life server',
        'An audit finds five servers still on CentOS 7. Your manager asks what the risk is and what you propose.',
        'do you understand lifecycles and safe migration?',
        '''<ul>
          <li>Risk: CentOS 7 reached end of life on 30 June 2024, so it gets no security patches; any new vulnerability stays open.</li>
          <li>Options: migrate to Rocky Linux or AlmaLinux (same family, least change), RHEL with support, or re-platform on Ubuntu LTS.</li>
          <li>Plan: inventory apps, test on a copy, migrate in small waves with backups and rollback, then add EOL dates to monitoring so it does not happen again.</li>
        </ul>''', '“It still works, so it is fine.”') +
    scn('Product company · containers', 'Mid-level', 'Alpine image breaks the app',
        'The team switched the Docker base image from Debian slim to Alpine to save space. A Python package with compiled parts now fails to install or crashes.',
        'do you know Alpine’s main difference?',
        '''<ul>
          <li>Alpine uses the musl C library instead of glibc; some pre-built binaries (wheels) are made for glibc, so they need compiling or behave differently.</li>
          <li>Options: install build tools and compile, use musl-compatible packages, or go back to a slim glibc image (Debian/Ubuntu slim). A slightly larger image that works is better than a tiny one that breaks.</li>
        </ul>''', 'blaming Docker or Python without checking the base image.')
) + teaser('1.4', 'Riya’s backup script runs fine on Windows and refuses to run on Linux, though the text looks exactly the same. What is hiding in the file that she cannot see?')

from linuxkit import mindmap
MINDMAP = mindmap('Distributions', [
    ('What a distro is', 'acc', ['kernel + GNU tools', 'package manager + repos', 'defaults + support']),
    ('Debian family', 'green', ['Debian, Ubuntu, Mint', '.deb · apt · dpkg', 'AppArmor, auth.log']),
    ('Red Hat family', 'red', ['RHEL, Fedora, Rocky', '.rpm · dnf · rpm', 'SELinux, /var/log/secure']),
    ('Others', 'violet', ['SUSE: zypper', 'Arch: pacman (rolling)', 'Alpine: apk, musl']),
    ('Release models', 'blue', ['LTS: 5 yrs (Ubuntu)', 'RHEL: 10 years', 'rolling: always newest']),
    ('Identify a system', 'amber', ['cat /etc/os-release', 'ID and ID_LIKE', 'uname -r = kernel only']),
])
