import os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', '..'))
from linuxkit import *

# ---------------------------------------------------------------- 1. story
opts = [(20, 'WSL', 'inside Windows', 'green'), (140, 'VirtualBox VM', 'a PC inside a PC', 'blue'), (260, 'Dual boot', 'choose at start-up', 'amber'), (380, 'Cloud VM', 'rented by the hour', 'violet'), (500, 'Browser', 'this website', 'acc')]
sc = ''.join(label_box(x, 24, 112, 46, [n, u], tone, 8.6) for x, n, u, tone in opts)
sc += t(320, 100, 'Riya’s laptop: Windows 11, 8 GB RAM, 512 GB SSD, college assignments on it.', 9, 'ink2')
sc += t(320, 118, 'She cannot risk losing her files. Which way is safest and fastest?', 9, 'acc', bold=True)
story = '''<section class="part" id="story">
  <span class="part-label"><b>1</b> The story</span>
  <h2>“I can’t wipe my laptop for this”</h2>
  <div class="story">
''' + puzzle('WSL gives Riya a real Ubuntu inside Windows in ten minutes, without touching her disk partitions. But Linux needs a <b>Linux kernel</b>, and Windows has its own, different kernel. So where does the Linux kernel come from, and where do Ubuntu’s files actually live?') + '''
    <p class="narration">Arjun Sir asks every learner to practise Linux daily. Riya has one laptop with Windows 11, all her college assignments and her internship documents on it. A senior once told her that installing Linux “formatted his whole disk”. She wants Linux, but not at the cost of her files.</p>
''' + scene('Five ways to get Linux: WSL, a VirtualBox VM, dual boot, a cloud VM and the browser runner, next to Riya’s Windows laptop.', sc,
            'Five ways to get Linux. <tspan font-weight="700" class="s-acc">Only one of them touches your disk partitions.</tspan>') + '''
R> Sir, my senior lost everything when he installed Linux. I really can’t afford that.
A> He chose <b>dual boot</b> and made a mistake while partitioning. You do not need to. On Windows 10 or 11 the easiest way is <b>WSL</b>: one command, a restart, and you have a real Ubuntu inside Windows. Your files are not touched.
K> I use WSL every day for work. VS Code opens my Linux folders directly. And when I want to break things safely, I use a VirtualBox VM.
R> And the cloud? Neha said our servers are “VMs on AWS”.
A> A cloud VM is a real server you rent. Great practice for SSH, but you must remember to stop it, or it keeps billing. Today you will learn all five ways, when to use each, and you will install WSL step by step. You can also keep using the runner on this website from any device.
  </div>
</section>
'''

# ---------------------------------------------------------------- 2. definition
lv = levels4('Getting Linux at four depths', [
    ('v', 'No jargon: five ways to try a new dish', '''      <p>Getting Linux is like trying a new dish. There are five ways, from “just taste it” to “build a second kitchen”.</p>''' + '''<div class="scene"><svg viewBox="0 0 640 210" role="img" aria-label="Five ways to get Linux compared to trying a dish: food-court sample (browser), corner of your own kitchen (WSL), toy kitchen inside your kitchen (virtual machine), building a second kitchen (dual boot), renting a restaurant kitchen by the hour (cloud VM). A risk bar grows only for dual boot.">''' + ''.join(label_box(10 + k * 126, 14, 116, 70, [a, b, c], tone, 8.6) for k, (a, b, c, tone) in enumerate([('Food-court sample', 'a quick taste', 'Browser runner', 'acc'), ('Corner of your', 'own kitchen', 'WSL', 'green'), ('Toy kitchen inside', 'your kitchen', 'Virtual machine', 'blue'), ('Build a second', 'kitchen', 'Dual boot', 'amber'), ('Rent a restaurant', 'kitchen hourly', 'Cloud VM', 'violet')])) + t(14, 112, 'Risk to your own files:', 9, 'ink2', anchor='start', bold=True) + ''.join(fill(20 + k * 126, 122, w, 12, col, rx=4) + t(70 + k * 126, 150, lab, 8.4, 'ink2') for k, (w, col, lab) in enumerate([(8, 'green', 'none'), (8, 'green', 'none'), (8, 'green', 'none'), (100, 'red', 'real: partitioning'), (8, 'green', 'none (but a bill)')])) + t(320, 182, 'Start with the browser and WSL. Add a VM to experiment. Dual boot only after a full backup.', 9, 'acc', bold=True) + '''<text x="632" y="204" text-anchor="end" class="s-wm">myphatshala.in</text></svg></div>''' + '''
      <ul>
        <li><b>Browser runner</b>: taste Linux right now on this page. Nothing to install.</li>
        <li><b>WSL</b>: Linux cooks in a corner of your Windows kitchen. Recommended for this course.</li>
        <li><b>Virtual machine</b>: a toy kitchen inside your kitchen; break anything, nothing real is harmed.</li>
        <li><b>Dual boot</b>: a second kitchen. Powerful, but building it can damage the first one.</li>
        <li><b>Cloud VM</b>: rent a professional kitchen by the hour. Remember to hand back the keys (stop it).</li>
      </ul>'''),
    ('b', 'Five kinds of homes for Linux', '''      <ul>
        <li><b>Browser runner</b>: a room in a hotel. Walk in, use it, leave. Nothing installed (every “Run the code” box on this site).</li>
        <li><b>WSL</b>: a guest room inside your own house (Windows). Linux lives next to Windows and shares the furniture (files).</li>
        <li><b>Virtual machine</b>: a doll’s house inside your house. A complete pretend computer; break anything, nothing outside is affected.</li>
        <li><b>Dual boot</b>: divide your plot into two houses. Each start-up you choose Windows or Linux. Most power, most risk.</li>
        <li><b>Cloud VM</b>: rent a flat in another city. A real server reachable over the internet; you pay rent while it runs.</li>
      </ul>'''),
    ('i', 'What each option needs', '''      <ul>
        <li><b>WSL</b>: Windows 10 version 2004 (build 19041) or later, or Windows 11; one command <code>wsl --install</code> in an administrator PowerShell; a restart. Installs Ubuntu with WSL 2 by default.</li>
        <li><b>VirtualBox</b>: an <b>ISO</b> file (the installer image) of a distro, hardware virtualisation enabled in BIOS/UEFI (Intel VT-x / AMD-V), 2 GB+ RAM and 25 GB disk for the VM.</li>
        <li><b>Dual boot</b>: a USB stick, a full backup, free unpartitioned space, and care with the partitioning screen. Turn off Windows Fast Startup.</li>
        <li><b>Cloud VM</b>: an account with a cloud provider, an SSH key pair, and a firewall rule (security group) allowing SSH only from your IP. Stop or delete the VM when done.</li>
        <li><b>Always verify the ISO</b>: compare its SHA-256 checksum with the one on the distro’s website (Lesson 19.4).</li>
      </ul>'''),
    ('a', 'How WSL 2 really works, and its traps', '''      <ul>
        <li>WSL 2 runs a <b>real Linux kernel</b> (built by Microsoft) inside a lightweight utility virtual machine using Hyper-V technology. It starts in about a second and shares memory with Windows dynamically.</li>
        <li>Each distro’s files live in a virtual disk (<code>ext4.vhdx</code>). Windows drives appear in Linux under <code>/mnt/c</code>, <code>/mnt/d</code>; Linux files appear in Windows Explorer under <code>\\\\wsl.localhost\\Ubuntu</code>.</li>
        <li><b>Performance trap</b>: Linux tools working on files under <code>/mnt/c</code> cross the VM boundary and are much slower. Keep projects in your Linux home (<code>~/projects</code>).</li>
        <li>WSL supports <b>systemd</b> (enable it in <code>/etc/wsl.conf</code> under <code>[boot]</code> if your distro has not), so services like Docker and databases work as on a server.</li>
        <li><code>wsl --shutdown</code> stops the VM; <code>wsl -l -v</code> lists distros and their WSL version; <code>wsl --set-version Ubuntu 2</code> converts an old WSL 1 install.</li>
      </ul>'''),
])

definition = '''<section class="part" id="definition">
  <span class="part-label"><b>2</b> Definition</span>
  <h2>WSL, virtual machines and where Linux can run</h2>
''' + def_block(
    'A <b>virtual machine (VM)</b> is a software emulation of a complete computer, with virtual CPUs, memory, disks and network, created and managed by a <b>hypervisor</b> (such as VirtualBox, VMware, Hyper-V or KVM) on a physical host. The <b>Windows Subsystem for Linux (WSL)</b> is a Windows feature that runs Linux distributions directly on Windows; WSL 2 does this by running a genuine Linux kernel inside a lightweight, Windows-managed virtual machine.',
    'A VM is a pretend computer running inside your real one. WSL is Microsoft’s ready-made, very light VM that gives you a real Ubuntu inside Windows with one command.') + '''

  <h3>Words you’ll meet in this lesson</h3>
''' + terms([
    ('WSL / WSL 2', f'Linux inside Windows; WSL 2 uses a real Linux kernel. {gl("wsl-windows-subsystem-for-linux", "Glossary →")}'),
    ('Virtual machine', f'A complete computer emulated in software. {gl("virtual-machine-vm", "Glossary →")}'),
    ('Hypervisor', 'The software that creates and runs VMs: VirtualBox, VMware, Hyper-V, KVM.'),
    ('Host / guest', 'Host = your real computer and OS. Guest = the OS running inside the VM.'),
    ('ISO file', 'An image of an installation disc, e.g. <code>ubuntu-24.04-desktop-amd64.iso</code>.'),
    ('Dual boot', 'Two operating systems on separate partitions; you choose one at start-up.'),
    ('Boot loader', f'The program that offers the OS choice at start-up (GRUB). {gl("boot-loader-grub", "Glossary →")}'),
    ('Cloud instance', 'A VM rented from AWS (EC2), Azure or Google Cloud, reached over SSH.'),
    ('Virtualisation (VT-x / AMD-V)', 'CPU features that let VMs run fast. Must be enabled in BIOS/UEFI.'),
    ('sudo', f'Run one command as the administrator. Needed for installing software. {gl("sudo", "Glossary →")}'),
]) + '''

  <h3>Quick facts</h3>
''' + facts([
    ('Install WSL', '<code>wsl --install</code> in PowerShell as administrator, then restart'),
    ('WSL requirements', 'Windows 10 version 2004 (build 19041) or later, or Windows 11'),
    ('Default distro and version', 'Ubuntu, WSL 2'),
    ('List available distros', '<code>wsl --list --online</code>; install one with <code>wsl --install -d &lt;name&gt;</code>'),
    ('Minimum for a desktop VM', 'About 2 vCPUs, 4 GB RAM, 25 GB disk (a server VM needs less)'),
    ('Checksum to verify an ISO', 'SHA-256, published on the distro’s download page'),
]) + '\n' + names('Installation is full of short forms. Here is what they stand for.', [
    ('WSL', 'Windows Subsystem for Linux', 'Linux living inside Windows.'),
    ('VM', 'virtual machine', 'A pretend computer made of software.'),
    ('ISO', 'from the ISO 9660 standard', 'The CD-ROM file-system standard; an .iso is an image of an install disc.'),
    ('VDI', 'VirtualBox Disk Image', 'The file that is the VM’s whole hard disk.'),
    ('UEFI', 'Unified Extensible Firmware Interface', 'The modern replacement for BIOS that starts your PC.'),
    ('GRUB', 'GRand Unified Bootloader', 'The menu that lets you choose Windows or Linux at start-up.'),
    ('sudo', 'superuser do', 'Do this one command as the administrator.'),
    ('apt', 'Advanced Package Tool', 'Ubuntu’s software installer.'),
]) + '\n' + lv + didyou('The Linux kernel used by WSL 2 is built and maintained by Microsoft, and its source code is published as open source, as the GPL requires (Lesson 1.4). A company famous for Windows now ships a Linux kernel with it.') + '''
EXAM> “Explain virtualisation and the difference between a VM and dual booting” → define VM and hypervisor (type 1 bare-metal vs type 2 hosted), host vs guest, list advantages (isolation, snapshots, several OSes at once) and contrast with dual boot (one OS at a time, full hardware speed, partitioning risk).
''' + qc('Is WSL 2 a virtual machine?', 'Yes, a very lightweight one managed by Windows, running a real Linux kernel. It starts in about a second and shares memory with Windows as needed.') + '''
</section>
'''

# ---------------------------------------------------------------- 3. types
types = '''<section class="part" id="types">
  <span class="part-label"><b>3</b> Types and ways to use it</span>
  <h2>Five ways to get Linux, compared</h2>
''' + table(['', 'Browser runner', 'WSL 2', 'VirtualBox VM', 'Dual boot', 'Cloud VM'], [
    ['Setup time', '0 min', '10–15 min', '30–45 min', '1–2 hours', '10 min'],
    ['Risk to your files', 'None', 'None', 'None', '<b>Real</b> (partitioning)', 'None'],
    ['Full Linux (sudo, services)', 'No', 'Yes', 'Yes', 'Yes', 'Yes'],
    ['Graphical desktop', 'No', 'Apps only', 'Yes', 'Yes', 'Usually no'],
    ['Speed', '—', 'Near native', 'Slower (shares host)', 'Full speed', 'Depends on size'],
    ['Cost', 'Free', 'Free', 'Free', 'Free', 'Pay per hour (free credits for new accounts)'],
    ['Best for', 'Quick practice on any device', '<b>This course</b> on Windows', 'Breaking things safely, snapshots', 'Daily Linux on your own PC', 'SSH, servers, DevOps practice'],
], minw=760) + '''

  <h3>On a Mac?</h3>
''' + cards([
    ('Terminal app', 'macOS already has a Unix terminal (zsh). Most commands in Modules 2–7 work; remember the BSD vs GNU differences from Lesson 1.4.', 'built in'),
    ('A Linux VM', 'UTM or Parallels (Apple silicon) or VirtualBox (Intel Macs) with an ARM or x86 Ubuntu image.', 'full Linux'),
    ('Multipass or Docker', 'Start an Ubuntu VM or container with one command, then work in it like a server.', 'developer way'),
]) + '''
  <h3>Recommended path for this course</h3>
''' + cards([
    ('Windows 10/11', 'WSL 2 with Ubuntu. Add VirtualBox later when you want a desktop or snapshots.', 'recommended'),
    ('macOS', 'Terminal for basics, plus an Ubuntu VM (UTM/Multipass) for system administration modules.', 'recommended'),
    ('Any device, even a phone', 'The browser runner on every lesson. Not enough for sudo, services or networking modules.', 'anywhere'),
    ('Want server practice', 'A small cloud VM for Modules 15–21 (SSH, firewalls, services). Stop it when idle.', 'later'),
]) + '''
''' + qc('Of the five ways to get Linux, which one can actually put your existing files at risk?', 'Dual boot, because it needs disk partitioning. WSL, VMs, cloud VMs and the browser never touch your partitions.') + '''
</section>
'''

# ---------------------------------------------------------------- 4. steps: install WSL
steps = '''<section class="part" id="steps">
  <span class="part-label"><b>4</b> Step by step</span>
  <h2>Install Ubuntu with WSL on Windows</h2>
  <p>About 15 minutes, most of it downloading. Follow along on your own laptop.</p>
''' + stepper([
    ('1. Open PowerShell as administrator', '<p>Start menu → type <b>PowerShell</b> → right-click → <b>Run as administrator</b>.</p>', 'Behind the screen: enabling Windows features needs admin rights, just like sudo on Linux.'),
    ('2. Run the install command', '<p><code>wsl --install</code></p>', 'Behind the screen: Windows enables the “Virtual Machine Platform” and WSL features, downloads the WSL Linux kernel and the Ubuntu image. If you only see help text, WSL is already installed: run <code>wsl --install -d Ubuntu</code>.'),
    ('3. Restart the computer', '<p>Required once, so the new Windows features load.</p>', 'Behind the screen: the hypervisor component starts during boot.'),
    ('4. Create your Linux user', '<p>Ubuntu opens and asks for a <b>new UNIX username</b> and <b>password</b>. Use lower case and no spaces, for example <code>riya</code>.</p>',
     'Behind the screen: this creates a normal Linux user (not root) and gives it sudo rights. While you type the password <b>nothing appears</b>, not even stars. That is normal on Linux.'),
    ('5. Update the system', '<p><code>sudo apt update &amp;&amp; sudo apt upgrade -y</code></p>', 'Behind the screen: apt downloads the latest package lists and installs security updates (Module 14).'),
    ('6. Check everything works', '<p><code>whoami</code>, <code>pwd</code>, <code>cat /etc/os-release</code>, and in PowerShell <code>wsl -l -v</code> should show VERSION 2.</p>', 'Behind the screen: VERSION 2 means a real Linux kernel. Version 1 is the older translation layer.'),
    ('7. Work in your Linux home', '<p><code>mkdir ~/projects</code>; open the folder from Windows with <code>explorer.exe .</code> or in VS Code with <code>code .</code></p>', 'Behind the screen: files under <code>~</code> are inside the Linux virtual disk: fast for Linux tools. <code>/mnt/c</code> is your C: drive, slower from Linux.'),
]) + '''
  <div class="callout callout--warn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3 2 21h20L12 3z"/><path d="M12 10v5M12 18v.5"/></svg><p><b>Choosing dual boot?</b> Back up everything first, read the installer screens slowly, never choose “Erase disk” unless you mean it, and turn off Windows Fast Startup and BitLocker prompts as the distro’s guide explains.</p></div>
''' + '''
  <h3 id="virtualbox">Option B: Ubuntu in VirtualBox, step by step</h3>
  <p>Use this when you want a full Ubuntu desktop, snapshots you can roll back to, or you are on a computer where WSL is not allowed.</p>
''' + stepper([
    ('1. Download VirtualBox and an Ubuntu ISO', '<p>VirtualBox from virtualbox.org for your OS; the Ubuntu Desktop LTS ISO from ubuntu.com. Verify the ISO with <code>sha256sum</code> (Windows: <code>certutil -hashfile file.iso SHA256</code>).</p>', 'Behind the screen: the checksum proves the ISO was not corrupted or tampered with (Lesson 19.4).'),
    ('2. Make sure virtualisation is on', '<p>If VirtualBox complains about VT-x/AMD-V, enable “Intel Virtualization Technology” or “SVM” in your BIOS/UEFI settings.</p>', 'Behind the screen: these CPU features let the guest run at near-native speed.'),
    ('3. Create the VM', '<p>New → name <i>ubuntu-lab</i> → choose the ISO → type Linux, Ubuntu (64-bit) → <b>4 GB RAM, 2 CPUs</b> → a <b>25 GB dynamically allocated</b> disk.</p>', 'Behind the screen: the VM’s disk is one file (.vdi) on your Windows drive; “dynamically allocated” means it grows only as Ubuntu uses space.'),
    ('4. Install Ubuntu inside the VM', '<p>Start the VM, choose <b>Install Ubuntu</b>, keyboard, then “Erase disk and install Ubuntu”, user name and password.</p>', 'Behind the screen: “Erase disk” here erases only the <b>virtual</b> disk file, never your real one. Inside a VM it is safe.'),
    ('5. Add Guest Additions', '<p>Devices → Insert Guest Additions CD image → run it → restart. Now the screen resizes, copy-paste works and shared folders are possible.</p>', 'Behind the screen: Guest Additions are drivers inside Ubuntu that talk to VirtualBox.'),
    ('6. Take a snapshot', '<p>Machine → Take Snapshot → “fresh install”. Before any risky experiment, take another.</p>', 'Behind the screen: a snapshot freezes the disk state; restoring it takes seconds.'),
]) + '''
  <h3 id="transfer">Moving files between Windows and Linux</h3>
''' + table(['Situation', 'Easiest way'], [
    ['Windows ↔ WSL', 'From WSL: <code>/mnt/c/Users/&lt;you&gt;/…</code>. From Windows: <code>\\\\wsl.localhost\\Ubuntu</code> in Explorer, or <code>explorer.exe .</code> inside WSL.'],
    ['Windows ↔ VirtualBox VM', 'A shared folder (needs Guest Additions), or drag-and-drop when enabled.'],
    ['Windows ↔ a server or cloud VM', '<code>scp file.zip user@server:~/</code> from a terminal, or a graphical SFTP tool such as WinSCP (Lesson 16.6).'],
], minw=520) + qc('You typed your password for sudo and nothing appeared on the screen. What should you do?', 'Nothing is wrong: Linux hides password input completely. Type the whole password and press Enter.') + '''
</section>
'''

# ---------------------------------------------------------------- 5. animations
see = [term(20, 18, 320, 130, [('PS C:\\> wsl --install', 'acc')], title='Windows PowerShell (Administrator)') + t(180, 172, 'Riya runs one command as administrator.', 9, 'ink2'),
       term(20, 18, 320, 130, [('PS C:\\> wsl --install', 'acc'), ('Installing: Virtual Machine Platform', 'out'), ('Installing: Windows Subsystem for Linux', 'out'), ('Installing: Ubuntu', 'out')], title='Windows PowerShell (Administrator)') + t(180, 172, 'Typical messages while it installs.', 9, 'ink2'),
       term(20, 18, 320, 130, [('The requested operation is successful.', 'out'), ('Changes will not be effective until', 'out'), ('the system is rebooted.', 'out')], title='Windows PowerShell (Administrator)') + t(180, 172, 'She restarts the laptop.', 9, 'ink2'),
       term(20, 18, 320, 130, [('Enter new UNIX username: riya', 'out'), ('New password:', 'out'), ('Retype new password:', 'out'), ('passwd: password updated successfully', 'out')], title='Ubuntu') + t(180, 172, 'First start: she creates her Linux user.', 9, 'ink2'),
       term(20, 18, 320, 130, ['$ whoami', 'riya', '$ grep PRETTY /etc/os-release', 'PRETTY_NAME="Ubuntu 24.04 LTS"', '$ '], title='riya@laptop: ~', cursor=True) + t(180, 172, 'A real Ubuntu, inside Windows.', 9, 'green', bold=True)]
def wsl_layers(hl, extra=''):
    o = label_box(10, 14, 340, 28, ['Windows 11 (your files, apps)'], 'card' if 0 not in hl else 'blue', 8.8)
    o += label_box(10, 50, 340, 30, ['Hyper-V utility VM (lightweight)'], 'card' if 1 not in hl else 'acc', 8.8)
    o += label_box(20, 86, 150, 30, ['Linux kernel (WSL)'], 'card' if 2 not in hl else 'blue', 8.6)
    o += label_box(180, 86, 160, 30, ['Ubuntu files: ext4.vhdx'], 'card' if 3 not in hl else 'green', 8.6)
    o += label_box(20, 122, 320, 26, ['user riya · bash · apt'], 'card' if 4 not in hl else 'green', 8.6)
    return o + extra
behind = [wsl_layers([0]) + t(180, 172, 'Admin rights let it change Windows features.', 8.8, 'ink2'),
          wsl_layers([1, 2, 3]) + t(180, 172, 'It enables the VM platform and downloads kernel + Ubuntu.', 8.8, 'ink2'),
          wsl_layers([1]) + t(180, 172, 'After the restart, the hypervisor layer is active.', 8.8, 'ink2'),
          wsl_layers([3, 4]) + t(180, 172, 'Ubuntu’s files are unpacked; user riya is created with sudo.', 8.8, 'ink2'),
          wsl_layers([2, 3, 4]) + t(180, 172, 'Commands run on the real Linux kernel inside the VM.', 8.8, 'green', bold=True)]
two = anim_two('wsl --install', 'From Windows to Ubuntu in one command', 'PowerShell running wsl --install, a restart, creating a Linux user, and running whoami in Ubuntu.',
               'Layers created by WSL: Windows, a Hyper-V utility VM, the WSL Linux kernel, Ubuntu’s virtual disk and the user riya.', see, behind,
               ['In an administrator PowerShell Riya types <code>wsl --install</code>.',
                'Windows installs the needed components and Ubuntu. (Messages shown are typical; exact wording varies by Windows version.)',
                'Windows asks for a restart to activate the new features.',
                'Ubuntu opens for the first time and asks for a new username and password. The password does not show while typing.',
                'Now <code>whoami</code> and <code>/etc/os-release</code> prove she is inside Ubuntu.'],
               ['Changing Windows features needs administrator rights.',
                'WSL 2 adds a lightweight virtual machine, a Linux kernel built by Microsoft, and a distribution image (Ubuntu by default).',
                'The hypervisor layer starts with Windows after the reboot.',
                'Ubuntu’s whole file system lives in a virtual disk file. Your Linux user is created inside it and added to the sudo group.',
                'From now on, commands like <code>ls</code> run on a genuine Linux kernel. Windows files remain where they were, reachable at <code>/mnt/c</code>.'])

# scenario 1: invisible password
pa = term(20, 20, 320, 110, ['$ sudo apt update', ('[sudo] password for riya: ', 'out')], cursor=True) + cap('sudo asks for Riya’s password.', '', 'card', y=150, h=34)
pb = term(20, 20, 320, 110, ['$ sudo apt update', ('[sudo] password for riya: ', 'out')]) + t(180, 112, 'She types… nothing appears!', 9, 'red', bold=True) + cap('No stars, no dots. Is the keyboard broken?', '', 'red', y=150, h=34)
pc_ = term(20, 20, 320, 110, ['$ sudo apt update', ('[sudo] password for riya: ', 'out')]) + t(180, 112, 'Every key IS received, just not shown.', 9, 'green', bold=True) + cap('Linux hides passwords completely,', 'so nobody can even count the letters.', 'blue', y=150, h=44)
pd = term(20, 20, 320, 110, ['$ sudo apt update', ('[sudo] password for riya:', 'out'), ('Hit:1 http://archive.ubuntu.com/ubuntu noble', 'dim'), ('Reading package lists... Done', 'out')]) + cap('She types it fully and presses Enter. It works.', '', 'green', y=150, h=34)
pe = (t(180, 30, 'Remember', 10.5, 'acc', bold=True) + ''.join(t(26, 56 + k * 19, s, 8.6, anchor='start') for k, s in enumerate(['• sudo asks for YOUR password, not root’s.', '• Nothing is echoed: type carefully, press Enter.', '• After success, sudo remembers you for a few minutes.', '• Forgot the WSL password? It can be reset from PowerShell.'])) + cap('The most common first-day panic, solved.', '', 'green', y=150, h=34))
s1 = anim_one('Real-time scenario 1', 'The invisible password',
              'Almost every beginner thinks their keyboard stopped working the first time Linux asks for a password. Watch what really happens.',
              'Typing a password on Linux', 'A terminal asks for the sudo password; nothing appears while typing; after Enter the command runs.', [pa, pb, pc_, pd, pe],
              ['Riya runs <code>sudo apt update</code>. sudo asks for her own password.',
               'She types, and nothing appears on the screen. She thinks something is broken.',
               'It is a security feature: the terminal does not echo the characters at all, so someone watching cannot see how long the password is.',
               'She types the whole password and presses Enter. sudo accepts it and apt runs. (Messages shown are typical.)',
               'If she types it wrong, sudo says “Sorry, try again”. If the WSL password is forgotten, it can be reset from Windows.'],
              hid='scenario-password')

# scenario 2: files between Windows and WSL
fa = label_box(14, 20, 150, 60, ['Windows', 'C:\\Users\\Riya\\Documents'], 'blue', 8.4) + label_box(196, 20, 150, 60, ['WSL Ubuntu', '/home/riya'], 'green', 8.4) + cap('Two worlds on one laptop.', 'How do files cross between them?', 'card', y=150, h=44)
fb = label_box(14, 20, 150, 60, ['Windows', 'C:\\Users\\Riya\\Documents'], 'blue', 8.4) + label_box(196, 20, 150, 60, ['WSL Ubuntu', '/mnt/c/Users/Riya/Documents'], 'green', 8.4) + arrow(166, 50, 194, 50, 'acc', 2) + cap('From Linux, Windows drives appear under /mnt/c.', '', 'blue', y=150, h=34)
fc = label_box(14, 20, 150, 60, ['Windows Explorer', '\\\\wsl.localhost\\Ubuntu'], 'blue', 8.4) + label_box(196, 20, 150, 60, ['WSL Ubuntu', '/home/riya/projects'], 'green', 8.4) + arrow(194, 50, 166, 50, 'acc', 2) + cap('From Windows, Linux files appear in Explorer.', 'Or type explorer.exe . in WSL.', 'blue', y=150, h=44)
fd = bars([('ls -R on /mnt/c project', 100, 'red', 'slow'), ('ls -R on ~/projects', 18, 'green', 'fast')], y=40) + cap('Linux tools on /mnt/c cross the VM boundary.', 'Keep projects in ~ (Linux home). Bars illustrative.', 'amber', y=150, h=44)
fe = (t(180, 30, 'Rules of thumb', 10.5, 'acc', bold=True) + ''.join(t(26, 56 + k * 19, s, 8.6, anchor='start') for k, s in enumerate(['• Code and data you process with Linux tools: ~/projects.', '• Documents you open in Windows apps: Windows folders.', '• VS Code: run code . inside WSL for the best of both.'])) + cap('Right file, right side.', '', 'green', y=150, h=34))
s2 = anim_one('Real-time scenario 2', 'Where are my files? Windows ↔ WSL',
              'Kabir shows Riya how files move between Windows and Ubuntu in WSL, and the one mistake that makes everything slow.',
              'Sharing files between Windows and WSL', 'Windows and WSL folders, arrows showing /mnt/c from Linux and \\\\wsl.localhost from Windows, and a speed comparison.', [fa, fb, fc, fd, fe],
              ['Windows has its folders; Ubuntu in WSL has its own Linux file system.',
               'Inside Ubuntu, the C: drive is mounted at <code>/mnt/c</code>, so <code>cd /mnt/c/Users/Riya/Documents</code> reaches Windows files.',
               'In Windows Explorer, Linux files are under <code>\\\\wsl.localhost\\Ubuntu</code>. Running <code>explorer.exe .</code> in WSL opens the current folder.',
               'Linux tools running on files in <code>/mnt/c</code> must go through a translation layer, which is much slower for many small files. Bars are illustrative.',
               'Keep Linux projects in your Linux home and use VS Code’s WSL support to edit them from Windows.'],
              hid='scenario-files')

# scenario 3: cloud VM and the forgotten bill
ca = label_box(14, 20, 150, 56, ['Create VM', 'Ubuntu 24.04, small size'], 'blue', 8.4) + label_box(196, 20, 150, 56, ['Firewall rule', 'SSH 22 from: my IP'], 'green', 8.4) + cap('Riya creates a small Ubuntu VM in the cloud console.', '', 'card', y=150, h=34)
cb = term(14, 16, 332, 96, ['$ ssh -i ~/.ssh/course-key ubuntu@203.0.113.10', ('Welcome to Ubuntu 24.04 LTS', 'out'), ('ubuntu@vm:~$ ', 'prompt')], title='riya@laptop', size=7.4, step=13) + cap('She logs in over SSH with a key file.', 'A real server, 10 minutes later.', 'blue', y=150, h=44)
cc = bars([('Day 1', 8, 'green', 'running'), ('Day 10', 40, 'amber', 'still running'), ('Day 30', 100, 'red', 'bill!')], y=34) + cap('She forgets it. It runs 24×7 for a month.', 'Cloud VMs bill by the hour while running.', 'red', y=150, h=44)
cd_ = label_box(14, 20, 150, 56, ['Stop when idle', 'or delete after use'], 'green', 8.4) + label_box(196, 20, 150, 56, ['Billing alert', 'e.g. ₹500 budget'], 'green', 8.4) + cap('Fix: stop or delete idle VMs, set a budget alert.', '', 'green', y=150, h=34)
ce = (t(180, 30, 'Cloud VM checklist', 10.5, 'acc', bold=True) + ''.join(t(26, 56 + k * 19, s, 8.6, anchor='start') for k, s in enumerate(['• SSH with a key, never a weak password.', '• Allow port 22 only from your own IP.', '• Budget alert on day one.', '• Stop or delete when the practice session ends.'])) + cap('Treat a cloud VM like a taxi meter.', '', 'green', y=150, h=34))
s3 = anim_one('Real-time scenario 3 · advanced', 'A cloud VM in ten minutes, and the bill that followed',
              'Cloud servers are the best practice for SSH and administration, and a classic source of surprise bills and open doors. IP address and amounts are examples.',
              'Using a cloud VM safely', 'Creating a cloud VM with a firewall rule, logging in with SSH, forgetting it running for a month, and the fixes.', [ca, cb, cc, cd_, ce],
              ['Riya creates a small Ubuntu VM and a firewall rule that allows SSH (port 22) only from her own IP address.',
               'She logs in with <code>ssh -i key ubuntu@&lt;ip&gt;</code>. Now she has a real internet-facing Linux server (Lesson 16.6 explains SSH keys).',
               'She forgets to stop it. Cloud VMs are billed by the hour (or second) while running, so a month of idling costs money.',
               'Habits: stop or delete VMs after practice, and set a budget alert on the account from day one.',
               'Security matters too: any server open to the internet receives automated login attempts within minutes. Keys and narrow firewall rules keep them out.'],
              hid='scenario-cloud')

animation = '''<section class="part" id="animation">
  <span class="part-label"><b>5</b> See it happen</span>
  <h2>What <code>wsl --install</code> really builds</h2>
  <p>Left: what Riya sees in PowerShell and Ubuntu (messages are typical; wording varies by version). Right: the layers WSL creates.</p>
''' + two + '''
  <p>Three real-time scenarios: the invisible password, moving files between Windows and WSL, and using a cloud VM safely.</p>
''' + s1 + s2 + s3 + '''
''' + dissect('Layer by layer: dissect Ubuntu inside Windows (WSL 2)',
    'What actually runs when you open “Ubuntu” from the Windows Start menu? Six layers, from the app you click down to the hardware. The commands shown ran on our Ubuntu build machine, which is not WSL; on WSL you will see the WSL values mentioned.', [
    dict(key='app', name='Windows Terminal', sub='the window you click',
         why='You need a window to type in. Windows provides it, as for any other app.',
         how='It starts <code>wsl.exe</code> and shows its text.',
         impl='A normal Windows app; profiles for Ubuntu, PowerShell and cmd.',
         used='Every WSL session; VS Code also opens WSL terminals.'),
    dict(key='wslexe', name='wsl.exe', sub='the doorway',
         why='Something must connect Windows to the Linux side and start it if it is not running.',
         how='It asks the WSL service to start the utility VM and the Ubuntu distro, then attaches your window to a Linux shell.',
         impl='<code>C:\\Windows\\System32\\wsl.exe</code>; commands such as <code>wsl -l -v</code> and <code>wsl --shutdown</code>.',
         used='Managing distros: install, list, stop, set defaults.'),
    dict(key='vm', name='Utility VM', sub='lightweight virtual machine',
         why='The Linux kernel cannot run directly on the Windows kernel. A tiny VM gives it a computer of its own.',
         how='Built on Hyper-V technology; starts in about a second and borrows memory from Windows as needed.',
         impl='Managed by Windows; you never configure it by hand (optional settings in <code>.wslconfig</code>).',
         used='Also used by Docker Desktop on Windows.',
         cmd='systemd-detect-virt'),
    dict(key='kernel', name='WSL Linux kernel', sub='built by Microsoft',
         why='Ubuntu’s programs need a real Linux kernel for system calls.',
         how='A genuine Linux kernel, kept up to date through Windows Update; its version string contains “microsoft”.',
         impl='Shipped with WSL; source published as open source.',
         used='Every command you run in WSL goes through it.',
         cmd='grep -qi microsoft /proc/version && echo "WSL kernel" || echo "not WSL (this build machine): $(uname -r)"'),
    dict(key='files', name='Ubuntu’s files', sub='a virtual disk',
         why='Linux needs its own file system (ext4) with Linux permissions.',
         how='Ubuntu’s whole tree lives in one virtual disk file; Windows drives are mounted inside it at <code>/mnt/c</code>.',
         impl='A file named <code>ext4.vhdx</code> in your Windows user’s AppData folder.',
         used='Keep projects inside it (~/projects) for speed.',
         cmd='df -h / | tail -1'),
    dict(key='shell', name='Your shell', sub='bash as user riya',
         why='This is where you finally type commands.',
         how='bash runs as the user you created on first start, with sudo rights.',
         impl='<code>/usr/bin/bash</code> inside Ubuntu; your home is <code>/home/&lt;you&gt;</code>.',
         used='The rest of this course.',
         cmd='echo "$(whoami) in $HOME on $(grep PRETTY_NAME /etc/os-release | cut -d\'"\' -f2)"'),
]) + qc('Inside WSL, where is your Windows C: drive?', '<code>/mnt/c</code>. And Linux files appear in Windows Explorer under <code>\\\\wsl.localhost\\Ubuntu</code>.') + '''
</section>
'''

# ---------------------------------------------------------------- 6. real world
uc = '''<section class="part" id="real-world">
  <span class="part-label"><b>6</b> Real-world use</span>
  <h2>How professionals get their Linux</h2>
''' + usecase('<rect x="20" y="18" width="80" height="54" rx="6" class="s-board"/>' + t(60, 50, 'VS Code + WSL', 8.2, 'chalk', bold=True),
              '1. Developers on Windows laptops',
              'Many companies issue Windows laptops; developers install WSL, keep code in the Linux home and use VS Code’s WSL mode, so their tools match the Linux servers.',
              ['Windows laptop', '*WSL Ubuntu', 'Same tools as servers']) + '\n' + usecase(
    label_box(14, 22, 92, 46, ['VM snapshot', 'before / after'], 'blue', 8.6), '2. Training and testing in VMs',
    'Trainers and testers use VMs with snapshots: take a snapshot, try something risky, roll back in seconds. Perfect for learning administration.',
    ['Snapshot', '*experiment', 'Restore']) + '\n' + usecase(
    ''.join(server(10 + k * 36, 16, 30, 50, None, 'violet', leds=3) for k in range(3)), '3. Cloud servers for real projects',
    'Production systems run on cloud VMs or on servers in data centres. Engineers reach them only over SSH; nobody installs them by clicking through an ISO.',
    ['Image', '*cloud VM', 'SSH']) + '\n' + usecase(
    label_box(14, 22, 92, 46, ['docker run', 'ubuntu'], 'green', 8.6), '4. Containers for quick environments',
    'With Docker, <code>docker run -it ubuntu bash</code> starts a throw-away Ubuntu environment in seconds. Common for testing scripts on several distros.',
    ['docker run', '*Linux container', 'Test script']) + '\n' + usecase(
    '<rect x="30" y="16" width="60" height="58" rx="6" class="s-card2" style="stroke:var(--line)"/>' + t(60, 50, 'USB', 9, 'acc', bold=True),
    '5. Live USB for rescue',
    'Admins carry a bootable Linux USB to rescue machines that will not start: copy files off, fix boot problems, test hardware.',
    ['Broken PC', '*Live USB Linux', 'Files rescued']) + '''
  <p class="muted">Examples are simplified and generic. They describe common patterns, not the internal systems of any particular company.</p>
''' + oneliners('Checks to run right after installing Linux. All were really run on an Ubuntu 24.04 cloud VM; on WSL some answers will differ.', [
    dict(level='b', title='Am I really inside Linux, and as whom?', scenario='You opened Ubuntu for the first time and want to confirm the setup.',
         cmd='echo "$(whoami) on $(grep PRETTY_NAME /etc/os-release | cut -d\'"\' -f2)"',
         explain='<code>whoami</code> prints your user; the grep and cut pick the distro name out of /etc/os-release.'),
    dict(level='b', title='Is this WSL?', scenario='A script should behave differently on WSL and on a real server.',
         cmd='grep -qi microsoft /proc/version && echo "running on WSL" || echo "not WSL"',
         explain='The WSL kernel’s version string contains “microsoft”. <code>grep -q</code> prints nothing and only sets the exit status, which <code>&&</code> and <code>||</code> use.'),
    dict(level='i', title='Do I have enough room for the course?', scenario='Before installing big tools (Docker, Hadoop) you want free disk and RAM in one line.',
         cmd='echo "disk free: $(df -h ~ | awk \'NR==2 {print $4}\'), RAM: $(free -h | awk \'/^Mem/ {print $2}\')"',
         explain='<code>df -h ~</code> reports the disk holding your home; <code>awk \'NR==2\'</code> takes its second line, column 4 (Avail). <code>free -h</code> line Mem, column 2 (total).'),
    dict(level='a', title='What kind of machine is this?', scenario='Support asks whether you are on a VM, a container, WSL or real hardware.',
         cmd='systemd-detect-virt',
         explain='Prints the virtualisation technology detected: <code>none</code> on real hardware, <code>wsl</code>, <code>kvm</code>, <code>oracle</code> (VirtualBox), <code>docker</code>… This answer came from the container used to build this lesson.'),
], extra=build_up('a one-line “is this machine ready?” report', 'Before installing Docker or Hadoop later in the course, check cores, RAM and free disk in one line.', '', [
    ('nproc', 'CPU cores.'),
    ("free -m | awk '/^Mem/ {print $2}'", 'Total RAM in MB: the Mem line, column 2.'),
    ("df -BG ~ | awk 'NR==2 {print $4}'", 'Free disk space in GB on the disk holding your home.'),
    ("c=$(nproc); r=$(free -m | awk '/^Mem/ {print $2}'); d=$(df -BG ~ | awk 'NR==2 {print $4}'); [ $c -ge 2 ] && [ $r -ge 4096 ] && s=READY || s='NOT READY'; echo \"cores=$c ram=${r}MB disk_free=$d -> $s\"", 'Combine into a verdict. Both tests must pass for READY.'),
], level='i')) + which('Everyday commands around installing and running Linux.', [
    ('Install WSL with Ubuntu (PowerShell, admin)', 'wsl --install', 'Enables features and installs Ubuntu on WSL 2.', 'Running it in a normal (non-admin) PowerShell.'),
    ('See installed distros and WSL version', 'wsl -l -v', 'Shows NAME, STATE and VERSION (want 2).', 'Assuming WSL 2 on an old install that is still on version 1.'),
    ('Restart WSL completely', 'wsl --shutdown', 'Stops the VM; next start is fresh.', 'Rebooting Windows instead.'),
    ('Open the current Linux folder in Windows', 'explorer.exe .', 'Opens Explorer at \\\\wsl.localhost\\…', 'Editing Linux files with old Windows tools that change line endings.'),
    ('Update Ubuntu after installing', 'sudo apt update && sudo apt upgrade -y', 'Refreshes lists, then installs updates.', 'Running only <code>apt update</code> and thinking you upgraded.'),
    ('Connect to a cloud VM', 'ssh -i key.pem ubuntu@IP', 'Logs in with your private key.', 'Opening port 22 to the whole internet with password login.'),
    ('Check an ISO before installing', 'sha256sum ubuntu.iso', 'Compare with the official SHA256SUMS.', 'Installing an ISO downloaded from a random mirror without checking.'),
]) + '''
''' + puzzle_answer('WSL 2 starts a tiny <b>virtual machine</b> (built on Hyper-V) that runs a <b>real Linux kernel built by Microsoft</b>, separate from the Windows kernel. Ubuntu’s files live inside a single <b>virtual disk file</b> (<code>ext4.vhdx</code>) on your Windows drive. Your Windows partitions are never touched; your C: drive is simply visible from Linux at <code>/mnt/c</code>.') + qc('You finished practising on a cloud VM. What two things should you do before closing your laptop?', 'Stop or delete the VM so it stops billing, and make sure a budget alert is set on the account.') + '''
</section>
'''

cmap = concept_map(
    [('1.1', 'Computer basics', 'disk, RAM, files'), ('1.3', 'Distributions', 'why Ubuntu LTS')],
    ['five ways to get Linux', 'WSL step by step', 'Ubuntu in VirtualBox', 'how WSL 2 works', 'files between Windows and Linux', 'cloud VM safety'],
    [('1.6', 'Terminal and prompt', 'your first session'), ('15.1', 'Disks and partitions', 'what dual boot really changes'), ('16.6', 'SSH', 'log in to cloud VMs'), ('19.4', 'Checksums', 'verify ISO downloads')],
    'Once Linux is installed, every “Run on your PC” panel in the course works on your own machine.')
body = cmap + (story.replace('  <div class="story">', before('Lessons <a href="../01-before-you-start-computer-basics-files-servers/">1.1</a>–<a href="../03-linux-distributions-explained-ubuntu-debian/">1.3</a>. You need a Windows 10/11 laptop, a Mac, or any device for the browser runner.') + '  <div class="story">', 1)
        + definition + types + steps + animation + uc)
open(os.path.join(HERE, 'body.html'), 'w', encoding='utf-8').write(body)
print('body.html', len(body) // 1024, 'KB')
